@extends('layouts.master') @section('content') @section('title') @endsection
@php $actionUrl=url('/storePatientSerialAction'); @endphp
<script>$('form').parsley();</script>
<style>
    ul li.active,
    a.active {
        color: #3fbbc0;
    }

</style>
<div class="" role="main">
    <div class="">
        {{-- <div class="page-title">
            <div class="col-md-6">
                <div class="row">
                    <h3>
                        {{$header['pageTitle']}}
                    </h3>
                </div>
            </div>
        </div> --}}
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="x_panel" style="min-height:450px;">
                    {{-- <div class="x_title">
                        <h2>{{$header['tableTitle']}} </h2>
                    </div> --}}
                    <div class="x_title">
                        <div class="col-sm-12">
                            <h2 style="color: #262626;font-size:24px;font-weight:normal;">{{$header['tableTitle']}} </h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <br>
                        <form id="SerialEntryForm" data-parsley-validate="" role="form" method="post" action="{{$actionUrl}}"
                            class="form-label-left" autocomplete="off">
                            @csrf

                            <?php
                            $MX_SL = 0;
                            if($slInfo){
                                $MX_SL = $slInfo->MAX_SL + 1;
                            }else{
                                    $MX_SL = $MX_SL+1;
                            }
                            ?>
                            <style>
                                .SL_NO[readonly] {
                                    background-color: #f5f7f9;
                                }
                            </style>
                            <div class="field item form-group">
                                <label class="col-form-label col-md-3 col-sm-3  label-align">Serial No</label>
                                <div class="col-md-6 col-sm-6">
                                    <input class="form-control input-field-required-sign SL_NO" name="SL_NO" id="SL_NO" value="{{$MX_SL}}" required readonly/>
                                </div>
                            </div>
                            {{-- <div class="field item form-group">
                                <label class="col-form-label col-md-3 col-sm-3  label-align">Department*</label>
                                <div class="col-md-6 col-sm-6">
                                    <select class="form-control" name="DEPT_ID" id="DEPT_ID" required>
                                        <option value="">--select--</option>
                                        @if($depts)
                                        @foreach($depts as $row)
                                        <option value="{{$row->LOOKUP_DATA_ID}}">{{$row->LOOKUP_DATA_NAME}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="field item form-group">
                                <label class="col-form-label col-md-3 col-sm-3  label-align">Doctor*</label>
                                <div class="col-md-6 col-sm-6">
                                    <select class="form-control" name="DOCTOR_ID" id="DOCTOR_ID" required>
                                        <option value="">--select--</option>
                                        @if($doctors)
                                        @foreach($doctors as $row)
                                        <option value="{{$row->LOOKUP_DATA_ID}}">{{$row->LOOKUP_DATA_NAME}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="field item form-group">
                                <label class="col-form-label col-md-3 col-sm-3  label-align">Room No*</label>
                                <div class="col-md-6 col-sm-6">
                                    <select class="form-control" name="ROOM_NO" id="ROOM_NO" required>
                                        <option value="">--select--</option>
                                        @if($rooms)
                                        @foreach($rooms as $row)
                                        <option value="{{$row->LOOKUP_DATA_ID}}">{{$row->LOOKUP_DATA_NAME}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div> --}}
                            <div class="field item form-group">
                                <label class="col-form-label col-md-3 col-sm-3  label-align">Category*</label>
                                <div class="col-md-6 col-sm-6">
                                    <select class="form-control" name="CATEGORY_ID" id="CATEGORY_ID" required>
                                        <option value="">--select--</option>
                                        @if($categories)
                                        @foreach($categories as $row)
                                        <option value="{{$row->ID}}">{{$row->NAME}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="field item form-group">
                                <label class="col-form-label col-md-3 col-sm-3  label-align">Name</label>
                                <div class="col-md-6 col-sm-6">
                                    <input class="form-control input-field-required-sign" name="NAME" id="NAME" required/>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="form-group">
                                <div class="col-md-6 offset-md-3">
                                    <input type="hidden" name="targetURL" id="targetURL">
                                    <button type="submit" id="btnSubmit" class="btn btn-primary">Submit</button>
                                    {{-- <button type='reset' class="btn btn-success">Reset</button> --}}
                                    <a href="{{url('serial-entry')}}" class="btn btn-success">Refresh</a>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $("#CATEGORY_ID").change(function(){
        $("#NAME").removeClass("parsley-error");
        var CATEGORY_ID = $("#CATEGORY_ID").val();
        if(CATEGORY_ID==3){
            $("#NAME").removeAttr("required","required");
        }else{
            $("#NAME").attr("required","required");
        }
    });
</script>
@endsection






