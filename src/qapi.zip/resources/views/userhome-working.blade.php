<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Queue Management</title>
    <link href="{{url('images/favicon.png')}}" rel="icon" type="image/x-icon" />
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script type="text/javascript" src="{{ URL::asset('assets/vendors/jquery/dist/jquery.min.js') }}"></script>

    <!-- Styles -->
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Nunito', sans-serif;
            background-color: white;
            color: black;
            position: relative;
            min-height: 100vh;
        }

        .header-container {
            font-size: 4rem;
            display: flex;
            justify-content: space-between;
            padding: 4vh;
        }

        .body-container {
            display: flex;
            flex-direction: column;
            justify-content: center;
            height: 80vh;
        }

        .serial-container {
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-around;
        }

        marquee {
            white-space: pre-wrap;
            background-color: #000080;
            font-size: 4rem;
            padding: 10px;
            color: white;
            /* color: #ff1a1a; */
        }

        .serial-no {
            width: 100px !important;
            height: 100px !important;
            border:4px solid #FF0000;
            background: red;
            border-radius: 50%;
            font-weight: bold;
        }

        .stopwatch-container {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .stopwatch {
            width: 40vw;
            min-height: 200px;
            /* border: solid 1px cyan; */
            border-radius: 10px;
            padding: 30px;
            display: flex;
            align-items: center;
            flex-direction: column;
            justify-content: space-around;
        }

        .stopwatch-dial {
            padding: 20px;
            width: 100%;
            /* border: solid 1px cyan; */
            border-radius: 10px;
            box-shadow: 0px 0px 10px 8px rgb(160, 212, 232);
            -webkit-box-shadow: 0px 0px 10px 8px rgb(160, 212, 232);
            -moz-box-shadow: 0px 0px 10px 8px rgb(160, 212, 232);
            font-size: 5.5rem;
            display: flex;
            justify-content: space-around;
        }

        .animate-charcter {
            text-transform: uppercase;
            text-align: center;
            background-image: linear-gradient(-225deg,
                    #231557 0%,
                    #44107a 29%,
                    #ff1361 67%,
                    #fff800 100%);
            background-size: auto auto;
            background-clip: border-box;
            background-size: 200% auto;
            color: #fff;
            background-clip: text;
            text-fill-color: transparent;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: textclip 3s linear infinite;
            display: inline-block;
            font-size: 9rem;
            margin: 0.5rem 0;
        }

        @keyframes textclip {
            to {
                background-position: 200% center;
            }
        }

        footer {
            background-color: #191919;
            color: white;
            position: absolute;
            bottom: 0;
            width: 100%;
            /* padding: 15px 0; */
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        footer p {
            margin: 0;
            padding: 10px;
        }

        footer img {
            max-height: 26px;
        }

        /* Media Query for Bigger Screens  */

        @media screen and (min-width: 1380px) {
            .header-container {
                font-size: 7rem;
            }

            marquee {
                font-size: 7rem;
            }

            .stopwatch-dial {
                font-size: 10rem;
            }

            .animate-charcter {
                font-size: 12rem;
            }

            footer {
                font-size: 1.5rem;
            }

        }
        /* Custom css by Salaquzzaman */
        .animate-charcter{
            text-transform: capitalize;
            margin-top: -70px;
        }
    </style>
</head>

<body>
    <div style="border:2px solid green; position:fixed; z-index:999;display:none;">
        <button id="pauseTimer" class="btn">Pause</button>
        <button id="startTimer" class="btn">Start</button>
        <button id="resetTimer" class="btn">Reset</button>
        <input type="text" name="OLD_VAL" id="OLD_VAL">
        <input type="text" name="TEA_BREAK_STATUS" id="TEA_BREAK_STATUS">
    </div>

      <div class="timerDisplay" style="display:none;">
        00 : 00 : 00 : 000
      </div>

    <div class="header-container">
        <div> Now Serving </div>
        <div id="date" class="date" onload="showDate()"></div>
    </div>
    <div class="body-container">
        <div class="serial-container" id="serialContainer">
            <div class="marquee-container"><marquee behavior="scroll" id="marquID" onclick="getThisMark(this)"><span id="serialTitle">Serial No</span><span id="serialSpace"> - </span><span class="serial-no" id="serialNo"></span><span id="nameOrCat"></span><span id="remarks"></span> </marquee></div>

            <div class="stopwatch-container">
                <div class="stopwatch">
                    <div class="stopwatch-dial">
                        <span id="min">00</span> :
                        <span id="sec">00</span>
                    </div>
                </div>
            </div>
        </div>
        <h3 class="animate-charcter" id="breakContainer">Prayer Time</h3>
    </div>
    <script>
        $('#serialContainer').hide();
        $('#breakContainer').hide();

        getCurrentDetails();
        function getCurrentDetails(){
            // $('#serialNo').html('');
            // $('#remarks').html('');
            $.ajax({
                type: 'GET',
                url: '{{url("/getCurrentData")}}',
                success: function (data) {
                    // Serial initialization
                    $('#min').html(data.timeDurationMin);
                    $('#sec').html(data.timeDurationSec);
                    var serialNo = data.sl;
                    var slLength = data.slLength;
                    if(slLength==1){
                        $('#serialNo').html('0'+serialNo);
                    }else{
                        $('#serialNo').html(serialNo);
                    }
                    if(slLength>0){
                        $('#serialNo').show();
                        $('#serialSpace').show();
                        $('#serialTitle').show();
                        $('#nameOrCat').show();
                    }else{
                        $('#serialNo').hide();
                        $('#serialSpace').hide();
                        $('#serialTitle').hide();
                        $('#nameOrCat').hide();
                    }

                    // Name or Category showing
                    var nameOrCat = data.nameOrCat;
                    if(nameOrCat!=''){
                        $("#nameOrCat").html(' - '+nameOrCat);
                    }else{
                        $("#nameOrCat").html('');
                    }

                    // Remarks showing
                    var remarks = data.remarks;
                    if(remarks==''){
                        $('#remarks').html('');
                    }else{
                        if(remarks==null){
                            $('#remarks').html('');
                        }else{
                            $('#remarks').html(' - '+remarks);
                        }
                    }

                    // Break time showing
                    var teaBreak = data.teaBreak;
                    if(teaBreak==1){
                        $('#serialContainer').hide();
                        $('#breakContainer').show();
                        $('#TEA_BREAK_STATUS').val(1);
                    }else{
                        $('#serialContainer').show();
                        $('#breakContainer').hide();
                        var TEA_BREAK_STATUS = $('#TEA_BREAK_STATUS').val();
                        if(TEA_BREAK_STATUS==1){
                            setTimeout(function () {
                                $('#marquID').click();
                            }, 1000);
                            $('#TEA_BREAK_STATUS').val('');
                            // $('#resetTimer').click();
                            // resetWatch();
                            // $('#startTimer').click();
                        }
                    }

                    if(serialNo==''){  // sl empty
                        $('#OLD_VAL').val('')
                        //$('#resetTimer').click();
                        //resetWatch();
                    }else{ // sl not empty

                        if($('#OLD_VAL').val()==''){
                            $('#OLD_VAL').val(data.sl);
                            //$('#startTimer').click();
                        }else{ // yes old value
                            var NEW_VAL = serialNo;
                            var OLD_VAL = $('#OLD_VAL').val();
                            if(NEW_VAL != OLD_VAL){
                                $('#OLD_VAL').val(NEW_VAL);
                                // $('#resetTimer').click();
                                // resetWatch();
                                // $('#startTimer').click();
                            }
                        }
                    }

                }
            });
            setTimeout(function () {
                getCurrentDetails();
            }, 1000);
        }

        // Start marquree
        function getThisMark(e){
            e.start();
        }
        setTimeout(function () {
            $('#marquID').click();
        }, 1000);

    </script>

<script>
    // STOPWATCH SCRIPT
    /*let [milliseconds,seconds,minutes,hours] = [0,0,0,0];
    let timerRef = document.querySelector('.timerDisplay');
    let currentInterval = null;

    document.getElementById('startTimer').addEventListener('click', ()=>{
        if(currentInterval!==null){
            clearInterval(currentInterval);
        }
        currentInterval = setInterval(displayTimer,10);
    });

    document.getElementById('pauseTimer').addEventListener('click', ()=>{
        clearInterval(currentInterval);
    });

    document.getElementById('resetTimer').addEventListener('click', ()=>{
        clearInterval(currentInterval);
        [milliseconds,seconds,minutes,hours] = [0,0,0,0];
        timerRef.innerHTML = '00 : 00 : 00 : 000 ';
    });

    function displayTimer(){
        milliseconds+=10;
        if(milliseconds == 1000){
            milliseconds = 0;
            seconds++;
            if(seconds == 60){
                seconds = 0;
                minutes++;
                if(minutes == 60){
                    minutes = 0;
                    hours++;
                }
            }
        }

    let h = hours < 10 ? "0" + hours : hours;
    let m = minutes < 10 ? "0" + minutes : minutes;
    let s = seconds < 10 ? "0" + seconds : seconds;
    let ms = milliseconds < 10 ? "00" + milliseconds : milliseconds < 100 ? "0" + milliseconds : milliseconds;*/

    //timerRef.innerHTML = ` ${h} : ${m} : ${s} : ${ms}`;
    //$('#min').html(m);
    //$('#sec').html(s);
    }
    //$('#startTimer').click();

    // Customize function by Salaquzzaman for this page only
    function resetWatch(){
        let [milliseconds,seconds,minutes,hours] = [0,0,0,0];
        let timerRef = document.querySelector('.timerDisplay');
        let currentInterval = null;
        $('#min').html('00');
        $('#sec').html('00');
    }
</script>


</body>

<footer>
    <p> Designed and Developed by </p>
    <img src="{{asset('public/images/ati-logo.png')}}" alt="" srcset="">
</footer>


<script>
    function showDate() {
        var d = new Date(Date.now());
        d = d.toLocaleString('en-US', {
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        });

        document.getElementById("date").innerText = d;
        document.getElementById("date").textContent = d;
    }
    showDate();
</script>

</body>

</html>

