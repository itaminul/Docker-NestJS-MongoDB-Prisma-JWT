<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiResponseModel;
use Illuminate\Http\Request;
use App\Models\User;
use Auth;
use DB;
use Exception;
use Illuminate\Database\QueryException;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Mail;
use Illuminate\Support\Facades\Http;

class SmsController extends Controller
{

    public function sendOTP($recipientNumber, $otp)
    {
        // API Endpoint
        $apiEndpoint = 'https://login.esms.com.bd/api/v3/sms/send';

        // Prepare the data as an array
        $data = [
            'recipient' => '88' . $recipientNumber,
            'sender_id' => '8809601001293',
            'type' => 'plain',
            'message' => 'আপনার ওটিপি হলো ' . $otp,
        ];
        // dd($data);

        // Send request with array data
        $response = Http::withOptions(['verify' => false])->withHeaders([
            'Accept' => '*/*',
            'Content-Type' => 'application/json',
        ])
        ->withToken('Bearer 311|M9019W7qC5A7CVK0cJyOuFEFh29yqo8AnMl3eeis')
        ->post('https://login.esms.com.bd/api/v3/sms/send', $data);
        

        // Check if the request was successful
        if ($response->successful()) {
            return $response->json();
        } else {
            // Handle the error
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to send OTP',
            ], $response->status());
        }
    }

    public function sendOTP1($recipientNumber, $otp)
    {
        // API Endpoint
        $apiEndpoint = 'https://login.esms.com.bd/api/v3/sms/send';

        // Prepare the data as an array
        $data = [
            'recipient' => '88' . $recipientNumber,
            'sender_id' => '8809601001293',
            'type' => 'plain',
            'message' => 'আপনার ওটিপি হলো ' . $otp,
        ];

        // Send request with array data
        $response = Http::withOptions(['verify' => false])->withHeaders([
            'Authorization' => 'Bearer 300|ZsjmROoaLMfMgv1POUnCvhT2UBjrdyN21eHOUS3V',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->post('https://login.esms.com.bd/api/v3/sms/send', [
            'recipient' => '88' . $recipientNumber,
            'sender_id' => '8809601001293',
            'type' => 'plain',
            'message' => 'আপনার ওটিপি হলো ' . $otp,
        ]);
        var_dump($response);
        exit;

        // Check if the request was successful
        if ($response->successful()) {
            return $response->json();
        } else {
            // Handle the error
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to send OTP',
            ], $response->status());
        }
    }

}
