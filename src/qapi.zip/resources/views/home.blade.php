@extends('layouts.master')
@section('content')
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    @if (Session::has('errors') || Session::has('passChange'))
                        <div class="alert alert-{{ Session::has('errors') ? 'danger' : 'success' }}" id="success-alert">
                            <button type="button" class="close" data-dismiss="alert">x</button>
                            <strong> {{ Session::has('errors') ? 'Fail !': 'Success !' }} </strong>
                            {{ Session::has('errors') ? Session::get('errors') : Session::get('passChange') }}
                        </div>
                    @endif

                    <div class="card-header">{{ __('Dashboard') }}</div>
                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $("#success-alert").fadeTo(2000, 500).slideUp(500, function() {
                $("#success-alert").slideUp(500);
            });
        });
    </script>
@endsection
