<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Queue</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Styles -->
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Nunito', sans-serif;
            background-color: white;
            color: black;
            position: relative;
            min-height: 100vh;
        }

        .header-container {
            font-size: 4rem;
            display: flex;
            justify-content: space-between;
            padding: 4vh;
        }

        .body-container {
            display: flex;
            flex-direction: column;
            justify-content: center;
            height: 80vh;
        }

        .serial-container {
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-around;
        }

        marquee {
            white-space: pre-wrap;
            background-color: #000080;
            font-size: 4rem;
            padding: 10px;
            color: white;
            /* color: #ff1a1a; */
        }

        .serial-no {
            width: 100px;
            height: 100px;
            background: red;
            border-radius: 50%;
            font-weight: bold;
        }

        .stopwatch-container {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .stopwatch {
            width: 40vw;
            min-height: 200px;
            /* border: solid 1px cyan; */
            border-radius: 10px;
            padding: 30px;
            display: flex;
            align-items: center;
            flex-direction: column;
            justify-content: space-around;
        }

        .stopwatch-dial {
            padding: 20px;
            width: 100%;
            /* border: solid 1px cyan; */
            border-radius: 10px;
            box-shadow: 0px 0px 10px 8px rgb(160, 212, 232);
            -webkit-box-shadow: 0px 0px 10px 8px rgb(160, 212, 232);
            -moz-box-shadow: 0px 0px 10px 8px rgb(160, 212, 232);
            font-size: 5.5rem;
            display: flex;
            justify-content: space-around;
        }

        .animate-charcter {
            text-transform: uppercase;
            text-align: center;
            background-image: linear-gradient(-225deg,
                    #231557 0%,
                    #44107a 29%,
                    #ff1361 67%,
                    #fff800 100%);
            background-size: auto auto;
            background-clip: border-box;
            background-size: 200% auto;
            color: #fff;
            background-clip: text;
            text-fill-color: transparent;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: textclip 3s linear infinite;
            display: inline-block;
            font-size: 9rem;
            margin: 0.5rem 0;
        }

        @keyframes textclip {
            to {
                background-position: 200% center;
            }
        }

        footer {
            background-color: #191919;
            color: white;
            position: absolute;
            bottom: 0;
            width: 100%;
            /* padding: 15px 0; */
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        footer p {
            margin: 0;
            padding: 10px;
        }

        footer img {
            max-height: 26px;
        }

        /* Media Query for Bigger Screens  */

        @media screen and (min-width: 1380px) {
            .header-container {
                font-size: 7rem;
            }

            marquee {
                font-size: 7rem;
            }

            .stopwatch-dial {
                font-size: 10rem;
            }

            .animate-charcter {
                font-size: 12rem;
            }

            footer {
                font-size: 1.5rem;
            }

        }
    </style>
</head>

<body>
    <div class="header-container">
        <div> Now Serving </div>
        <div id="date" class="date" onload="showDate()"></div>
    </div>
    <div class="body-container">
        <div class="serial-container">
            <div class="marquee-container">
                <marquee> Serial No - 5 - Name - As Test Emmergency Patient </marquee>
            </div>

            <div class="stopwatch-container">
                <div class="stopwatch">
                    <div class="stopwatch-dial">
                        <span>00</span> :
                        <span>00</span>
                    </div>
                </div>
            </div>
        </div>
        <!-- <h3 class="animate-charcter">Break<br>Time</h3> -->
    </div>
</body>

<footer>
    <p> Designed and Developed by </p>
    <img src="{{asset('/images/ati-logo.png')}}" alt="" srcset="">
</footer>


<script>
    function showDate() {
        var d = new Date(Date.now());
        d = d.toLocaleString('en-US', {
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        });

        document.getElementById("date").innerText = d;
        document.getElementById("date").textContent = d;
    }
    showDate();
</script>

</body>

</html>
