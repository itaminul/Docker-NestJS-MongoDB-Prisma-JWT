<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

use function PHPUnit\Framework\returnSelf;

class Settings extends Model
{

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 28-11-2022
     * @purpose get number value from settings by name
     */
    function getValOfSettings($name=null){
        $result = '';
        if(!empty($name)){
            $exe = DB::selectOne("select VALUE from settings where NAME='$name'");
            if($exe){
                $result = $exe->VALUE;
            }
        }
        return $result;
    }

}
