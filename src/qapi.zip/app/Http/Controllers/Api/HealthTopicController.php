<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiResponseModel;
use DB;

class HealthTopicController extends Controller{

    // public function getHealthTopicList1(){
    //     $healthTopicList = [];
    //     for($i=0;$i<=100;$i++){
    //         $healthTopicList[$i] = array(
    //             "document_url" => url('/uploads/health_topics/test.pdf'),
    //             "title" => "title ".($i+1)
    //         );
    //     }
        
    //     $data = array(
    //         "health_topic_list" => $healthTopicList
    //     );
    //     $result = new ApiResponseModel(true,"Health topic list Found",$data);
    //     return response()->json($result, 200);
    // }


    public function getHealthTopicList()
    {
        $pdf_list = DB::table('vascular_pdf_info')->select('PDF_NAME', 'PDF_URL')->get();
        if(!$pdf_list){
            $result = new ApiResponseModel(true,"PDF List Not Found");
            return response()->json($result, 500);
        }

        $healthTopicList = [];

        foreach($pdf_list as $key=>$pdf){
            $healthTopicList[$key] = array(
                "document_url" => url($pdf->PDF_URL),
                "title" => $pdf->PDF_NAME
            );
        }
     
        
        $data = array(
            "health_topic_list" => $healthTopicList
        );

        $result = new ApiResponseModel(true,"Health topic list Found",$data);
        return response()->json($result, 200);
        
    }

}

?>