@section('content')
@include('layouts.modalFormSubmit')
@php $actionUrl=url('/changeStatusDO'); @endphp
<script>
    $('form').parsley();
</script>
<?php ini_set('memory_limit', -1) ?>
<div class="flash-message"></div>
<div class="x_content">
    <form id="statusChangeForm" data-parsley-validate="" role="form" method="post" action="{{$actionUrl}}"
        class="form-label-left" autocomplete="off">
        @csrf

        @php
            $colorStatus = $status;
            $status = $status+1;
            $label = '<i style="color:red" class="fa fa-long-arrow-right"></i>';
        @endphp

        @if($colorStatus==0)
            <style>
                .btnChange{
                    border-radius: 50px;
                    width: 100px;
                    height: 100px;
                    background-color: #8746A6;
                    color: #fff;
                }
                .btnChange:hover{
                    background-color: #FFA525;
                    color: #fff;
                }
            </style>
            @php $label = 'DI'; @endphp
        @elseif($colorStatus==1)
            <style>
                .btnChange{
                    border-radius: 50px;
                    width: 100px;
                    height: 100px;
                    background-color: #FFA525;
                    color: #fff;
                }
                .btnChange:hover{
                    background-color: #82AB47;
                    color: #fff;
                }
            </style>
            @php $label = 'DO'; @endphp
        @else
        @endif

        @if($status==1)
            <span id="remrksAlert">Another patient already is in DI, for this remarks is mendatory.</span>
            <input type="checkbox" class="circle-nicelabel" name="REMARKS_OK" id="REMARKS_OK" value="1"/>Remarks
            <br>
            <textarea style="border:1px solid #dee2e6;margin-bottom:3px;"
                name="REMARKS" id="REMARKS" cols="50" rows="2" readonly></textarea>

        @endif

        <input type="hidden" name="ID" id="ID" value="{{$id}}">
        <input type="hidden" name="PATIENT_STATUS" id="PATIENT_STATUS" value="{{$status}}">
        <div style="text-align: center">
            <br>
            <input type="hidden" name="targetURL" id="targetURL">
            <input type="hidden" name="submitURL" id="submitURL" value="{{$actionUrl}}">

            <button type="submit" class="btn btn-lg btnChange"
                name="submit" id="">
                Proceed {{$label}}</button>


        </div>
        <script>

        </script>
        <style>
            #REMARKS:read-only{
                background-color: #EFEAEA;
            }
        </style>
    </form>
</div>
<script>
    $('#REMARKS_OK').click(function(){
        $('#REMARKS').val('');
        if ($(this).is(':checked')) {
            $('#REMARKS').removeAttr( "readonly");
            $('#REMARKS').css("background-color","initial");
        }else{
            $('#REMARKS').attr( "readonly", true);
            $('#REMARKS').css("background-color","#EFEAEA");
        }
    });

    // Redirect to specific location
    var k = $(location).attr("href");
    const myArray = k.split("/");
    var result = myArray[myArray.length - 1];
    $('#targetURL').val(result);
</script>
<script>
    $('#REMARKS_OK').nicelabel();
</script>

@if($colorStatus==0)
<style>
@media only screen and (min-width: 992px) {
    .btnChange {
      margin-top:-90px !important;
    }
}
</style>
@endif


