<div class="row patientDataTable">
    <div class="col-sm-12">
        <div class="card-box table-responsive">
            <table id="datatable12"
                class="table table-striped table-bordered custom-table-border dataTable no-footer"
                role="grid" aria-describedby="datatable_info">
                <thead>
                    <tr>
                        <th class="center">#</th>
                        <th class="center">Patient Category</th>
                        <th class="center">Patient Name</th>
                        <th class="center">Remarks</th>
                        <th class="center">Action</th>
                        <th class="center">Status</th>
                    </tr>
                </thead>
                <tbody>
                    @php $sl=1 @endphp @foreach($patients as $row)
                    <tr>
                        <td>
                            {{$sl}}
                            <input type="hidden" class="PATIENT_STATUS"  value="{{$row->PATIENT_STATUS}}">
                        </td>
                        <td>{{$row->CATEGORY_NAME}}</td>
                        <td>{{$row->NAME}}</td>
                        <td>{{$row->REMARKS}}</td>
                        <td>
                            @if($row->PATIENT_STATUS==0)
                            <button type="button" class="btn btn-info btn-sm"
                                style="width:30px;"
                                pageTitle="Update Patient"
                                pageLink="{{url('updateSerialInfo/'.$row->ID)}}"
                                onclick="getProfileUpdatePage($(this))" name="" id=""
                                data-modal-size="modal-lg" data-toggle="tooltip"
                                data-placement="top"
                                title="Update Patient">
                                <i class="fa fa-pencil"></i>
                            </button>
                            @endif
                        </td>
                        <td width="90px">
                            @if($row->PATIENT_STATUS==0) {{--PENDING--}}
                                <button type="button" class="btn btn-info btn-sm btnCP"
                                    pageTitle="Do you want to change status?"
                                    pageLink="{{url('viewStatus/'.$row->ID.'/0')}}"
                                    onclick="getStatusPage($(this))" name="" id=""
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="Consultation Pending">
                                    CP
                                </button>
                                {{-- <a href="{{ url('cancelSerial/'.$row->ID) }}" style="width: 30px"
                                    class="btn btn-sm btn-danger" title="Cancel"
                                    onclick="return confirm('Are you sure to cancel this serial?')">X</a> --}}

                            @elseif($row->PATIENT_STATUS==1) {{--ONGOING--}}
                                <button type="button" class="btn btn-info btn-sm btnDI"
                                    pageTitle="Do you want to change status?"
                                    pageLink="{{url('viewStatusDO/'.$row->ID.'/1')}}"
                                    onclick="getStatusPageForDO($(this))" name="" id=""
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="Doctor Room In">
                                    DI
                                </button>
                            @elseif($row->PATIENT_STATUS==2) {{--COMPLETE--}}
                                <button type="button" class="btn btn-info btn-sm btnDO"
                                    title="Doctor Room Out">
                                    DO
                                </button>
                            @else
                            @endif
                            {{-- @if($row->PATIENT_STATUS==3)
                                <span style="color:red;">Cancelled</span>
                            @endif --}}
                        </td>
                    </tr>
                    @php $sl++;@endphp @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    function getStatusPage(a) {
        var remarksNeeded = false;
        var TEA_BREAK = $('#TEA_BREAK').val();
        if ($('#TEA_BREAK').is(':checked')) {
            alertify.alert("Please, turn off prayer time first.");
            return false;
        }
        if ($('#REPORT_BREAK').is(':checked')) {
            alertify.alert("Please, turn off report view option first.");
            return false;
        }
        $("#remrksAlert").hide();

        // DI Checking
        var totalDI = 0;
        $('.PATIENT_STATUS').map(function () {
            if(this.value=='1' || this.value==1){
                totalDI = parseInt(totalDI) + 1;
            }
        }).get();
        totalDI = parseInt(totalDI);
        if(totalDI>=2){
            console.log('MAX DI EXCEDEED');
            alertify.alert("Maximum two patients allowed in DI.");
            return false;
        }else{
            // do remarks checking & popup
            remarksNeeded = true;

            // proceed to popup
            var url = a.context.attributes.pageLink.nodeValue;
            var pageTitle = a.context.attributes.pageTitle.nodeValue;
            $.ajax({
                type: 'GET',
                url: url,
                success: function (data) {
                    $('.modal-body').html(data);
                    $('.modal').modal('show');
                    $('#modalSize').addClass("modal-lg");
                    $('.modal-title').html(pageTitle);
                    // $('.modal-content').css({"width": "400px", "margin": "auto"});
                    // $('.modal-title').css({"font-size": "19px", "color": "#000"});

                    if(remarksNeeded){
                        if(totalDI>=1){
                            console.log('REMARKS needed');
                            $("#remarksAlert").show();
                            $("#remarksAlertVal").val(2);
                        }
                    }
                }
            });
        }

    }

    function getStatusPageForDO(a) {
        var TEA_BREAK = $('#TEA_BREAK').val();
        if ($('#TEA_BREAK').is(':checked')) {
            alertify.alert("Please, turn off prayer time first.");
            return false;
        }
        if ($('#REPORT_BREAK').is(':checked')) {
            alertify.alert("Please, turn off report view option first.");
            return false;
        }

        var url = a.context.attributes.pageLink.nodeValue;
        var pageTitle = a.context.attributes.pageTitle.nodeValue;
        $.ajax({
            type: 'GET',
            url: url,
            success: function (data) {
                $('.modal-body').html(data);
                $('.modal').modal('show');
                $('#modalSize').addClass("modal-lg");
                $('.modal-title').html(pageTitle);
                // $('.modal-content').css({"width": "400px", "margin": "auto"});
                // $('.modal-title').css({"font-size": "19px", "color": "#000"});
            }
        });
    }

    function getProfileUpdatePage(a){
        var url = a.context.attributes.pageLink.nodeValue;
        if(url!=''){
            $('.ajaxLoaderFormLoad').show();
            $.ajax({
                type: 'GET',
                url: url,
                success: function (data) {
                    $('.ajaxLoaderFormLoad').hide();
                    $('.modal').modal('show');
                    // $('#modalSize').addClass("modal-lg");
                    $('.modal-title').html(a.context.attributes.pagetitle.nodeValue);
                    $('.modal-body').html(data);
                }
            });
        }
    }

    $(document).ready(function () {
        $('#datatable12').DataTable({
            lengthMenu: [
                [50, 100, 200, -1],
                [50, 100, 200, 'All'],
            ],
        });
    });
</script>
<style>
.patientDataTable .btn{
    padding: 2px 4px !important;
    font-size: 13px !important;
}

/*.btnFollowup, .btnCreateFollowup, .btnProfile{
    padding: 2px 4px !important;
    font-size: 13px;
}*/
.btnCreateFollowup{
    background-color: #eeb60f;
    border-color: #eeb60f;
    color: #212529 !important;
}

.btnCP,.btnDI,.btnDO{
    width: 60px;
}
.btnCP, .btnCP:hover, .btnCP:focus, .btnCP:active{
    background-color: #B06FCF !important;
    border-color: #B06FCF !important;
}
.btnDI, .btnDI:hover, .btnDI:focus, .btnDI:active{
    background-color: #DAB600 !important;
    border-color: #DAB600 !important;
}
.btnDO, .btnDO:hover, .btnDO:focus, .btnDO:active {
    background-color: #82AB47 !important;
    border-color: #82AB47 !important;
}
</style>
