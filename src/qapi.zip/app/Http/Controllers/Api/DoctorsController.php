<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiResponseModel;

class DoctorsController extends Controller{

    public function getDoctorList(){
        $doctorList = [];
        
        $doctorList[0] = array(
            "id" => 1,
            "name" => "Dr Saklayen Russel",
            "short_info" => "MBBS (DMC), MS (CBTS)",
            "img_url" => url('/uploads/doctors/1.png'),
            "about" => "MBBS (DMC), MS (CBTS)",
        );
        
        $data = array(
            "doctor_list" => $doctorList
        );

        $result = new ApiResponseModel(true,"Doctor list Found",$data);
        return response()->json($result, 200);
    }

}

?>


