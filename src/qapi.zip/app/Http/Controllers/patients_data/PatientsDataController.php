<?php

namespace App\Http\Controllers\patients_data;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Session;
use Auth;
use PDF;
use App\Models\Settings;

class PatientsDataController extends Controller
{

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 18-10-2022
     * @target Patient's data list
     */
    public function patientData()
    {
        $header = array(
            'pageTitle' => 'Patient\'s Data',
            'tableTitle' => 'All patient List',
        );
        return view('patients_data.index', compact('header'));
    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 19-10-2022
     * @target Patient's data core list
     */
    public function searchPatientData($searchField = null)
    {
        $patients = [];

        // searhcing result
        if (!empty($searchField)) {
        } else {
            $cDate = date('Y-m-d');
            $patients = DB::select("select i.*, c.NAME CATEGORY_NAME
                FROM pat_patients_info i
                LEFT JOIN set_category c ON c.ID=i.CATEGORY_ID
                WHERE i.ACTIVE_STATUS=1 AND i.ENTRY_DATE='$cDate' order by ID ASC");
        }

        return view('patients_data.searchPatient', compact('patients'));
    }


    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 18-10-2022
     * @target Patient's data list
     */
    public function serialEntry()
    {
        $header = array(
            'pageTitle' => 'Serial Entry',
            'tableTitle' => 'All serial List',
        );
        return view('serial.index', compact('header'));
    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 19-10-2022
     * @target Patient's data core list
     */
    public function searchSerialEntry($searchField = null)
    {

        $patients = [];

        // searhcing result
        if (!empty($searchField)) {
        } else {
            $cDate = date('Y-m-d');
            $patients = DB::select("select i.*, c.NAME CATEGORY_NAME
                FROM pat_patients_info i
                LEFT JOIN set_category c ON c.ID=i.CATEGORY_ID
                WHERE i.ACTIVE_STATUS=1 AND i.ENTRY_DATE='$cDate' order by ID ASC");
        }

        return view('serial.searchSerial', compact('patients'));
    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 18-10-2022
     * @target Patient's data list
     */
    public function patientHistory()
    {
        $header = array(
            'pageTitle' => 'History',
            'tableTitle' => 'All patient List',
        );
        return view('history.index', compact('header'));
    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 19-10-2022
     * @target Patient's data core list
     */
    public function searchPatientHistory($searchFieldFrom = null, $searchFieldTo = null)
    {

        $patients = [];

        // searhcing result
        if ($searchFieldFrom && $searchFieldTo) {
            $fDate = date('Y-m-d', strtotime($searchFieldFrom));
            $tDate = date('Y-m-d', strtotime($searchFieldTo));
            $patients = DB::select("select i.*, c.NAME CATEGORY_NAME
                FROM pat_patients_info i
                LEFT JOIN set_category c ON c.ID=i.CATEGORY_ID
                WHERE i.ACTIVE_STATUS=1 AND i.PATIENT_STATUS=2 AND (i.ENTRY_DATE BETWEEN '$fDate' AND '$tDate')
                order by i.ENTRY_DATE ASC, ID ASC");
        } else {
            $cDate = date('Y-m-d');
            $patients = DB::select("select i.*, c.NAME CATEGORY_NAME
                FROM pat_patients_info i
                LEFT JOIN set_category c ON c.ID=i.CATEGORY_ID
                WHERE i.ACTIVE_STATUS=1 AND i.PATIENT_STATUS=2 order by i.ENTRY_DATE DESC");
        }

        return view('history.searchPatient', compact('patients'));
    }

    public function serialEntryPopup()
    {

        $header = array(
            'pageTitle' => 'Serial Entry',
            'tableTitle' => 'Serial Entry'
        );

        $categories = DB::table('set_category')
            ->where('ACTIVE_STATUS', 1)
            ->orderBy('ID', 'ASC')
            ->get();

        $depts = DB::table('sa_lookup_data as s')
            ->where('s.LOOKUP_GRP_ID', 5)
            ->select('s.LOOKUP_DATA_ID', 's.LOOKUP_DATA_NAME')
            ->where('s.ACTIVE_FLAG', 1)
            ->get();
        $doctors = DB::table('sa_lookup_data as s')
            ->where('s.LOOKUP_GRP_ID', 37)
            ->select('s.LOOKUP_DATA_ID', 's.LOOKUP_DATA_NAME')
            ->where('s.ACTIVE_FLAG', 1)
            ->get();
        $rooms = DB::table('sa_lookup_data as s')
            ->where('s.LOOKUP_GRP_ID', 36)
            ->select('s.LOOKUP_DATA_ID', 's.LOOKUP_DATA_NAME')
            ->where('s.ACTIVE_FLAG', 1)
            ->get();

        $cDate = date('Y-m-d');
        $slInfo = DB::selectOne("SELECT MAX(SL_NO) AS MAX_SL FROM pat_patients_info WHERE ENTRY_DATE='$cDate'");
        return view('patients_data.create_serial', compact('header', 'slInfo', 'categories', 'depts', 'doctors', 'rooms'));
    }

    public function storePatientSerial(Request $request)
    {

        $header = array(
            'pageTitle' => 'Serial Entry',
            'tableTitle' => 'Serial Entry'
        );

        if (!$request->SL_NO) {
            Session::flash('error', 'Serial can not be blank.');
        } else {
            $cDate = date('Y-m-d');
            $slInfo = DB::selectOne("SELECT MAX(SL_NO) AS MAX_SL FROM pat_patients_info WHERE ENTRY_DATE='$cDate'");
            $MX_SL = 0;
            if ($slInfo) {
                $MX_SL = $slInfo->MAX_SL + 1;
            } else {
                $MX_SL = $MX_SL + 1;
            }
            $patientData = array(
                "NAME"              => $request->NAME,
                "CATEGORY_ID"       => $request->CATEGORY_ID,
                // "DEPT_ID"           => $request->DEPT_ID,
                // "DOCTOR_ID"         => $request->DOCTOR_ID,
                // "ROOM_NO"           => $request->ROOM_NO,
                "SL_NO"             => $MX_SL,
                "ENTRY_DATE"        => $cDate,
                "PATIENT_STATUS"    => 0,
                "ACTIVE_STATUS"     => 1,
                "created_by"        => Auth::user()->id,
                "created_at"        => date('Y-m-d H:i:s'),
            );
            $patitentInfoID = DB::table('pat_patients_info')->insertGetId($patientData);
            if ($patitentInfoID) {
                Session::flash('success', 'Serial Info Saved Successfully!');
            }
        }
        $targetURL = $request->targetURL;
        return redirect()->route($targetURL);
    }

    public function updateSerialInfo($id = null)
    {

        $header = array(
            'pageTitle' => 'Update Patient Info',
            'tableTitle' => 'Update Patient Info'
        );

        $patientInfo = [];
        if ($id) {
            $patientInfo = DB::selectOne("select * from pat_patients_info where ID=$id");
        }
        return view('patients_data.update_serial', compact('header', 'patientInfo'));
    }

    public function storeUpdateSerial(Request $request)
    {

        $header = array(
            'pageTitle' => 'Update Patient Info',
            'tableTitle' => 'Update Patient Info'
        );

        $ID = $request->PATIENT_ROW_ID;
        $successPage = $request->successPage;
        if ($ID) {
            DB::table('pat_patients_info')
                ->where('ID', $ID)
                ->update(['name' => ($request->NAME) ? $request->NAME : null]);

            Session::flash('success', 'Name updated successfully.');
        } else {
            Session::flash('error', 'Name not saved.');
        }
        $targetURL = $request->targetURL;
        return redirect()->route($targetURL);
    }

    // Serial Entry Form @ 08-12-2022
    public function serialEntryForm()
    {
        $cDate = date('Y-m-d');

        $header = array(
            'pageTitle' => 'Serial Entry',
            'tableTitle' => 'Serial Entry'
        );

        $categories = DB::table('set_category')
            ->where('ACTIVE_STATUS', 1)
            ->orderBy('ID', 'ASC')
            ->get();

        $depts = DB::table('sa_lookup_data as s')
            ->where('s.LOOKUP_GRP_ID', 5)
            ->select('s.LOOKUP_DATA_ID', 's.LOOKUP_DATA_NAME')
            ->where('s.ACTIVE_FLAG', 1)
            ->get();
        $doctors = DB::table('sa_lookup_data as s')
            ->where('s.LOOKUP_GRP_ID', 37)
            ->select('s.LOOKUP_DATA_ID', 's.LOOKUP_DATA_NAME')
            ->where('s.ACTIVE_FLAG', 1)
            ->get();
        $rooms = DB::table('sa_lookup_data as s')
            ->where('s.LOOKUP_GRP_ID', 36)
            ->select('s.LOOKUP_DATA_ID', 's.LOOKUP_DATA_NAME')
            ->where('s.ACTIVE_FLAG', 1)
            ->get();
        $patientAppointments = DB::table('pat_appoint_info')
            ->where('APPOINTMENT_STATUS', '=', 3)
            ->where('START_TIME', '=', $cDate)
            ->orderBy('ID', 'DESC')
            ->get();

        // var_dump($patientAppointments);exit;
        $slInfo = DB::selectOne("SELECT MAX(SL_NO) AS MAX_SL FROM pat_patients_info WHERE ENTRY_DATE='$cDate'");
        return view('patients_data.serial_entry_form', compact('patientAppointments', 'header', 'slInfo', 'categories', 'depts', 'doctors', 'rooms'));
    }


    public function storePatientSerialAction(Request $request)
    {

        $header = array(
            'pageTitle' => 'Serial Entry',
            'tableTitle' => 'Serial Entry'
        );

        if (!$request->SL_NO) {
            Session::flash('error', 'Serial can not be blank.');
        } else {
            $cDate = date('Y-m-d');
            $slInfo = DB::selectOne("SELECT MAX(SL_NO) AS MAX_SL FROM pat_patients_info WHERE ENTRY_DATE='$cDate'");
            $MX_SL = 0;
            if ($slInfo) {
                $MX_SL = $slInfo->MAX_SL + 1;
            } else {
                $MX_SL = $MX_SL + 1;
            }
            $patientData = array(
                "NAME"              => $request->NAME,
                "CATEGORY_ID"       => $request->CATEGORY_ID,
                // "DEPT_ID"           => $request->DEPT_ID,
                // "DOCTOR_ID"         => $request->DOCTOR_ID,
                // "ROOM_NO"           => $request->ROOM_NO,
                "SL_NO"             => $MX_SL,
                "ENTRY_DATE"        => $cDate,
                "PATIENT_STATUS"    => 0,
                "ACTIVE_STATUS"     => 1,
                "created_by"        => Auth::user()->id,
                "created_at"        => date('Y-m-d H:i:s'),
            );
            $patitentInfoID = DB::table('pat_patients_info')->insertGetId($patientData);
            if ($patitentInfoID) {
                Session::flash('success', 'Serial Info Saved Successfully!');
            }
        }
        return redirect()->route('serialEntryForm');
    }

    public function viewStatus($id = null, $status = null)
    {
        $header = array(
            'pageTitle' => 'Change Status',
            'tableTitle' => 'Change Status',
        );
        if (!$id) {
            echo 'Status data not found.';
            exit;
        }
        return view('patients_data.change_status', compact('header', 'id', 'status'));
    }

    public function changeStatus(Request $request)
    {
        $id = $request->ID;
        $status = $request->PATIENT_STATUS;
        if (!$id) {
            Session::flash('error', 'Status data not found.');
        } else {
            if ($status == 1) {
                $info = [
                    'PATIENT_STATUS' => $request->PATIENT_STATUS,
                    'REMARKS_OK'     => ($request->REMARKS_OK) ? $request->REMARKS_OK : null,
                    'REMARKS'        => ($request->REMARKS_OK) ? $request->REMARKS : null,
                    'START_TIME'     => date('Y-m-d H:i:s')
                ];
            } else {
                $info = [
                    'PATIENT_STATUS' => $request->PATIENT_STATUS,
                    'START_TIME'     => date('Y-m-d H:i:s')
                ];
            }
            DB::table('pat_patients_info')
                ->where('ID', $id)
                ->update($info);

            Session::flash('success', 'Status changed successfully.');
        }
        $targetURL = $request->targetURL;
        return redirect()->route($targetURL);
    }

    // Change status from DI to DO
    public function viewStatusDO($id = null, $status = null)
    {
        $header = array(
            'pageTitle' => 'Change Status',
            'tableTitle' => 'Change Status',
        );
        if (!$id) {
            echo 'Status data not found.';
            exit;
        }
        return view('patients_data.change_status_do', compact('header', 'id', 'status'));
    }

    // Change status from DI to DO - Action
    public function changeStatusDO(Request $request)
    {
        $id = $request->ID;
        $status = $request->PATIENT_STATUS;
        if (!$id) {
            Session::flash('error', 'Status data not found.');
        } else {
            if ($status == 1) {
                $info = [
                    'PATIENT_STATUS' => $request->PATIENT_STATUS,
                    'REMARKS_OK'     => ($request->REMARKS_OK) ? $request->REMARKS_OK : null,
                    'REMARKS'        => ($request->REMARKS_OK) ? $request->REMARKS : null,
                    'END_TIME'       => date('Y-m-d H:i:s')
                ];
            } else {
                $info = [
                    'PATIENT_STATUS' => $request->PATIENT_STATUS,
                    'END_TIME'       => date('Y-m-d H:i:s')
                ];
            }
            DB::table('pat_patients_info')
                ->where('ID', $id)
                ->update($info);

            Session::flash('success', 'Status changed successfully.');
        }
        $targetURL = $request->targetURL;
        return redirect()->route($targetURL);
    }

    public function cancelSerial($id = null)
    {

        $header = array(
            'pageTitle' => 'Cancel Serial',
            'tableTitle' => 'Cancel Serial'
        );

        if (!$id) {
            Session::flash('error', 'Serial not found.');
        } else {
            DB::table('pat_patients_info')
                ->where('ID', $id)
                ->update(['PATIENT_STATUS' => 3]);
            Session::flash('success', 'Serial cancelled successfully.');
        }
        return redirect()->route('serialEntry');
    }

    // Set break time status @ 28-11-2022 by Salaquzzaman <salaquzzaman@atilimited.net>
    public function setBreakTime($text = null, $value = null)
    {
        $result = 0;
        if ($text) {
            $exe = DB::table('settings')
                ->where('NAME', $text)
                ->update(['VALUE' => $value]);
            if ($exe) {
                $result = $value;
            }
        }
        return $result;
    }

    // Set report time status @ 02-01-2023 by Salaquzzaman <salaquzzaman@atilimited.net>
    public function setReportTime($text = null, $value = null)
    {
        $result = 0;
        if ($text) {
            $exe = DB::table('settings')
                ->where('NAME', $text)
                ->update(['VALUE' => $value]);
            if ($exe) {
                $result = $value;
            }
        }
        return $result;
    }

    // Get Current Data for HOMEPAGE @ 28-11-2022 by Salaquzzaman <salaquzzaman@atilimited.net>
    public function getCurrentData()
    {
        $cDate = date('Y-m-d');
        $info = DB::select("SELECT SL_NO, REMARKS FROM pat_patients_info WHERE ENTRY_DATE='$cDate'
            AND PATIENT_STATUS=1 ORDER BY SL_NO");
        $sl = '';
        $remarks = '';
        if ($info) {
            $sl = $info[0]->SL_NO;
            $remarks = $info[0]->REMARKS;
        }

        $flag = 0;
        $settings = new Settings();
        $flag = $settings->getValOfSettings('TEA_BREAK');

        return [
            "sl" => $sl,
            "slLength" => strlen($sl),
            "remarks" => $remarks,
            "teaBreak" => $flag
        ];
    }

    // Get Current Data(patient list) for HOMEPAGE @ 28-11-2022 by Salaquzzaman <salaquzzaman@atilimited.net>
    public function getCurrentList()
    {
        $cDate = date('Y-m-d');
        $res = '';
        $info = DB::select("select i.SL_NO, i.NAME, i.REMARKS, c.LOOKUP_DATA_NAME CATEGORY, r.LOOKUP_DATA_NAME ROOM_NO
            FROM pat_patients_info i
            LEFT JOIN sa_lookup_data c ON c.LOOKUP_DATA_ID=i.CATEGORY_ID
            LEFT JOIN sa_lookup_data r ON r.LOOKUP_DATA_ID=i.ROOM_NO
            WHERE ENTRY_DATE='$cDate' AND i.PATIENT_STATUS!=2 AND i.NAME!=''
            AND i.ACTIVE_STATUS=1 ORDER BY SL_NO");

        if ($info) {
            $res .= '<table id="patientTable">';
            $res .= '<tr>
                    <th>Sl</th>
                    <th>Patient Name</th>
                    <th>Room no</th>
                </tr>';
            foreach ($info as $row) {
                $res .= '<tr>
                    <td>' . $row->SL_NO . '</td>
                    <td>' . $row->NAME . '</td>
                    <td>' . $row->ROOM_NO . '</td>
                    </tr>';
            }
            $res .= '</table>';
        }
        return $res;
    }


    public function patientSummary()
    {
        $header = array(
            'pageTitle' => 'Summary',
            'tableTitle' => 'All patient List',
        );
        return view('summary.index', compact('header'));
    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 19-10-2022
     * @target Patient's data core list
     */
    public function searchPatientSummary($searchFieldFrom = null, $searchFieldTo = null)
    {
        // echo 'check';exit;

        $patients = [];

        // searhcing result
        if ($searchFieldFrom && $searchFieldTo) {
            $fDate = date('Y-m-d', strtotime($searchFieldFrom));
            $tDate = date('Y-m-d', strtotime($searchFieldTo));
            $patients = DB::select("select i.*, c.NAME CATEGORY_NAME
                FROM pat_patients_info i
                LEFT JOIN set_category c ON c.ID=i.CATEGORY_ID
                WHERE i.ACTIVE_STATUS=1 AND i.PATIENT_STATUS=2 AND (i.ENTRY_DATE BETWEEN '$fDate' AND '$tDate')
                order by i.ENTRY_DATE ASC, ID ASC");
        } else {
            $cDate = date('Y-m-d');
            $patients = DB::select("select i.*, c.NAME CATEGORY_NAME
                FROM pat_patients_info i
                LEFT JOIN set_category c ON c.ID=i.CATEGORY_ID
                WHERE i.ACTIVE_STATUS=1 AND i.PATIENT_STATUS=2 order by i.ENTRY_DATE DESC");
        }
        // dd($patients);
        return view('summary.searchPatient', compact('patients'));
    }

    public function registeredPatientData()
    {
        $header = array(
            'pageTitle' => 'Registered Patients',
            'tableTitle' => 'Registered Patient List'

        );

        $results = DB::table('pat_appoint_info as a')
            ->select('a.*', 'b.NAME as USERNAME')
            ->leftJoin('pat_patients_info as b', 'b.ID', '=', 'a.PATIENT_ID')
            ->where('a.APPOINTMENT_STATUS', '<', 3)
            ->orderBy('ID', 'DESC')
            ->get();



        return view('setup.registeredPatient.index', compact('header', 'results'));
    }

    public function searchregisteredPatientData(Request $request)
    {
        $from_date = $request->input('FROM_DATE');
        $to_date = $request->input('TO_DATE');

        $results = DB::table('pat_appoint_info as a')
            ->select('a.*', 'b.NAME as USERNAME')
            ->leftJoin('pat_patients_info as b', 'b.ID', '=', 'a.PATIENT_ID')
            ->where('a.APPOINTMENT_STATUS', '<', 3)
            ->whereBetween('a.created_at', [$from_date, $to_date])
            ->orderBy('ID', 'DESC')
            ->get();

        return response()->json($results);
    }

    public function editRegisteredPatient($id)
    {
        $header = array(
            'pageTitle' => 'Registered Patient Edit',
            'tableTitle' => 'Registered Patient Edit'

        );
        if (!$id) {
            Session::flash('error', 'Data not found.');
            return redirect()->route('categorySetup');
        }


        $appointment = DB::table('pat_appoint_info')->where('ID', $id)->first();
        $attachments = DB::table('pat_docu_info')->where('APPOINTMENT_ID', $id)->get();
        return view('setup.registeredPatient.update', compact('header', 'appointment', 'attachments'));
    }


    public function approveAppointment(Request $request)
    {
        if ($request->button_clicked == 'approve') {
            DB::table('pat_appoint_info')->where('ID', '=', $request->APPOINTMENT_ID)->update([
                'APPOINTMENT_STATUS' => 2,
            ]);
        } else {
            DB::table('pat_appoint_info')->where('ID', '=', $request->APPOINTMENT_ID)->update([
                'APPOINTMENT_STATUS' => 0,
            ]);
        }
        return redirect()->back();
    }

    public function scheduleAppointmentData()
    {
        $header = array(
            'pageTitle' => 'Appointments',
            'tableTitle' => 'Appointments List'

        );

        $results = DB::table('pat_appoint_info as a')
            ->select('a.*', 'b.NAME as USERNAME')
            ->leftJoin('pat_patients_info as b', 'b.ID', '=', 'a.PATIENT_ID')
            ->where('a.APPOINTMENT_STATUS', '<', 4)
            ->where('a.APPOINTMENT_STATUS', '>', 1)
            ->orderBy('ID', 'DESC')
            ->get();

        // $results = DB::table('pat_appoint_info')
        //     ->where('APPOINTMENT_STATUS',2)
        //     ->orderBy('ID','DESC')
        //     ->get();

        return view('setup.approveAppointments.index', compact('header', 'results'));
    }

    public function editAppointment($id)
    {
        $header = array(
            'pageTitle' => 'Registered Patient Edit',
            'tableTitle' => 'Registered Patient Edit'

        );
        if (!$id) {
            Session::flash('error', 'Data not found.');
            return redirect()->route('categorySetup');
        }


        $appointment = DB::table('pat_appoint_info')->where('ID', $id)->first();
        $attachments = DB::table('pat_docu_info')->where('APPOINTMENT_ID', $id)->get();
        $appointmentTimes = DB::table('appointment_schedule_setup')->get();
        // dd($appointment);
        return view('setup.approveAppointments.update', compact('header', 'appointment', 'attachments', 'appointmentTimes'));
    }

    public function scheduleAppointment(Request $request)
    {
        // dd($request->all());
        $cDate = date('Y-m-d');
        if ($request->button_clicked == 'reject') {
            DB::table('pat_appoint_info')->where('ID', '=', $request->APPOINTMENT_ID)->update([
                'APPOINTMENT_STATUS' => 0,
            ]);
        } else {
            DB::table('pat_appoint_info')->where('ID', '=', $request->APPOINTMENT_ID)->update([
                'SCHEDULE_ID' => $request->SCHEDULE_TIME,
                'START_TIME' => $cDate,
                'APPOINTMENT_STATUS' => 3,
            ]);

            // $patSchedule = DB::table('appointment_schedule_setup')->where('ID', '=', $request->SCHEDULE_TIME)->first();
            // $patScheduleCount = $patSchedule->PAT_COUNT;
            // if (isset($patSchedule) && isset($patSchedule->PAT_COUNT)) {
            //     $patScheduleCoun = $patScheduleCount + 1;
            // } else {
            //     $patScheduleCoun = 0;
            // }

            // DB::table('appointment_schedule_setup')->where('ID', '=', $request->SCHEDULE_TIME)->update([
            //     'PAT_COUNT' => $patScheduleCount + 1,
            // ]);

            DB::table('appointment_schedule_details')->insert([
                'SCHEDULE_ID' => $request->SCHEDULE_TIME,
                'PA_APPOI_ID' => $request->APPOINTMENT_ID,
                'PATIENT_ID' => $request->PATIENT_ID,
                'START_TIME' => $request->START_TIME,
                'END_TIME' => $request->END_TIME,
                'APPOINTMENT_DATE' => $cDate,
                'ENTRY_BY' => auth()->user()->id,
                'ENTRY_DATE' => $cDate,
                // 'UPDATE_BY' => $request->UPDATE_BY,
                // 'UPDATE_DATE' => $request->UPDATE_DATE,
            ]);

        }
        return redirect()->back();
    }

    public function getPatientSuggestions($query)
    {
        $patientAppointments = DB::table('pat_appoint_info as s')
            ->where('s.APPOINTMENT_STATUS', 3)
            ->get();

        return response()->json($doctors);
    }

    public function approvePatientAppointment(Request $request)
    {
        // echo 'check';exit;

        $patients = [];

        // searhcing result
        if ($searchFieldFrom && $searchFieldTo) {
            $fDate = date('Y-m-d', strtotime($searchFieldFrom));
            $tDate = date('Y-m-d', strtotime($searchFieldTo));
            $patients = DB::select("select i.*, c.NAME CATEGORY_NAME
                FROM pat_patients_info i
                LEFT JOIN set_category c ON c.ID=i.CATEGORY_ID
                WHERE i.ACTIVE_STATUS=1 AND i.PATIENT_STATUS=2 AND (i.ENTRY_DATE BETWEEN '$fDate' AND '$tDate')
                order by i.ENTRY_DATE ASC, ID ASC");
        } else {
            $cDate = date('Y-m-d');
            $patients = DB::select("select i.*, c.NAME CATEGORY_NAME
                FROM pat_patients_info i
                LEFT JOIN set_category c ON c.ID=i.CATEGORY_ID
                WHERE i.ACTIVE_STATUS=1 AND i.PATIENT_STATUS=2 order by i.ENTRY_DATE DESC");
        }
        // dd($patients);
        return view('summary.searchPatient', compact('patients'));
    }
}
