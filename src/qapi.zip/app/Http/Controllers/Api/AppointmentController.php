<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiResponseModel;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\PatientInfo;
use Auth;
use DB;
use Exception;
use Illuminate\Database\QueryException;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Mail;

class AppointmentController extends Controller
{


    public function takeAppointment(Request $request)
    {
        $validatedData = $request->validate([
            'relation' => ['required'],
        ]);

        $userId = Auth::user()->id;
        $folderPath = "appointmentImages/patient/";
        $relation = $request->relation;
        $appointStatus = 0;
        $userInfo = DB::table('users')->where('id', '=', $userId)->first();

        if($relation == "self"){
            $patientInfo = DB::table('pat_patients_info')->where('MOBILE_NO', '=', $userInfo->contact_no)->first();
            $name = $patientInfo->NAME;
            $gender = $patientInfo->GENDER;
            $age = $patientInfo->AGE;
            $mobile = $patientInfo->MOBILE_NO;
            $maxAppointmentId = DB::table('pat_appoint_info')->max('ID');
            $maxAppointmentSl = DB::table('pat_appoint_info')->max('SL_NO');

            if(!isset($maxAppointmentId)){
                $maxAppointmentId = 0;
            }
            if(!isset($maxAppointmentSl)){
                $maxAppointmentSl = 0;
            }

            // Check if there exists any image or the description of the appointment. If there is then an appointment is created
            if($request->hasFile('image1') || $request->hasFile('image2') || $request->hasFile('image3') || isset($request->description)){
                $patientAppoint = DB::table('pat_appoint_info')->insert([
                    'ID' => $maxAppointmentId + 1,
                    'PATIENT_ID' => $patientInfo->ID,
                    'SL_NO' => $maxAppointmentSl + 1,
                    'NAME' => $name,
                    'APPOINTMENT_STATUS' => 1,
                    'GENDER' => $gender,
                    'AGE' => $age,
                    'DESCRIPTION' => $request->description,
                    'ACTIVE_STATUS' => 1,
                    'MOBILE_NO' => $mobile,
                    'ENTRY_DATE' => date('Y-m-d H:i:s'),
                    'created_by' => $userId,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            $maxId = DB::table('pat_appoint_info')->max('ID');
            

            if(isset($patientAppoint)){

                if ($request->hasFile('image1')) {
                    $photo = $request->file('image1');
                    $name = '';
                    $ext = '';
                    $ext = strtolower($photo->getClientOriginalExtension());
                    $name = strtolower(date('Y-m-d') . "_" . mt_rand(111111, 999999) . '.' . $ext);
                    $photo->move($folderPath, $name);
                    $photoName = $name;


                    $patientDocu = DB::table('pat_docu_info')->insert([
                        'APPOINTMENT_ID' => $maxId,
                        'documents_image' => $photoName,
                        'ACTIVE_STATUS' => 1,
                        'created_by' => $userId,
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);
                }

                if ($request->hasFile('image2')) {
                    $photo = $request->file('image2');
                    $name = '';
                    $ext = '';
                    $ext = strtolower($photo->getClientOriginalExtension());
                    $name = strtolower(date('Y-m-d') . "_" . mt_rand(111111, 999999) . '.' . $ext);
                    $photo->move($folderPath, $name);
                    $photoName = $name;


                    $patientDocu = DB::table('pat_docu_info')->insert([
                        'APPOINTMENT_ID' => $maxId,
                        'documents_image' => $photoName,
                        'ACTIVE_STATUS' => 1,
                        'created_by' => $userId,
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);
                }

                if ($request->hasFile('image3')) {
                    $photo = $request->file('image3');
                    $name = '';
                    $ext = '';
                    $ext = strtolower($photo->getClientOriginalExtension());
                    $name = strtolower(date('Y-m-d') . "_" . mt_rand(111111, 999999) . '.' . $ext);
                    $photo->move($folderPath, $name);
                    $photoName = $name;


                    $patientDocu = DB::table('pat_docu_info')->insert([
                        'APPOINTMENT_ID' => $maxId,
                        'documents_image' => $photoName,
                        'ACTIVE_STATUS' => 1,
                        'created_by' => $userId,
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);
                }
                $appointStatus = 1;
                $result = new ApiResponseModel(true, "Appointment created successfully !!");
                return response()->json($result, 200);
            }else{
                $result = new ApiResponseModel(true, "Appointment create unsuccessful !!");
                return response()->json($result, 500);
            }
        }else{
            // Validate Relation*, Name*, Sex*, Age*
            $validatedData = $request->validate([
                'relation' => ['required'],
                'name' => ['required'],
                'gender' => ['required'],
                'age' => ['required', 'numeric'],
                'image1' => ['required_without_all:image2,image3,description'],
                'image2' => ['required_without_all:image1,image3,description'],
                'image3' => ['required_without_all:image1,image2,description'],
                'description' => ['required_without_all:image1,image2,image3'],
            ]);

            $patientInfo = DB::table('pat_patients_info')->where('MOBILE_NO', '=', $userInfo->contact_no)->first();
            $mobile = $patientInfo->MOBILE_NO;
            $maxAppointmentId = DB::table('pat_appoint_info')->max('ID');
            $maxAppointmentSl = DB::table('pat_appoint_info')->max('SL_NO');
            

            if(!isset($maxAppointmentId)){
                $maxAppointmentId = 0;
            }
            if(!isset($maxAppointmentSl)){
                $maxAppointmentSl = 0;
            }

            if($request->hasFile('image1') || $request->hasFile('image2') || $request->hasFile('image3') || isset($request->description)){
                $patientAppoint = DB::table('pat_appoint_info')->insert([
                    'ID' => $maxAppointmentId + 1,
                    'PATIENT_ID' => $patientInfo->ID,
                    'SL_NO' => $maxAppointmentSl + 1,
                    'NAME' => $request->name,
                    'APPOINTMENT_STATUS' => 1,
                    'GENDER' => $request->sex,
                    'AGE' => $request->age,
                    'ACTIVE_STATUS' => 1,
                    'MOBILE_NO' => $mobile,
                    'ENTRY_DATE' => date('Y-m-d H:i:s'),
                    'created_by' => $userId,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }
            $maxId = DB::table('pat_appoint_info')->max('ID');
            

            if(isset($patientAppoint)){

                if ($request->hasFile('image1')) {
                    $photo = $request->file('image1');
                    $name = '';
                    $ext = '';
                    $ext = strtolower($photo->getClientOriginalExtension());
                    $name = strtolower(date('Y-m-d') . "_" . mt_rand(111111, 999999) . '.' . $ext);
                    $photo->move($folderPath, $name);
                    $photoName = $name;


                    $patientDocu = DB::table('pat_docu_info')->insert([
                        'APPOINTMENT_ID' => $maxId,
                        'PATIENT_ID' => $patientInfo->ID,
                        'documents_image' => $photoName,
                        'ACTIVE_STATUS' => 1,
                        'created_by' => $userId,
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);
                }

                if ($request->hasFile('image2')) {
                    $photo = $request->file('image2');
                    $name = '';
                    $ext = '';
                    $ext = strtolower($photo->getClientOriginalExtension());
                    $name = strtolower(date('Y-m-d') . "_" . mt_rand(111111, 999999) . '.' . $ext);
                    $photo->move($folderPath, $name);
                    $photoName = $name;


                    $patientDocu = DB::table('pat_docu_info')->insert([
                        'APPOINTMENT_ID' => $maxId,
                        'PATIENT_ID' => $patientInfo->ID,
                        'documents_image' => $photoName,
                        'ACTIVE_STATUS' => 1,
                        'created_by' => $userId,
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);
                }

                if ($request->hasFile('image3')) {
                    $photo = $request->file('image3');
                    $name = '';
                    $ext = '';
                    $ext = strtolower($photo->getClientOriginalExtension());
                    $name = strtolower(date('Y-m-d') . "_" . mt_rand(111111, 999999) . '.' . $ext);
                    $photo->move($folderPath, $name);
                    $photoName = $name;


                    $patientDocu = DB::table('pat_docu_info')->insert([
                        'APPOINTMENT_ID' => $maxId,
                        'PATIENT_ID' => $patientInfo->ID,
                        'documents_image' => $photoName,
                        'ACTIVE_STATUS' => 1,
                        'created_by' => $userId,
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);
                }
                $appointStatus = 1;
                $result = new ApiResponseModel(true, "Appointment created successfully !!");
                return response()->json($result, 200);
            }else{
                $result = new ApiResponseModel(true, "Appointment create unsuccessful !!");
                return response()->json($result, 500);
            }

        }
    }
}
