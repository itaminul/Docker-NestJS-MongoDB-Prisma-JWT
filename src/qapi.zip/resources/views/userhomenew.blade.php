<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Queue</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Styles -->
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Nunito', sans-serif;
            background-color: white;
            color: black;
            position: relative;
            min-height: 100vh;
        }

        .marquee-container {
            display: flex;
            align-items: center;
            padding: 6px 10px;
            font-size: 1.25rem;
            /* margin-top: 10px;
            border-top: solid 2px black;
            border-bottom: solid 2px black;
            color: black; */
            background-color: #595959;
            color: white;
        }

        marquee {
            white-space: pre-wrap;
            /* color: #ff1a1a; */
        }

        .container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px
        }

        .patient-container {
            /* padding: 5%; */
            /* height: 85vh; */
            /* display: flex;
            flex-direction: column;
            justify-content: space-around; */
            font-size: 1.25rem;
            padding: 0 5%;
        }

        /* .patient-and-room {
            display: flex;
            justify-content: space-between;
            border-bottom: solid 1px;
        } */

        table {
            height: calc(100vh - 140px);
            margin-top: 20px;
            /* text-align: center; */
            width: 100%;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
            border-collapse: collapse;
        }

        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        table td {
            padding: 0 1rem;
        }

        .time-date-container {
            display: flex;
            justify-content: space-around;
            font-family: 'Orbitron', sans-serif;
            padding: 20px 0;
            font-size: 2rem;
            color: red;
            font-weight: 500;
            /* text-shadow: 1px 1px 1px white; */
            /* text-shadow: 0px 0px 14px rgba(255, 0, 0, 0.7); */
        }

        .block-container {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 70vh;
        }

        .animated-box {
            /* padding: 30px; */
            text-align: center;
            border-radius: 4px;
            padding: 2rem 4rem;
        }

        .current-serial {
            font-size: 2.5rem;
            text-transform: uppercase;
            margin: 0;
            color: #ff1a1a;
        }

        /* The animation starts here */
        .animated-box {
            position: relative;
        }

        .animated-box:after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: 4px;
            background: rgb(0, 136, 255);
            background: linear-gradient(-225deg,
                    #231557 0%,
                    #44107a 29%,
                    #ff1361 67%,
                    #fff800 100%);
            /* background: linear-gradient(120deg, #00F260, #0575E6, #00F260); */
            background-size: 300% 300%;
            clip-path: polygon(0% 100%, 6px 100%, 6px 6px, calc(100% - 6px) 6px, calc(100% - 6px) calc(100% - 6px), 6px calc(100% - 6px), 6px 100%, 100% 100%, 100% 0%, 0% 0%);
        }

        .animated-box.in:after {
            animation: frame-enter 1s forwards ease-in-out reverse, gradient-animation 3s ease-in-out infinite;
        }

        /* motion */
        @keyframes gradient-animation {
            0% {
                background-position: 15% 0%;
            }

            50% {
                background-position: 85% 100%;
            }

            100% {
                background-position: 15% 0%;
            }
        }

        @keyframes frame-enter {
            0% {
                clip-path: polygon(0% 100%, 6px 100%, 6px 6px, calc(100% - 6px) 6px, calc(100% - 6px) calc(100% - 6px), 6px calc(100% - 6px), 6px 100%, 100% 100%, 100% 0%, 0% 0%);
            }

            25% {
                clip-path: polygon(0% 100%, 6px 100%, 6px 6px, calc(100% - 6px) 6px, calc(100% - 6px) calc(100% - 6px), calc(100% - 6px) calc(100% - 6px), calc(100% - 6px) 100%, 100% 100%, 100% 0%, 0% 0%);
            }

            50% {
                clip-path: polygon(0% 100%, 6px 100%, 6px 6px, calc(100% - 6px) 6px, calc(100% - 6px) 6px, calc(100% - 6px) 6px, calc(100% - 6px) 6px, calc(100% - 6px) 6px, 100% 0%, 0% 0%);
            }

            75% {
                -webkit-clip-path: polygon(0% 100%, 6px 100%, 6px 6px, 6px 6px, 6px 6px, 6px 6px, 6px 6px, 6px 6px, 6px 0%, 0% 0%);
            }

            100% {
                -webkit-clip-path: polygon(0% 100%, 6px 100%, 6px 100%, 6px 100%, 6px 100%, 6px 100%, 6px 100%, 6px 100%, 6px 100%, 0% 100%);
            }
        }

        #text3d {
            color: #70869d;
            font-size: 12rem;
            padding: 0;
            margin: 0;
            /* letter-spacing: .15em; */
            text-shadow:
                -1px -1px 1px #efede3,
                0px 1px 0 #2e2e2e,
                0px 2px 0 #2c2c2c,
                0px 3px 0 #2a2a2a,
                0px 4px 0 #282828,
                0px 5px 0 #262626,
                0px 6px 0 #242424,
                0px 7px 0 #222,
                0px 8px 0 #202020,
                0px 9px 0 #1e1e1e,
                0px 10px 0 #1c1c1c,
                0px 11px 0 #1a1a1a,
                0px 12px 0 #181818,
                0px 13px 0 #161616,
                0px 14px 0 #141414,
                0px 15px 0 #121212,
                2px 20px 5px rgba(0, 0, 0, 0.9),
                5px 23px 5px rgba(0, 0, 0, 0.3),
                8px 27px 8px rgba(0, 0, 0, 0.5),
                8px 28px 35px rgba(0, 0, 0, 0.9);

            animation: floating-text 1.25s ease-in-out alternate infinite;
        }

        @keyframes floating-text {
            0% {
                -webkit-transform: translateY(0.1em);
            }

            100% {}
        }

        .animate-charcter {
            text-transform: uppercase;
            background-image: linear-gradient(-225deg,
                    #231557 0%,
                    #44107a 29%,
                    #ff1361 67%,
                    #fff800 100%);
            background-size: auto auto;
            background-clip: border-box;
            background-size: 200% auto;
            color: #fff;
            background-clip: text;
            text-fill-color: transparent;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: textclip 4s linear infinite;
            display: inline-block;
            font-size: 6rem;
            margin: 0.5rem 0;
        }

        @keyframes textclip {
            to {
                background-position: 200% center;
            }
        }

        footer {
            background-color: #191919;
            color: white;
            position: absolute;
            bottom: 0;
            width: 100%;
            /* padding: 15px 0; */
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        footer p {
            margin: 0;
            padding: 10px;
        }

        footer img {
            max-height: 26px;
        }

        /* Media Query for Bigger Screens  */

        @media screen and (min-width: 1380px) {
            marquee {
                font-size: 1.25rem;
            }

            table {
                font-size: 1.625rem;
            }

            .time-date-container {
                font-size: 2.5rem;
            }

            .current-serial {
                font-size: 2.825rem;
            }

            #text3d {
                font-size: 15rem;
            }

            .animate-charcter {
                font-size: 8rem;
            }

            .marquee-container {
                font-size: 1.5rem;
            }

            footer {
                font-size: 1.5rem;
            }

        }
    </style>
</head>

<body>
    <div class="marquee-container">
        <marquee> হাত ধুই মাস্ক পড়ি, করোনা থেকে দূরে থাকি </marquee>
    </div>
    <div class="container">
        <div class="patient-container">
            <table>
                <tr>
                    <th>Sl</th>
                    <th>Patient Name</th>
                    <th>Room no</th>
                </tr>

                <tr>
                    <td>1</td>
                    <td>Obaidul Quader Chowdhury</td>
                    <td>403</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Obaidul Quader Chowdhury</td>
                    <td>403</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Obaidul Quader Chowdhury</td>
                    <td>403</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Obaidul Quader Chowdhury</td>
                    <td>403</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Obaidul Quader Chowdhury</td>
                    <td>403</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Obaidul Quader Chowdhury</td>
                    <td>403</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Obaidul Quader Chowdhury</td>
                    <td>403</td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>Obaidul Quader Chowdhury</td>
                    <td>403</td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>Obaidul Quader Chowdhury</td>
                    <td>403</td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>Obaidul Quader Chowdhury</td>
                    <td>403</td>
                </tr>
            </table>
        </div>
        <div class="time-serial-container">
            <div class="time-date-container">
                <div id="date" class="date" onload="showDate()"></div>
                <div id="time" class="clock" onload="showTime()"></div>
            </div>
            <div class="block-container">
                <div class="animated-box in">
                    <!-- <h1 class="current-serial">Current Serial : </h1>
                    <h1 id="text3d">27</h1> -->

                    <h3 class="animate-charcter">Break<br>Time</h3>

                </div>
            </div>
        </div>
    </div>

    <footer>
        <p> Designed and Developed by </p>
        <img src="{{asset('/images/ati-logo.png')}}" alt="" srcset="">
    </footer>


    <script>
        function showDate() {
            var d = new Date(Date.now());
            d = d.toLocaleString('en-US', {
                day: 'numeric',
                month: 'short',
                year: 'numeric'
            });

            document.getElementById("date").innerText = d;
            document.getElementById("date").textContent = d;
        }

        function showTime() {
            var date = new Date();
            var h = date.getHours(); // 0 - 23
            var m = date.getMinutes(); // 0 - 59
            var s = date.getSeconds(); // 0 - 59
            var session = "AM";

            if (h == 0) {
                h = 12;
            }

            if (h > 12) {
                h = h - 12;
                session = "PM";
            }

            h = (h < 10) ? "0" + h : h;
            m = (m < 10) ? "0" + m : m;
            s = (s < 10) ? "0" + s : s;

            var time = h + ":" + m + ":" + s + " " + session;
            document.getElementById("time").innerText = time;
            document.getElementById("time").textContent = time;
            setTimeout(showTime, 1000);
        }

        showDate();
        showTime();
    </script>

</body>

</html>