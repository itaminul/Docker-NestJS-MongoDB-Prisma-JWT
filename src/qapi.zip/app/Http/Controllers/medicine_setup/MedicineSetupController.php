<?php

namespace App\Http\Controllers\medicine_setup;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Session;
use Auth;

class MedicineSetupController extends Controller
{

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 06-11-2022
     * @target Medicine Setup
     */
    public function medicineIndex(){
        $header = array(
            'pageTitle' => 'Medicine Data',
            'tableTitle' => 'All medicine List',
        );
        $medicines = DB::select("select m.ID, m.MEDICINE, c.CATEGORY_NAME, c.SHORT_NAME
            FROM pat_hf_med_list m
            LEFT JOIN pat_hf_med_category c ON m.CATEGORY_ID=c.ID
            WHERE m.ACTIVE_STATUS=1
            ORDER BY c.SORT_NO ASC");
        return view('medicine_setup.index',compact('header','medicines'));
    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 06-11-2022
     * @target Medicine Create
     */
    public function createMedicine(){
        $categories = DB::select("select ID, CATEGORY_NAME FROM pat_hf_med_category WHERE ACTIVE_STATUS=1 order by CATEGORY_NAME ASC");
        return view('medicine_setup.create',compact('categories'));
    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 06-11-2022
     * @target Medicine Store
     */
    public function storeMedicine(Request $request){

        $medicineData = array(
            "MEDICINE"              => $request->MEDICINE,
            "CATEGORY_ID"           => $request->CATEGORY_ID,
            "ACTIVE_STATUS"         => 1,
            "created_by"            => Auth::user()->id,
            "created_at"            => date('Y-m-d H:i:s'),
        );
        $mstID = DB::table('pat_hf_med_list')->insertGetId($medicineData);
        if($mstID){
            Session::flash('success', 'Medicine saved successfully.');
        }else{
            Session::flash('error', 'Medicine not saved, Please try again.');
        }
        return redirect()->route('medicineIndex');

    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 08-11-2022
     * @target Medicine Edit Page
     */
    public function editMedicine($id=null){
        $medicine = [];
        if($id){
            $medicine = DB::selectOne("select * from pat_hf_med_list WHERE ID=$id");
        }
        return view('medicine_setup.update',compact('medicine'));
    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 08-11-2022
     * @target Medicine Update Action
     */
    public function updateMedicine(Request $request){

        $medicineData = array(
            "MEDICINE"              => $request->MEDICINE,
            "updated_by"            => Auth::user()->id,
        );

        if($request->MEDICINE_ID){
            $mstID = DB::table('pat_hf_med_list')
                ->where('ID', $request->MEDICINE_ID)
                ->update($medicineData);

            if($mstID){
                Session::flash('success', 'Medicine saved successfully.');
            }else{
                Session::flash('error', 'Medicine not saved, Please try again.');
            }
        }

        return redirect()->route('medicineIndex');

    }

}
