<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use Session;
use Tracker;
use App\Models\Settings;
use DateTimeImmutable;

class FontHomeController extends Controller
{
    public function home(){
        return view('userhome');
    }
    public function home2(){
        return view('userhomeMuhit04122022');
    }
    public function homeScroll(){
        return view('userhome-scroll');
    }

    // Get Current Data for HOMEPAGE @ 28-11-2022 by Salaquzzaman <salaquzzaman@atilimited.net>
    public function getCurrentData() {
        $cDate = date('Y-m-d');
        $info = DB::select("select p.SL_NO, p.NAME, p.REMARKS, p.CATEGORY_ID, c.NAME CATEGORY, p.START_TIME
            FROM pat_patients_info p
            LEFT JOIN set_category c ON c.ID=p.CATEGORY_ID
            WHERE p.ENTRY_DATE='$cDate'
            AND p.PATIENT_STATUS=1 ORDER BY p.SL_NO");
        $sl = '';
        $remarks = '';
        $name = '';
        $category = '';
        $category_id = '';
        $nameOrCat = '';
        $timeDurationMin = '00';
        $timeDurationSec = '00';

        if($info){

            $cdt = date('Y-m-d H:i:s');
            if($info[0]->START_TIME){
                $sdt = date('Y-m-d H:i:s', strtotime($info[0]->START_TIME));
                $origin = date_create($cdt);
                $target = date_create($sdt);
                $interval = date_diff($origin, $target);
                $timeDurationMin = $interval->format("%I");
                $timeDurationSec = $interval->format("%S");
            }

            $sl = $info[0]->SL_NO;
            $remarks = $info[0]->REMARKS;
            $name = $info[0]->NAME;
            $category = $info[0]->CATEGORY;
            $category_id = $info[0]->CATEGORY_ID;
            if($name!=""){
                $nameOrCat = $name;
            }else{
                if($category_id==3){
                    $nameOrCat = "Emergency";
                }else{
                    $nameOrCat = $category;
                }
            }
        }

        $flag = 0;
        $settings = new Settings();
        $tFlag = $settings->getValOfSettings('TEA_BREAK');
        $rFlag = $settings->getValOfSettings('REPORT_BREAK');
        if($tFlag==1){
            $flag = 1;
        }else if($rFlag==1){
            $flag = 2;
        }else{}

        return [
            "sl" => $sl,
            "slLength" => strlen($sl),
            "remarks" => $remarks,
            "name" => $name,
            "category" => $category,
            "nameOrCat" => $nameOrCat,
            "teaBreak" => $flag,
            "timeDurationMin" => $timeDurationMin,
            "timeDurationSec" => $timeDurationSec
        ];
    }

    // BACKUP
    public function getCurrentDataBackup17122022() {
        $cDate = date('Y-m-d');
        $info = DB::select("select p.SL_NO, p.NAME, p.REMARKS, p.CATEGORY_ID, c.NAME CATEGORY
            FROM pat_patients_info p
            LEFT JOIN set_category c ON c.ID=p.CATEGORY_ID
            WHERE p.ENTRY_DATE='$cDate'
            AND p.PATIENT_STATUS=1 ORDER BY p.SL_NO");
        $sl = '';
        $remarks = '';
        $name = '';
        $category = '';
        $category_id = '';
        $nameOrCat = '';
        if($info){
            $sl = $info[0]->SL_NO;
            $remarks = $info[0]->REMARKS;
            $name = $info[0]->NAME;
            $category = $info[0]->CATEGORY;
            $category_id = $info[0]->CATEGORY_ID;
            if($name!=""){
                $nameOrCat = $name;
            }else{
                if($category_id==3){
                    $nameOrCat = "Emergency";
                }else{
                    $nameOrCat = $category;
                }
            }
        }

        $flag = 0;
        $settings = new Settings();
        $flag = $settings->getValOfSettings('TEA_BREAK');

        return [
            "sl" => $sl,
            "slLength" => strlen($sl),
            "remarks" => $remarks,
            "name" => $name,
            "category" => $category,
            "nameOrCat" => $nameOrCat,
            "teaBreak" => $flag
        ];
    }
}
