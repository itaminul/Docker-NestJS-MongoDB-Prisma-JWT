<?php

namespace App\Http\Controllers\setup;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Session;
use DB;

class CategorySetupController extends Controller
{
    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 04-12-2022
     * @purpose Category setup index page
     */
    public function index()
    {
        $header = array(
            'pageTitle' => 'Category Setup',
            'tableTitle' => 'Category List'

        );

        $results = DB::table('set_category as dt1')
            ->where('ACTIVE_STATUS',1)
            ->orderBy('NAME','ASC')
            ->get();

        return view('setup.category.index',compact('header','results'));
    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 04-12-2022
     * @purpose Category create page
     */
    public function create()
    {
        $header = array(
            'pageTitle' => 'Category Create',
            'tableTitle' => 'Category Create'

        );

        return view('setup.category.create', compact('header'));
    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 04-12-2022
     * @purpose Category create/store action
     */
    public function store(Request $request)
    {
        if($request->NAME==''){
            Session::flash('error', 'Category name should not be empty.');
            return redirect()->route('categorySetup');
        }
        $data = [
            'NAME'          => $request->NAME,
            'ACTIVE_STATUS' => $request->ACTIVE_STATUS
        ];

        $mstID = DB::table('set_category')->insertGetId($data);
        if($mstID){
            Session::flash('success', 'Data Saved successfully!');
        }else{
            Session::flash('error', 'Data not saved, please tey again.');
        }
        return redirect()->route('categorySetup');
    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 04-12-2022
     * @purpose Category edit page
     */
    public function edit($id)
    {
        $header = array(
            'pageTitle' => 'Category Setup',
            'tableTitle' => 'Category List'

        );
        if(!$id){
            Session::flash('error', 'Data not found.');
            return redirect()->route('categorySetup');
        }

        $result = DB::table('set_category')->where('ID', $id)->first();
        return view('setup.category.update', compact('header', 'result'));

    }

    /**
     * @author Md. Salaquzzaman <salaquzzaman@atilimited.net>
     * @created-date 04-12-2022
     * @purpose Category upadte action
     */
    public function update(Request $request)
    {
        $id = $request->ID;
        if($id){
            $data = [
                'NAME' => $request->NAME,
                'ACTIVE_STATUS' => $request->ACTIVE_STATUS
            ];
            $exec = DB::table('set_category')
                ->where('ID', $id)
                ->update($data);

            Session::flash('success', 'Data Saved successfully!');
        }
        return redirect()->route('categorySetup');
    }
}
