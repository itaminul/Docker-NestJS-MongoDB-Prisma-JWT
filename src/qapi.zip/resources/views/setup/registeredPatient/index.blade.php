@extends('layouts.master')

@section('content')
@section('title')
@endsection
<style>
    ul li.active,
    a.active {
        color: #3fbbc0;
    }
</style>
<div class="" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>{{ $header['tableTitle'] }} </h2>

                        <div class="clearfix"></div>
                    </div>
                    <div class="container">
                        <div class="field item form-group">
                            <div class="col-md-3 col-sm-3">
                                <label for="fromdate">From</label>
                                <input type="date" class="form-control" name="fromdate" id="fromdate">
                            </div>
                            <div class="col-md-3 col-sm-3">
                                <label for="todate">To</label>
                                <input type="date" class="form-control" name="todate" id="todate">
                            </div>
                            <div class="col-md-3 col-sm-3 pt-1">
                                <button type="submit" id="submit_btn" class="btn btn-success mt-4">Submit</button>
                            </div>
                        </div>
                    </div>
                    <div class="x_content">
                        <div class="row">
                            <div id="table" class="col-sm-12">
                                <div class="card-box table-responsive">
                                    <table id="datatable"
                                        class="table table-striped table-bordered dataTable custom-table-border"
                                        role="grid" aria-describedby="data-table-info" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sl</th>
                                                <th>Mobile No</th>
                                                <th>Appointment For</th>
                                                <th>Patient Name</th>
                                                <th>Patient Sex</th>
                                                <th>Patient Age</th>
                                                <th style="width:60px;">Action</th>
                                                <th style="width:60px;">Status</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php $sl=1 @endphp
                                            @foreach ($results as $result)
                                                <tr>
                                                    <td>{{ $sl }}</td>
                                                    <td>{{ $result->MOBILE_NO }}</td>
                                                    <td>{{ $result->NAME }}</td>
                                                    <td>{{ $result->USERNAME }}</td>
                                                    <td>{{ $result->GENDER }}</td>
                                                    <td>{{ $result->AGE }}</td>

                                                    <td class="text-center">
                                                        <button type="button" class="btn btn-info btn-sm dynamicModal"
                                                            pageTitle="Appointment Information"
                                                            pageLink="{{ url('/editRegisteredPatient/' . $result->ID) }}"
                                                            data-modal-size="modal-lg" data-toggle="tooltip"
                                                            data-placement="top" title="Update Category">
                                                            <i class="glyphicon glyphicon-eye-open"></i>
                                                        </button>
                                                    </td>
                                                    <td>
                                                        @if ($result->APPOINTMENT_STATUS == 1)
                                                            <label class="btn btn-info btn-sm">Pending</label>
                                                        @elseif ($result->APPOINTMENT_STATUS == 2)
                                                            <label class="btn btn-success btn-sm">Accepted</label>
                                                        @elseif ($result->APPOINTMENT_STATUS == 0)
                                                            <label class="btn btn-danger btn-sm">Declined</label>
                                                        @endif
                                                    </td>
                                                </tr>
                                                @php $sl++;@endphp
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div style="display: none;" id="noResultsMessage"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    var submit = document.getElementById('submit_btn');
    submit.onclick = function() {
        var fromDate = $('#fromdate').val();
        var toDate = $('#todate').val();
        if (fromDate == '') {
            alert('Please Input From Date!');
            return false;
        }
        if (toDate == '') {
            alert('Please Input To Date!');
            return false;
        }
        $.ajax({
            type: "POST",
            url: "searchregisteredPatientData",
            data: {
                "_token": "{{ csrf_token() }}",
                "FROM_DATE": fromDate,
                "TO_DATE": toDate,
            },
            success: function(result) {
                if (result.length > 0) {
                    $('tbody').empty();
                    var editUrl = "{{ url('/editRegisteredPatient') }}";

                    $.each(result, function(index, data) {
                        var pageLink = editUrl + '/' + data.ID;
                        // Construct table row HTML using the data
                        var newRow = `
                <tr>
                    <td>${index + 1}</td>
                    <td>${data.MOBILE_NO}</td>
                    <td>${data.NAME}</td>
                    <td>${data.USERNAME}</td>
                    <td>${data.GENDER}</td>
                    <td>${data.AGE}</td>
                    <td class="text-center">
                        <button type="button" class="btn btn-info btn-sm dynamicModal"
                            pageTitle="Appointment Information"
                            pageLink="${pageLink}"
                            data-modal-size="modal-lg" data-toggle="tooltip"
                            data-placement="top" title="Update Category">
                            <i class="glyphicon glyphicon-eye-open"></i>
                        </button>
                    </td>
                    <td>
                        ${data.APPOINTMENT_STATUS == 1 ? '<label class="btn btn-info btn-sm">Pending</label>' : (data.APPOINTMENT_STATUS == 2 ? '<label class="btn btn-success btn-sm">Accepted</label>' : '<label class="btn btn-danger btn-sm">Declined</label>')}
                    </td>
                </tr>`;
                        // Append the new row to the tbody element
                        $('tbody').append(newRow);
                    });
                    $('.dynamicModal').click(function() {
                        var modal_size = $(this).attr('data-modal-size');
                        if (modal_size !== '' && typeof modal_size !== typeof undefined &&
                            modal_size !== false) {
                            $("#modalSize").addClass(modal_size);
                        } else {
                            $("#modalSize").addClass('modal-lg');

                        }

                        var pageTitle = $(this).attr('pageTitle');
                        var pageLink = $(this).attr('pageLink');
                        $('.modal .modal-title').html(pageTitle)
                        $('.modal .modal-body').html("Content loading please wait......")
                        $('.modal').modal("show");
                        $('.modal .modal-body').load(pageLink)
                    });
                }else{
                    $('#table').hide();
                    $('#noResultsMessage').show();
                    $('#noResultsMessage').text("No results found");
                }
            },
        });
    };
</script>
@endsection
