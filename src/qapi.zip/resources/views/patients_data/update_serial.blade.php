@section('content')
@include('layouts.modalFormSubmit')
@php $actionUrl=url('/storeUpdateSerial'); @endphp
<script>
    $('form').parsley();
</script>
<?php ini_set('memory_limit', -1) ?>
<div class="flash-message"></div>
<div class="x_content">
    <form id="ClassRoomSetupForm" data-parsley-validate="" role="form" method="post" action="{{$actionUrl}}"
        class="form-label-left" enctype="multipart/form-data" autocomplete="off">
        @csrf
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Name</label>
            <div class="col-md-6 col-sm-6">
                <input class="form-control input-field-required-sign" name="NAME" id="NAME"
                value="{{($patientInfo)? $patientInfo->NAME:''}}"/>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="form-group">
            <div class="col-md-6 offset-md-3">
                <input type="hidden" name="targetURL" id="targetURL">
                <input type="hidden" name="PATIENT_ROW_ID" id="PATIENT_ROW_ID" value="{{($patientInfo)? $patientInfo->ID:''}}">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </div>

    </form>
</div>
<script>
    // Redirect to specific location
    var k = $(location).attr("href");
    const myArray = k.split("/");
    var result = myArray[myArray.length - 1];
    $('#targetURL').val(result);
</script>


