<?php

namespace App\Models\security_access;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModuleLinkPermissionModel extends Model
{
    use HasFactory;
    protected $table = 'sa_uglw_mlink';
}
