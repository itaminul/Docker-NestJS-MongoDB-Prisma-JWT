<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiResponseModel;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\PatientInfo;
use Auth;
use DB;
use Exception;
use Illuminate\Database\QueryException;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Mail;

class AppInfoController extends Controller
{
    public function getAppInfo(Request $request) {
        // String? appName;
        // String? packageName;
        // String? version;
        // String? buildNumber;
        // String? buildSignature;
        // String? installerStore;
        $app_info = DB::table('app_info')
                    ->where('package_name', '=', $request->package_name)
                    ->where('active_fg', '=', 1)
                    ->orderBy('id', 'desc')
                    ->first();
        $result = new ApiResponseModel(true,"App Info Found",$app_info);
        return response()->json($result, 200);
    }


}
