@section('content')
    @include('layouts.modalFormSubmit')
    @php $actionUrl=url('/updateCategorySetup'); @endphp
    <style>
        .preview-container {
            margin-left: 50px;
            position: relative;
        }

        .preview-image {
            width: 80px;
            height: 80px;
            margin-right: 20px;
            transition: transform 0.3s ease-in-out;
        }

        .preview-image:hover {
            transform: scale(2);
            position: relative;
            z-index: 1;
        }

        /* Add some styling for the new table */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        td button {
            cursor: pointer;
        }
    </style>

    <script>
        $('form').parsley();
    </script>
    <?php ini_set('memory_limit', -1); ?>
    <div class="flash-message"></div>
    <div class="x_content">
        <form id="APPOINTMENT_FORM" action="{{ route('scheduleAppointment') }}" method="post">
            @csrf

            <div class="col col-md-6 col-lg-6">

                <div class="card">
                    <div class="card-body" style="padding-bottom: 27px">
                        <h5 class="card-title">Doctor Info</h5>
                        <h6 class="card-subtitle mb-2 text-muted">Dr. Saklayen Russel</h6>
                        <p class="card-text">MBBS (DMC), MS (CVTS)</p>
                        <br><br><br>
                    </div>
                </div>
            </div>

            <div class="col col-md-6 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Patient Info</h5>
                        <h6 class="card-title">Name : {{ $appointment->NAME }}</h6>
                        <p class="card-text">Age : {{ $appointment->AGE }}</p>
                        <p class="card-text">Gender : {{ $appointment->GENDER }}</p>
                        <p class="card-text">Mobile : {{ $appointment->MOBILE_NO }}</p>
                    </div>
                </div>
            </div>


            <input type="hidden" name="APPOINTMENT_ID" value="{{ $appointment->ID }}">
            <input type="hidden" name="PATIENT_ID" value="{{ $appointment->PATIENT_ID }}">

            <div class="col col-md-12 col-lg-12 mt-5">
                <div class="field item form-group">
                    <div class="col-md-12 col-sm-12">
                        <table>
                            <thead>
                                <tr>
                                    <th colspan="4" style="text-align: center; font-weight: bold;">Appointment Schedule
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-center">Start Time</th>
                                    <th class="text-center">End Time</th>
                                    <th class="text-center">Patient Count</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($appointmentTimes as $appointmentTime)
                                    <?php
                                    $today = date('Y-m-d');
                                    $patient_count = count(
                                        DB::table('appointment_schedule_details')
                                            ->where('SCHEDULE_ID', '=', $appointmentTime->ID)
                                            ->where('APPOINTMENT_DATE', '=', $today)
                                            ->get(),
                                    );
                                    ?>

                                    <tr>

                                        <td class="text-center">{{ $appointmentTime->START_TIME }}</td>
                                        <td class="text-center">{{ $appointmentTime->END_TIME }}</td>
                                        <td class="text-center">{{ $patient_count }}</td>

                                        {{-- <td><button id="setTime" class="btn btn-sm btn-info">Schedule</button></td> --}}
                                        <input type="hidden" class="SCHEDULE_ID" value="{{ $appointmentTime->ID }}">
                                        <input type="hidden" class="START_TIME"
                                            value="{{ $appointmentTime->START_TIME }}">
                                        <input type="hidden" class="END_TIME" value="{{ $appointmentTime->END_TIME }}">
                                        <td class="text-center"><a id="scheduleButton" onclick="scheduleTime(this)"
                                                class="btn btn-info">Schedule</a></td>

                                    </tr>
                                @endforeach
                                <input type="hidden" id="SCHEDULE_TIME" name="SCHEDULE_TIME" value="">
                                <input type="hidden" id="START" name="START_TIME" value="">
                                <input type="hidden" id="END" name="END_TIME" value="">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>



            <br><br>


            <div class="clearfix"></div>

            <div class="form-group">
                <div class="col-md-6 offset-md-3">
                    {{-- <button type="submit" id="deleteButton" onclick="setButtonClick('reject')" class="btn btn-danger">Reject</button> --}}
                    <input type="hidden" name="button_clicked" id="buttonClicked" value="">
                </div>
            </div>
        </form>
        <br><br><br>

    </div>

    <script>
        // This function helps to know if the reject button was clicked on this page
        function setButtonClick(buttonValue) {
            document.getElementById('buttonClicked').value = buttonValue;
        }

        // This function is for scheduling appointment time
        function scheduleTime(element) {
            var $row = $(element).closest('tr');
            var scheduleId = parseInt($row.find('.SCHEDULE_ID').val());
            var start = $row.find('.START_TIME').val();
            var end = $row.find('.END_TIME').val();
            $('#SCHEDULE_TIME').val(scheduleId);
            $('#START').val(start);
            $('#END').val(end);

            $('#APPOINTMENT_FORM').submit();
        }
    </script>
