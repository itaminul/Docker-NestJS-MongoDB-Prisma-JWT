@section('content')
@include('layouts.modalFormSubmit')
@php $actionUrl=url('/changeStatus'); @endphp
<script>
    $('form').parsley();
</script>
<?php ini_set('memory_limit', -1) ?>
<div class="flash-message"></div>
<div class="x_content">
    <form id="statusChangeForm" data-parsley-validate="" role="form"
        class="form-label-left" autocomplete="off">
        @csrf

        @php
            $colorStatus = $status;
            $status = $status+1;
            $label = '<i style="color:red" class="fa fa-long-arrow-right"></i>';
        @endphp

        @if($colorStatus==0)
            <style>
                .btnChange{
                    border-radius: 50px;
                    width: 100px;
                    height: 100px;
                    background-color: #8746A6;
                    color: #fff;
                }
                .btnChange:hover{
                    background-color: #FFA525;
                    color: #fff;
                }
            </style>
            @php $label = 'DI'; @endphp
        @else
        @endif

        <span id="remarksAlert" style="display:none;color:red;">Another patient already is in DI, for this please enter remarks.</span>
        <input type="checkbox" class="circle-nicelabel" name="REMARKS_OK" id="REMARKS_OK" value="1"/>Remarks
        <br>
        <textarea style="border:1px solid #dee2e6;margin-bottom:3px;"
            name="REMARKS" id="REMARKS" cols="50" rows="2" readonly></textarea>

        <input type="hidden" name="ID" id="ID" value="{{$id}}">
        <input type="hidden" name="PATIENT_STATUS" id="PATIENT_STATUS" value="{{$status}}">
        <div style="text-align: center">
            <br>
            <input type="hidden" name="targetURL" id="targetURL">
            <input type="hidden" name="submitURL" id="submitURL" value="{{$actionUrl}}">
            <input type="hidden" name="remarksAlertVal" id="remarksAlertVal">

            <a class="btnChange"
                name="btnSTSubmit" id="btnSTSubmit">
                <div class="btnChange"
                style="margin: auto; padding-top: 38px; font-weight: normal;">
                    Proceed {{$label}}</div></a>


        </div>
        <script>
            $('#btnSTSubmit').click(function(){
                var remarksAlertVal = $("#remarksAlertVal").val();
                var REMARKS = $("#REMARKS").val();
                var submitURL = $("#submitURL").val();
                REMARKS = REMARKS.trim();
                lngth = REMARKS.length;
                var postMode = false;
                if(remarksAlertVal==2){ // remarks mendatory
                    if(lngth<1){
                        alertify.alert("Please enter remarks");
                        return false;
                    }else{
                        postMode = true;
                    }

                }else{ // not mendatory
                    postMode = true;
                }

                if(postMode){
                    // do submit
                    $('#statusChangeForm').attr('method', 'post');
                    $('#statusChangeForm').attr('action', submitURL);
                    $("#statusChangeForm").submit();

                }
            });
        </script>
        <style>
            #REMARKS:read-only{
                background-color: #EFEAEA;
            }
        </style>
    </form>
</div>
<script>
    $('#REMARKS_OK').click(function(){
        $('#REMARKS').val('');
        if ($(this).is(':checked')) {
            $('#REMARKS').removeAttr( "readonly");
            $('#REMARKS').css("background-color","initial");
        }else{
            $('#REMARKS').attr( "readonly", true);
            $('#REMARKS').css("background-color","#EFEAEA");
        }
    });

    // Redirect to specific location
    var k = $(location).attr("href");
    const myArray = k.split("/");
    var result = myArray[myArray.length - 1];
    $('#targetURL').val(result);
</script>
<script>
    $('#REMARKS_OK').nicelabel();
</script>

@if($colorStatus==0)
<style>
@media only screen and (min-width: 992px) {
    .btnChange {
      margin-top:-90px !important;
    }
}
</style>
@endif


