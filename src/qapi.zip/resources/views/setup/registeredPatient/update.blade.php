@section('content')
@include('layouts.modalFormSubmit')
@php $actionUrl=url('/updateCategorySetup'); @endphp
<style>
    .preview-container {
      position: relative;
    }
  
    .preview-image {
      width: 80px;
      height: 80px;
      margin-right: 20px;
      transition: transform 0.3s ease-in-out;
    }
  
    .preview-image:hover {
      transform: scale(2); /* Increase the size on hover */
      position: relative; /* Ensure it doesn't affect other elements */
      z-index: 1; /* Bring the hovered image to the front */
    }
  </style>
  
<script>
    $('form').parsley();
</script>
<?php ini_set('memory_limit', -1) ?>
<div class="flash-message"></div>
<div class="container">
<form action="{{ route('approveAppointment') }}" method="post">
    @csrf

    <div class="col col-md-6 col-lg-6">

        <div class="card">
            <div class="card-body" style="padding-bottom: 27px">
              <h5 class="card-title">Doctor Info</h5>
              <h6 class="card-subtitle mb-2 text-muted">Dr. Saklayen Russel</h6>
              <p class="card-text">MBBS (DMC), MS (CVTS)</p>
              <br><br><br>
            </div>
          </div>
    </div>

    <div class="col col-md-6 col-lg-6">
        <div class="card">
            <div class="card-body">
              <h5 class="card-title">Patient Info</h5>
              <h6 class="card-title">Name    : {{ $appointment->NAME }}</h6>
              <p class="card-text">Age     : {{$appointment->AGE}}</p>
              <p class="card-text">Gender  : {{$appointment->GENDER}}</p>
              <p class="card-text">Mobile  : {{$appointment->MOBILE_NO}}</p>
            </div>
          </div>
    </div>
    <input type="hidden" name="APPOINTMENT_ID" value="{{$appointment->ID}}">

    <div class="col col-md-12 col-lg-12 my-3">
        <textarea name="DESCRIPTION" id="DESCRIPTION" cols="30" rows="5" style="width:100%" placeholder="Patient reason..." readonly>{{$appointment->DESCRIPTION}}</textarea>
    </div>

    <div class="col col-md-12 col-lg-12 d-flex align-items-center justify-content-center my-3">
        <div class="preview-container">
            @foreach ($attachments as $attachment)
                @if ($appointment->ID == $attachment->APPOINTMENT_ID)
                    <a href="{{ asset('appointmentImages/patient/' . $attachment->documents_image) }}" target="_blank">
                        <img src="{{ asset('appointmentImages/patient/' . $attachment->documents_image) }}" 
                            alt="Image" 
                            class="img-thumbnail preview-image"/>
                    </a>
                @endif
            @endforeach
        </div>
    </div>
    


        {{-- <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Appointment No:</label>
            <div class="col-md-8 col-sm-8">
                <input class="form-control" name="APPOINTMENT_ID" id="" value="{{$appointment->ID}}" readonly />
            </div>
        </div>
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Serial No:</label>
            <div class="col-md-8 col-sm-8">
                <input class="form-control" name="SL_NO" id="SL_NO" value="{{$appointment->SL_NO}}" readonly />
            </div>
        </div>
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Patient Name:</label>
            <div class="col-md-8 col-sm-8">
                <input class="form-control" name="NAME" id="NAME" value="{{$appointment->NAME}}" readonly />
            </div>
        </div>
        
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Age:</label>
            <div class="col-md-8 col-sm-8">
                <input class="form-control" name="AGE" id="AGE" value="{{$appointment->AGE}}" readonly />
            </div>
        </div>
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Gender:</label>
            <div class="col-md-8 col-sm-8">
                <input class="form-control" name="GENDER" id="GENDER" value="{{$appointment->GENDER}}" readonly />
            </div>
        </div>
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Mobile No:</label>
            <div class="col-md-8 col-sm-8">
                <input class="form-control" name="MOBILE_NO" id="MOBILE_NO" value="{{$appointment->MOBILE_NO}}" readonly />
            </div>
        </div>

        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Description:</label>
            <div class="col-md-8 col-sm-8">
                <input class="form-control" name="DESCRIPTION" id="DESCRIPTION" value="{{$appointment->DESCRIPTION}}" readonly />
            </div>
        </div>

        <div class="preview-containerr">
            <label class="col-form-label col-md-3 col-sm-3 label-align">Images:</label>
            @foreach ($attachments as $attachment)
                @if ($appointment->ID == $attachment->APPOINTMENT_ID)
                    <a href="{{ asset('appointmentImages/patient/' . $attachment->documents_image) }}" target="_blank">
                        <img src="{{ asset('appointmentImages/patient/' . $attachment->documents_image) }}" 
                            alt="Image" 
                            class="img-thumbnail preview-image"/>
                    </a>
                @endif
            @endforeach
        </div> --}}
        
    
        <div class="col col-md-12 col-lg-12 d-flex align-items-center justify-content-center my-3">
            <div class="form-group">
           
                <button type="submit" id="approveButton" onclick="setButtonClick('approve')" class="btn btn-success" data-appointment-id="{{ $appointment->ID }}">Approve</button>
                <button type="submit" id="deleteButton" onclick="setButtonClick('reject')" class="btn btn-danger"  data-appointment-id="{{ $appointment->ID }}">Reject</button>
                <input type="hidden" name="button_clicked" id="buttonClicked" value="">
            
        </div>
        </div>
     

        
    </form>
        <br>
 
</div>

<script>
    function setButtonClick(buttonValue) {
        document.getElementById('buttonClicked').value = buttonValue;
    }
</script>
