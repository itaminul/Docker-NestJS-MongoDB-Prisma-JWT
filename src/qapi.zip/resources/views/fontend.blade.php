@extends('font_layouts.master')

@section('content')
<main id="main">       
@include('font_layouts.fontDashbord')
</main>
@endsection



