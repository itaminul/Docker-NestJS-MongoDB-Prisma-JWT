<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Api\AppLoginController;
use App\Http\Controllers\Api\LoginController;
use App\Http\Controllers\Api\StdAcademicController;
use App\Http\Controllers\Api\StdInfoController;
use App\Http\Controllers\Api\BlockController;
use App\Http\Controllers\Api\AcaBlockTopicsController;
use App\Http\Controllers\Api\SubBlockController;
use App\Http\Controllers\Api\AcaStudentRegisController;
use App\Http\Controllers\Api\NoticeController;
use App\Http\Controllers\Api\StuActivityAttendanceController;
use App\Http\Controllers\Api\StuClassAttendanceController;
use App\Http\Controllers\Api\StuClassRoutineController;
use App\Http\Controllers\Api\StuDissProtoSubmissionController;
use App\Http\Controllers\Api\StuInstituteAttendanceController;
use App\Http\Controllers\Api\StuLeaveController;
use App\Http\Controllers\Api\StuMoneyReceiptController;
use App\Http\Controllers\Api\StuPublicationInfoController;
use App\Http\Controllers\Api\StuSkillInfoController;
use App\Http\Controllers\Api\StuTraningExperianceController;
use App\Http\Controllers\Api\StuTraineeFeedbackController;
use App\Http\Controllers\Api\StuTrainingPublicationController;

use App\Http\Controllers\Api\TeaBlockClearanceController;
use App\Http\Controllers\Api\TeaBlockPlacementController;
use App\Http\Controllers\Api\TeaClassRoutineController;
use App\Http\Controllers\Api\TeaFormativeAssessmentController;
use App\Http\Controllers\Api\TeaSummativeAssessmentController;
use App\Http\Controllers\Api\TeaLeaveController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\AppInfoController;
use App\Http\Controllers\Api\VideoController;
use App\Http\Controllers\Api\VascularPdfController;
use App\Http\Controllers\Api\AppointmentController;
use App\Http\Controllers\Api\DoctorController;
use App\Http\Controllers\Api\HealthTopicController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

//Route::post('login', [LoginController::class, 'signin']);
//Route::post('register', [LoginController::class, 'signup']);

Route::post('class_routine', [AppLoginController::class, 'class_routine']);
Route::post('get_events', [AppLoginController::class, 'get_events']);
Route::post('geo_data', [AppLoginController::class, 'getGeoData']);
Route::post('stu_attendance', [AppLoginController::class, 'StudentAttendance']);
Route::post('get_stu_attendance', [AppLoginController::class, 'getStudentAttendance']);
Route::post('get_stud_info', [AppLoginController::class, 'getStudentInfo']);
Route::post('update_stud_info', [AppLoginController::class, 'updateStudentInfo']);
Route::post('get_activity_attendance_info', [AppLoginController::class, 'activityAttendanceInfo']);
Route::post('create_activity_attendance', [AppLoginController::class, 'createActivityAttendance']);
Route::post('get_student_activity_attendance', [AppLoginController::class, 'getStudentActivityAttendance']);
Route::post('check_student_class_attendance', [AppLoginController::class, 'checkStudentCheckAttendance']);
Route::post('check_student_activity_attendance', [AppLoginController::class, 'checkStudentActivityAttendance']);
Route::post('check_student_block', [AppLoginController::class, 'checkStudentBlock']);
Route::post('atten_student_class_attendance', [AppLoginController::class, 'attenStudentCheckAttendance']);

Route::middleware('auth:sanctum')->group( function () {
    // azam@atilimited.net
    Route::resource('stdAcademicInfo', StdAcademicController::class);
    Route::resource('aca_student_regis', AcaStudentRegisController::class);
    Route::resource('stu_activity_attendance', StuActivityAttendanceController::class);
    Route::resource('stu_class_attendance', StuClassAttendanceController::class);
    Route::resource('stu_class_routine', StuClassRoutineController::class);
    Route::resource('stu_diss_prot_sub', StuDissProtoSubmissionController::class);
    Route::resource('stu_institute_attendance', StuInstituteAttendanceController::class);
    Route::resource('stu_leave', StuLeaveController::class);
    Route::resource('stu_money_receipt_attachment', StuMoneyReceiptController::class);
    Route::resource('stu_publication_info', StuPublicationInfoController::class);
    Route::resource('stu_skill_info', StuSkillInfoController::class);
    Route::resource('stu_training_exp_info', StuTraningExperianceController::class);
    Route::resource('stu_trainee_feedback_info', StuTraineeFeedbackController::class);
    Route::resource('stu_training_publication_info', StuTrainingPublicationController::class);
    // salaquzzaman
    Route::resource('tea_block_clearance', TeaBlockClearanceController::class);
    Route::resource('tea_block_placement', TeaBlockPlacementController::class);
    Route::resource('tea_class_routine', TeaClassRoutineController::class);
    Route::resource('tea_formative_assessment', TeaFormativeAssessmentController::class);
    Route::resource('tea_summative_assessment', TeaSummativeAssessmentController::class);
    Route::resource('tea_leave', TeaLeaveController::class);

});
Route::post('std_info', [StdInfoController::class, 'std_info']);
Route::post('block_create', [BlockController::class, 'block_create']);
Route::post('block_topics_create', [AcaBlockTopicsController::class, 'block_topics_create']);
Route::post('sub_block_create', [SubBlockController::class, 'sub_block_create']);



Route::post('/register', [UserController::class, 'register']);
Route::post('/login', [UserController::class, 'login']);
Route::post('/forgot-password', [UserController::class, 'forgotPassword']);


// Laravel passport middleware for user authentication using suthorization token
Route::middleware(['auth:api'])->group(function () {
    
    // App version code
    Route::post('/app-info',[AppInfoController::class,'getAppInfo']);

    // Route for getting user info
    Route::get('/patient/{id}', [UserController::class, 'getPatient']);
    // Route for Logging out info
    Route::get('/logout', [UserController::class, 'logout']);

    // Route for making appointment
    Route::post('/take-appointment', [AppointmentController::class, 'takeAppointment']);

   

    Route::post('/change-password', [UserController::class, 'changePassword']);

    Route::get('/popular-video-list',[VideoController::class,'getPopularVideoList']);

    Route::get('/vascular-pdf-list',[VascularPdfController::class,'getvascularPdfList']);

    Route::get('/video-list',[VideoController::class,'getAllVideoList']);

    // update user profile
    Route::post('/user/profile/update', [UserController::class, 'updateUserProfile']);
    
    Route::get('/notice-list',[NoticeController::class,'noticeList']);

    Route::get('/doctor-list',[DoctorController::class,'getDoctorList']);

    Route::get('/health-topic-list',[HealthTopicController::class,'getHealthTopicList']);
    Route::get('/doctorsList',[DoctorsController::class,'getHealthTopicList']);

    

});
// Route::post('/test', [AppointmentController::class, 'test']);
// Route::post('/request-otp',[UserController::class,'requestOTP']);
// Route::post('/register-user',[UserController::class,'registerUser']);
// Route::post('/login-mobile',[UserController::class,'loginMobile']);

