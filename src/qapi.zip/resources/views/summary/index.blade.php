@extends('layouts.master') @section('content') @section('title') @endsection
<style>
    ul li.active,
    a.active {
        color: #3fbbc0;
    }

</style>
<div class="" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <?php
                   $info = DB::selectOne("SELECT SL_NO, NAME FROM pat_patients_info
                        WHERE PATIENT_STATUS=0 ORDER BY ID ASC LIMIT 0,1");
                ?>
                <h3>
                    {{$header['pageTitle']}}
                    {{-- <span style="font-size: 20px; color: #5858f3;">
                        (Next Serial: {{($info && $info->SL_NO)? $info->SL_NO:''}},
                        Patient: {{($info && $info->NAME)? $info->NAME:''}}) </span> --}}
                </h3>
            </div>
            <div class="title_right">
                <div class="item form-group">
                    <div class="col-md-3 col-sm-3 offset-md-9">
                    {{-- <button type="button" class="btn btn-primary dynamicModal"
                        pageTitle="Serial Entry" pageLink="{{URL::route('serialEntryPopup')}}"
                        data-toggle="tooltip" data-placement="left"
                        title="Create New Serial" data-target=".bs-example-modal-lg"
                        data-modal-size="modal-lg">Create</button> --}}
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="x_panel">
                    {{-- <div class="x_title">
                        <h2>{{$header['tableTitle']}} </h2>
                    </div> --}}
                    <div class="x_title">
                        {{-- <h2>{{$header['tableTitle']}} </h2> --}}

                        {{-- filtering start --}}

                        <div class="row" style="padding-top:15px">
                            <div class="col-sm-12">
                                {{-- <div class="col-md-12"> --}}
                                    <div class="field item form-group">
                                        <label class="col-form-label col-md-1 col-sm-1  label-align">Date </label>
                                        <div class="col-md-3 col-sm-3">
                                            <input type="text" class="form-control datepickerMonthYearAppend required" autocomplete="off" name="" id="searchFieldFrom" placeholder="from" value="{{date('d-m-Y')}}" required>
                                        </div>
                                        <div class="col-md-3 col-sm-3">
                                            <input type="text" class="form-control datepickerMonthYearAppend required" autocomplete="off" name="" id="searchFieldTo" placeholder="to" value="{{date('d-m-Y')}}" required>
                                        </div>
                                        <div class="col-md-5 col-sm-12">
                                            <a id="btnSearch" class="btn btn-info btnSearch" style="color:#fff;">Search</a>
                                            <a href="{{url('patientSummary')}}" class="btn btn-success btnReset" style="color:#fff;">Reset</a>
                                        </div>
                                    </div>
                                {{-- </div> --}}
                                {{-- <div class="col-md-3">
                                    <div class="field item form-group">
                                        <div style="display: block; color:#FFF">
                                            <a id="btnSearch" class="btn btn-info">Search</a>
                                        </div>
                                    </div>
                                </div> --}}
                            </div>
                        </div>

                        {{-- filtering end --}}

                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content" id="searchPatientData">
                        {{-- searchable result --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
// search on user list
    $('#btnSearch').click(function(){
        var searchFieldFrom = $('#searchFieldFrom').val();
        var searchFieldTo = $('#searchFieldTo').val();

        if(searchFieldFrom=='' || searchFieldTo==''){
            //getPatientData(searchFieldFrom='',searchFieldTo='');
            alertify.alert("Please select from date & to date");
            return false;
        }else{
            getPatientData(searchFieldFrom, searchFieldTo);
        }
    });

    var searchFieldFrom = $('#searchFieldFrom').val();
    var searchFieldTo = $('#searchFieldTo').val();
    getPatientData(searchFieldFrom, searchFieldTo);

    // get patient data list, with search or without search
    function getPatientData(searchFieldFrom='',searchFieldTo=''){

        if(searchFieldFrom=='') searchFieldFrom=0;
        if(searchFieldTo=='') searchFieldTo=0;

        $('.ajaxLoaderFormLoad').show();
        $.ajax({
            type: 'GET',
            url: '{{url("/searchPatientSummary")}}/'+searchFieldFrom+'/'+searchFieldTo,
            success: function (data) {
                $('.ajaxLoaderFormLoad').hide();
                $('#searchPatientData').html(data);
                $('#datatable').dataTable();
            }
        });
    }
</script>
<style>
    .btnSearch, .btnReset{
        width:80px;
    }
    .datepickerMonthYearAppend::placeholder{
        color:#C0BFBF !important;
    }
    .datepickerMonthYearAppend:-ms-input-placeholder{
        color:#C0BFBF !important;
    }
    .datepickerMonthYearAppend::-ms-input-placeholder{
        color:#C0BFBF !important;
    }
</style>

@endsection
