<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiResponseModel;
use DB;

class VideoController extends Controller{


    public function getPopularVideoList()
    {
        $video_list = DB::table('dashboard_video_info')->select('video_thumbnail_url', 'video_url')->get();
        if(!$video_list){
            $result = new ApiResponseModel(true,"Video List Not Found");
            return response()->json($result, 500);
        }
        foreach($video_list as $video){
            $video->video_thumbnail_url = url($video->video_thumbnail_url);
        }
        $data = array(
            "video_list" => $video_list
        );
        $result = new ApiResponseModel(true,"Video List Found",$data);
        return response()->json($result, 200);
    }

    public function getAllVideoList(){
        $video_list = DB::table('dashboard_video_info')->select('video_thumbnail_url', 'video_url')->get();
        if(!$video_list){
            $result = new ApiResponseModel(true,"Video List Not Found");
            return response()->json($result, 500);
        }
        foreach($video_list as $video){
            $video->video_thumbnail_url = url($video->video_thumbnail_url);
        }
        $data = array(
            "video_list" => $video_list
        );
        $result = new ApiResponseModel(true,"Video List Found",$data);
        return response()->json($result, 200);
    }

}

?>