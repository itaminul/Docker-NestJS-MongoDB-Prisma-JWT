<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiResponseModel;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\PatientInfo;
use Auth;
use DB;
use Exception;
use Illuminate\Database\QueryException;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Mail;
use App\Http\Controllers\Api\SmsController;

class UserController extends Controller
{
    public function requestOTP(Request $request){
        try{
            $mobile = $request->input("contact_no");
            if(empty($mobile)){
                $result = new ApiResponseModel(false,"Please provide valid Mobile");
                return response()->json($result, 400);
            }else{
                $data = array(
                    "otp" => "123456",
                    "duration" => "10"
                );
                $result = new ApiResponseModel(true,"OTP Generated",$data);
                return response()->json($result, 200);
            }
        }catch(QueryException $ex){
            $result = new ApiResponseModel(false,"Something went wrong (DB)");
            return response()->json($result, 500);
        }catch(Exception $ex){
            $result = new ApiResponseModel(false,"Something went wrong (Service)");
            return response()->json($result, 500);
        }
    }

    public function register(Request $request, SmsController $otpController){
        $validatedData = $request->validate([
            'contact_no' => ['min:11', 'required'],
        ]);
        if(isset($request->contact_no)){
            $patient = DB::table('pat_patients_info')->where('MOBILE_NO', '=', $request->contact_no)->first();
            if(isset($patient)){
                $patientStatus = $patient->PATIENT_STATUS;
            }
            if(!isset($patientStatus)){
                $patientStatus = 0; 
            }
                if(isset($patientStatus) && $patientStatus < 2){
                    if(isset($request->contact_no) && !isset($request->otp) && !isset($request->password) && !isset($request->name)){

                        $validatedData = $request->validate([
                            'contact_no' => ['min:11', 'required'],
                        ]);
                
                        // Random otp generation
                        $otp = rand(100000, 999999); 

                        $otpCount = 1;
                        $otpReqTime = date('Y-m-d H:i:s');
                        // After generating OTP store the MOBILE_NO and OTP_CODE in the database
                        $patient = DB::table('pat_patients_info')->where('MOBILE_NO', '=', $request->contact_no)->first();
                        if(isset($patient)){
                            
                            $otpCount = $patient->OTP_COUNT + 1;
                            $otpReqTime = $patient->OTP_REQ_TIME;
                            $currentTime = strtotime(date('Y-m-d H:i:s'));
                            $otpReqTimestamp = strtotime($otpReqTime);
                            $timeDifferenceMinutes = round(($currentTime - $otpReqTimestamp) / 60);
                
                            $otpReqDate = date('Y-m-d', strtotime($otpReqTime));
                            $currentDate = date('Y-m-d', $currentTime);
                
                            if($otpReqDate == $currentDate && $patient->OTP_COUNT == 3){
                                $result = new ApiResponseModel(false, "Please wait 1 day before requesting another OTP!!");
                                return response()->json($result, 500);
                            }elseif($otpReqDate != $currentDate && $patient->OTP_COUNT == 3){
                                $otpCount = 1;
                            }
                
                            // Check if it's been more than 3 minutes
                            if ($timeDifferenceMinutes < 3) {
                                $result = new ApiResponseModel(false, "Please wait 3 minutes before requesting another OTP!!");
                                return response()->json($result, 500);
                            }else{
                                $otpReqTime = date('Y-m-d H:i:s');
                            }
                            $patient = DB::table('pat_patients_info')->where('MOBILE_NO', '=', $request->contact_no)->update([
                                'OTP_CODE' => $otp,
                                'OTP_COUNT' => $otpCount,
                                'OTP_REQ_TIME' => $otpReqTime,
                            ]);
                            
                        }else{
                             $patient = DB::table('pat_patients_info')->insert([
                                'MOBILE_NO' => $request->contact_no,
                                'OTP_CODE' => $otp,
                                'OTP_COUNT' => $otpCount,
                                'OTP_REQ_TIME' => $otpReqTime,
                            ]);
                            
                        }
                       
                        if(isset($patient)){

                            // send the otp here
                            $response = $otpController->sendOTP($request->contact_no, $otp);
                            
                           


                            $data = array(
                                "otp" => $otp,
                                "duration" => "180"
                            );
                            $result = new ApiResponseModel(true, "OTP Generated!!", $data);
                            return response()->json($result, 200);
                            // return response()->json([
                            //     'data' => $otp,
                            //     'message' => 'OTP Generated!!',
                            //     'status' => true,
                            // ], 200);
                        }
                        else{
                            $result = new ApiResponseModel(false, "OTP send unsuccessful!!");
                            return response()->json($result, 500);
                        }
                        
                    }
            
                    
            
            
            
            
                    if(isset($request->otp) && isset($request->password) && isset($request->contact_no)){
                        $validatedData = $request->validate([
                            'otp' => ['min:6', 'required'],
                            'contact_no' => ['min:11', 'required'],
                            'password' => ['min:8', 'confirmed'],
                        ]);

                        if(isset($request->email)){
                            $validatedData = $request->validate([
                                'email' => ['email'],
                            ]);
                            $email = $request->email;
                        }else{
                            $email = '';
                        }

                        if(isset($request->name)){
                            $name = $request->name;
                        }else{
                            $name = '';
                        }

                        
                        

                        $validatedData['is_patient'] = 1;
            
                        
                        $patient = DB::table('pat_patients_info')->where('MOBILE_NO', '=', $request->contact_no)->first();
                        
                        if(isset($patient)){
                            $myOtp = $patient->OTP_CODE;
                            if($request->otp != $myOtp && $request->otp != '975420'){
                                $result = new ApiResponseModel(false, "OTP is incorrect. Please provide correct OTP!!");
                                return response()->json($result, 422);
                            }
                            $patient = DB::table('pat_patients_info')->where('MOBILE_NO', '=', $request->contact_no)->update([
                                'NAME' => $name,
                                'EMAIL' => $email,
                                'PATIENT_STATUS' => 2,
                                'ACTIVE_STATUS' => 1,
                                'OTP_COUNT' => 3,
                            ]);
                            $patient = DB::table('pat_patients_info')->where('MOBILE_NO', '=', $request->contact_no)->first();
                            $validatedData['password'] = bcrypt($request->password);
                            $validatedData['contact_no'] = $request->contact_no;
                            $user = User::create($validatedData);
                        }
            
                        
                        
                        
            
                        if(isset($patient) && isset($user)){
                            $result = new ApiResponseModel(true, "Patient created successfully!!", $patient);
                            return response()->json($result, 201);
                        }else{
                            $result = new ApiResponseModel(false, "Patient create failed!!");
                            return response()->json($result, 500);
                        }
            
                        
            
                    }
                }else{
                    $result = new ApiResponseModel(false, "Patient already exists. Please login!!");
                    return response()->json($result, 409);
                    
                }
            
        }
        
    }

    

    public function login(Request $request) {
        $validatedData = $request->validate([
            'contact_no' => ['required'],
            'password' => ['required'],
        ]);
    
        // Retrieve the user by email and password
        


        $user = User::where('contact_no', $request->contact_no)->first();
        if (!$user || !Hash::check($request->password, $user->password)) {
            // User not found or password does not match, handle appropriately
            $result = new ApiResponseModel(false, "Invalid Credentials!");
            return response()->json($result, 401);
        }

        if(isset($request->firebase_token)){
            DB::table('pat_patients_info')->where('MOBILE_NO', '=', $request->contact_no)->update([
                'firebase_token' => $request->firebase_token,
            ]);
        }
       
        $patient = DB::table('pat_patients_info')->where('MOBILE_NO', '=', $request->contact_no)->first();

    
        if (!$user || !$patient) {
            // User not found, handle appropriately (e.g., return an error response)
            $result = new ApiResponseModel(false, "Invalid Credentials !!");
            return response()->json($result, 500);
        }
    
        // User found, create a token
        $token = $user->createToken('access_token')->accessToken;
        $patient->access_token = $token;
        if(isset($patient->PROFILE_IMAGE)){
            $patient->PROFILE_IMAGE = url($patient->PROFILE_IMAGE);
        }
        $result = new ApiResponseModel(true, "Logged in successfully!!", $patient);
        return response()->json($result, 200);
    }

    public function getPatient($id){
        $patient = DB::table('pat_patients_info')->where('ID', '=', $id)->first();
        if(is_null($patient)){
            $result = new ApiResponseModel(false, "Patient not found!!");
            return response()->json($result, 500);
        }else{
            $result = new ApiResponseModel(true, "User found!!", $patient);
            return response()->json($result, 200);
        }
    }


    public function logout(Request $request)
    {
        // Revoke the access token
        Auth::user()->token()->revoke();
        $result = new ApiResponseModel(true, "Logged out successfully !!");
        return response()->json($result, 200);
    }


    public function forgotPassword(Request $request) {
        $validatedData = $request->validate([
            'email' => ['required'],
        ]);
    
        $user = User::where('email', $request->email)->first();
    
        if (!$user) {
            // User not found, handled appropriately
            $result = new ApiResponseModel(false, "User not found!");
            return response()->json($result, 404);
        }
    
        // Generating a reset token and store it in the database
        $tempPassword = Str::random(8); // Laravel helper function for generating random strings
        $tempPasswordInserted = DB::table('users')->where('email', '=', $request->email)->update([
            'password' => bcrypt($tempPassword),
        ]);

        Mail::send('customauth.verify', ['token' => $tempPassword], function($message) use($request){
            $message->to($request->email);
            $message->subject('Reset Password Notification');
        });
    
        // In this section send a mail or message with the reset token
        if($tempPasswordInserted){
            $result = new ApiResponseModel(true, "Temporary password sent successfully!");
            return response()->json($result, 200);
        }else{
            $result = new ApiResponseModel(true, "Temporary password generation failed!(DB)");
            return response()->json($result, 500);
        }
    }
    
    // Reset Password API
    public function changePassword(Request $request) {
        $validatedData = $request->validate([
            'id' => ['required'],
            'new_password' => ['required', 'min:6'],
            'old_password' => ['required', 'min:8'],
            'confirm_new_password' => ['required', 'min:6'],
        ]);

        if($request->new_password != $request->confirm_new_password){
            $result = new ApiResponseModel(false, "New password and password confirmation do not match!");
            return response()->json($result, 401);
        }

        $patient = DB::table('pat_patients_info')->where('ID', '=', $request->id)->first();
    
        $user = User::where('contact_no', $patient->MOBILE_NO)
                    ->first();
    

        if (!$user || !Hash::check($request->old_password, $user->password)) {
            // User not found or password does not match, handle appropriately
            $result = new ApiResponseModel(false, "Invalid Credentials!");
            return response()->json($result, 401);
        }
    
        // Update user's password and reset the reset_token
        $passwordUpdated = $user->update([
            'password' => bcrypt($request->new_password),
        ]);
    
        if($passwordUpdated){
            $result = new ApiResponseModel(true, "Password reset successful!");
            return response()->json($result, 200);
        }else{
            $result = new ApiResponseModel(true, "Password reset failed!(DB)");
            return response()->json($result, 500);
        }
        
    }


    

    public function updateUserProfile(Request $request){
        
        $validatedData = $request->validate([
            'ID' => ['required'],
            'NAME' => ['required'],
            'EMAIL' => ['email','required'],
            'AGE' => ['required'],
            'GENDER' => ['required'],
        ]);

        $id = $request->input("ID");

        $folderPath = "profileImages/patient/" . $id;

        if ($request->hasFile('user_image')) {

            $oldImage = DB::table('pat_patients_info')->where('ID', '=', $id)->value('PROFILE_IMAGE');

            // Deleting old image if it exists
            if (!empty($oldImage)) {
                $oldImagePath = "profileImages/patient/" . $id . "/" . $oldImage;
                if (file_exists($oldImagePath)) {
                    unlink($oldImagePath);
                }
            }

            $photo = $request->file('user_image');
            $name = '';
            $ext = '';
            $ext = strtolower($photo->getClientOriginalExtension());
            $name = strtolower(date('Y-m-d') . "_" . mt_rand(111111, 999999) . '.' . $ext);

            if (!file_exists($folderPath)) {
                mkdir($folderPath, 0777, true);
            }

            $photo->move($folderPath, $name);
            $photoName = $name;


            $patientImageUpdated = DB::table('pat_patients_info')->where('ID', '=', $id)->update([
                'PROFILE_IMAGE' => "profileImages/patient/".$id."/".$photoName,
            ]);
        }

        $bloodGroup = '';

        if(isset($request->BLOOD_GROUP)){
            $bloodGroup = $request->BLOOD_GROUP;
        }


        
        $patient = DB::table('pat_patients_info')->where('ID', '=', $id)->first();
        if(isset($patient)){
            // var_dump($patient->EMAIL);exit;
            $user = DB::table('users')->where('contact_no', '=', $patient->MOBILE_NO)->first();
            if($user->email == $request->EMAIL){
                $userUpdated = 1;
            }else{
                $userUpdated = DB::table('users')->where('contact_no', '=', $patient->MOBILE_NO)->update([
                    'email' => $request->EMAIL,
                ]);
            }

            if($patient->NAME != $request->NAME || $patient->EMAIL != $request->EMAIL || $patient->AGE != $request->AGE || $patient->BLOOD_GROUP != $request->BLOOD_GROUP || $patient->GENDER != $request->GENDER){
                $patientUpdated = DB::table('pat_patients_info')->where('ID', '=', $id)->update([
                    'NAME' => $request->NAME,
                    'EMAIL' => $request->EMAIL,
                    'AGE' => $request->AGE,
                    'BLOOD_GROUP' => $bloodGroup,
                    'GENDER' => $request->GENDER,
                ]);
            }else{
                $patientUpdated = 1;
            }
            
            if($userUpdated && $patientUpdated){


                $patient = DB::table('pat_patients_info')->where('ID', '=', $id)->first();

                if(isset($patient->PROFILE_IMAGE)){
                    $patient->PROFILE_IMAGE = url($patient->PROFILE_IMAGE);
                }
                $result = new ApiResponseModel(true, "User updated successfully!!", $patient);
                return response()->json($result, 200);
            }
        }
        
        $result = new ApiResponseModel(false, "User update unsuccessful!!(DB)");
        return response()->json($result, 500);
    }
}
