@extends('layouts.master') @section('content') @section('title') @endsection
<style>
    ul li.active,
    a.active {
        color: #3fbbc0;
    }

</style>
<div class="" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>{{$header['pageTitle']}}</h3>
            </div>
            <div class="title_right">
                <div class="item form-group">
                    <div class="col-md-3 col-sm-3 offset-md-9">
                        <button type="button" class="btn btn-primary btn-sm dynamicModal" pageTitle="Create New Medicine"
                            pageLink="{{url('/createMedicine')}}" data-modal-size="modal-lg" data-toggle="tooltip"
                            data-placement="top" title="Create Medicine">
                            Create Medicine
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="x_panel">
                    {{-- <div class="x_title">
                        <h2>{{$header['tableTitle']}} </h2>
                    </div> --}}
                    <div class="x_content">
                        <div class="row">
    <div class="col-sm-12">
        <div class="card-box table-responsive">
            <table id="datatable"
                class="table table-striped table-bordered custom-table-border dataTable no-footer"
                role="grid" aria-describedby="datatable_info">
                <thead>
                    <tr>
                        <th class="center">#</th>
                        <th class="center">Category</th>
                        <th class="center">Medicine</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @php $sl=1 @endphp @foreach($medicines as $row)
                    <tr>
                        <td>{{$sl}}</td>
                        <td>{{$row->CATEGORY_NAME}}</td>
                        <td>{{$row->MEDICINE}}</td>
                        <td>
                            <button type="button" class="btn btn-info btn-sm"
                                pageTitle="Update Medicine"
                                pageLink="{{url('/editMedicine/'.$row->ID)}}"
                                rowID = "{{$row->ID}}"
                                onclick="getUpdatePage($(this))"
                                data-modal-size="modal-xl" data-toggle="tooltip"
                                data-placement="top" title="Assign">
                                    <i class="fa fa-pencil-square-o"></i>
                            </button>
                        </td>
                    </tr>
                    @php $sl++;@endphp @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
function getUpdatePage(a){
    var rowID = a.context.attributes.rowID.nodeValue;
    var pageLink = a.context.attributes.pageLink.nodeValue;
    var pagetitle = a.context.attributes.pagetitle.nodeValue;
    if(rowID!=''){
        $('.ajaxLoaderFormLoad').show();
        $.ajax({
            type: 'GET',
            url: pageLink,
            success: function (data) {
                $('.ajaxLoaderFormLoad').hide();
                $('.modal').modal('show');
                $('#modalSize').addClass("modal-lg");
                $('.modal-title').html(pagetitle);
                $('.modal-body').html(data);
            }
        });
    }
}
</script>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function () {
    $('#datatable').DataTable({
        lengthMenu: [
            [100, 150, 200, -1],
            [100, 150, 200, 'All'],
        ],
    });
    //MergeGridCells();
});

function MergeGridCells() {
    var dimension_cells = new Array();
    var dimension_col = null;
    var columnCount = $("#datatable tr:first th").length;
    for (dimension_col = 0; dimension_col < columnCount; dimension_col++) {
        // first_instance holds the first instance of identical td
        var first_instance = null;
        var rowspan = 1;
        // iterate through rows
        $("#datatable").find('tr').each(function () {

            // find the td of the correct column (determined by the dimension_col set above)
            var dimension_td = $(this).find('td:nth-child(' + dimension_col + ')');

            if (first_instance == null) {
                // must be the first row
                first_instance = dimension_td;
            } else if (dimension_td.text() == first_instance.text()) {
                // the current td is identical to the previous
                // remove the current td
                dimension_td.remove();
                ++rowspan;
                // increment the rowspan attribute of the first instance
                first_instance.attr('rowspan', rowspan);
            } else {
                // this cell is different from the last
                first_instance = dimension_td;
                rowspan = 1;
            }
        });
    }
}
</script>
@endsection
