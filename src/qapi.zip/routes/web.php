<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Controller;
use App\Http\Controllers\AcademyOfficerController;
use App\Http\Controllers\Auth\LoginController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

// Route List

Route::get('login', [LoginController::class, 'login'])->name('login');
//Route::post('submit-login', [LoginController::class, 'postLogin'])->name('login.post');
//Route::get('registration', [LoginController::class, 'registration'])->name('register');
//Route::post('submit-registration', [LoginController::class, 'postRegistration'])->name('register.post');
Route::get('home', [LoginController::class, 'home']);
Route::get('logout', [LoginController::class, 'logout'])->name('logout');
Route::get('/', 'App\Http\Controllers\FontHomeController@home');
Route::get('/home2', 'App\Http\Controllers\FontHomeController@home2');
Route::get('/homescroll', 'App\Http\Controllers\FontHomeController@homeScroll');
Route::get('/getCurrentData', [App\Http\Controllers\FontHomeController::class, 'getCurrentData'])->name('getCurrentData');


// change password ...
Route::get('/changePassword', [App\Http\Controllers\custom_auth\ForgotPasswordController::class, 'changePassword'])->name('changePassword');
Route::post('/saveChangePassword', [App\Http\Controllers\custom_auth\ForgotPasswordController::class, 'saveChangePassword'])->name('saveChangePassword');

//Email
Route::get('/forgetPassword', [App\Http\Controllers\custom_auth\ForgotPasswordController::class, 'getEmail'])->name('forgetPassword');
Route::post('/forgetPassword', [App\Http\Controllers\custom_auth\ForgotPasswordController::class, 'postEmail'])->name('forgetPassword');
Route::get('/resetPassword/{token}', [App\Http\Controllers\custom_auth\ResetPasswordController::class, 'getPassword'])->name('resetPassword');
Route::post('/resetPassword', [App\Http\Controllers\custom_auth\ResetPasswordController::class, 'PostPassword'])->name('resetPassword');

//start backend route
Auth::routes();
Route::group(['middleware' => ['auth']], function () {
    // echo 'ddd';exit;
    //start academic officer route
    //start Admission Management route
    Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


    //start security and access setup
    //start Modules route
    Route::get('/moduleSetup', [App\Http\Controllers\security_access\ModulesController::class, 'index'])->name('moduleSetup');
    Route::get('/creatModuleSetup', [App\Http\Controllers\security_access\ModulesController::class, 'create'])->name('creatModuleSetup');

    Route::post('/storemoduleSetup', [App\Http\Controllers\security_access\ModulesController::class, 'store'])->name('storeModuleSetup');
    Route::get('/editemoduleSetup/{id}', [App\Http\Controllers\security_access\ModulesController::class, 'edit'])->name('edit');
    Route::post('/updatemoduleSetup/{id}', [App\Http\Controllers\security_access\ModulesController::class, 'update'])->name('update');
    //start Modules links route

    Route::get('/moduleLinkSetup', [App\Http\Controllers\security_access\ModuleLinksController::class, 'index'])->name('moduleLinkSetup');
    Route::get('/createModuleLinkSetup', [App\Http\Controllers\security_access\ModuleLinksController::class, 'create'])->name('createModuleLinkSetup');
    Route::post('/storeModuleLinkSetup', [App\Http\Controllers\security_access\ModuleLinksController::class, 'store'])->name('storeModuleLinkSetup');
    Route::get('/editModuleLinkSetup/{id}', [App\Http\Controllers\security_access\ModuleLinksController::class, 'edit'])->name('edit');
    Route::post('/updateModuleLinkSetup/{id}', [App\Http\Controllers\security_access\ModuleLinksController::class, 'update'])->name('update');
    //end Modules links route
    //start Modules Manage route
    Route::get('/moduleManage', [App\Http\Controllers\security_access\ModuleManageController::class, 'index'])->name('moduleManage');
    Route::get('/createGroup/{id}', [App\Http\Controllers\security_access\ModuleManageController::class, 'createGroup'])->name('createGroup');
    Route::get('/createUser/{id}', [App\Http\Controllers\security_access\ModuleManageController::class, 'createUser'])->name('createUser');
    Route::get('/assignModul', [App\Http\Controllers\security_access\ModuleManageController::class, 'assignModul'])->name('assignModul');
    Route::get('/addPage/{id}', [App\Http\Controllers\security_access\ModuleManageController::class, 'addPage'])->name('addPage');
    Route::post('/addModulesInsert', [App\Http\Controllers\security_access\ModuleManageController::class, 'addModules'])->name('addModules');
    Route::post('/deleteModules', [App\Http\Controllers\security_access\ModuleManageController::class, 'deleteModules'])->name('deleteModules');

    //end Modules Manage route

    // Modules Manage  New User
    Route::get('/userIndex', [App\Http\Controllers\security_access\ModuleManageController::class, 'userIndex'])->name('userIndex');
    Route::get('/searchUser/{type}/{dept}/{course}', [App\Http\Controllers\security_access\ModuleManageController::class, 'searchUser'])->name('searchUser');
    Route::get('/createUser', [App\Http\Controllers\security_access\ModuleManageController::class, 'createUser'])->name('createUser');
    Route::post('/storeUser', [App\Http\Controllers\security_access\ModuleManageController::class, 'store'])->name('store');

    Route::post('/userGroupLevel', [App\Http\Controllers\security_access\ModuleManageController::class, 'userGroupLevel'])->name('userGroupLevel');

    //  Modules Manage group
    Route::get('/groupIndex', [App\Http\Controllers\security_access\ModuleManageController::class, 'groupIndex'])->name('groupIndex');
    Route::get('/createGroup', [App\Http\Controllers\security_access\GroupController::class, 'createGroup'])->name('createGroup');
    Route::post('/storeGroup', [App\Http\Controllers\security_access\ModuleManageController::class, 'storeGroup'])->name('storeGroup');

    //  Modules Manage user group level
    Route::get('/createLevel/{id}', [App\Http\Controllers\security_access\ModuleManageController::class, 'createLevel'])->name('createLevel');
    Route::post('/storeLevel', [App\Http\Controllers\security_access\ModuleManageController::class, 'storeLevel'])->name('storeLevel');
    Route::get('/editLevel/{id}', [App\Http\Controllers\security_access\ModuleManageController::class, 'editLevel'])->name('editLevel');
    Route::post('/updateLevel/{id}', [App\Http\Controllers\security_access\ModuleManageController::class, 'updateLevel'])->name('updateLevel');


    // Modules Manage  add page
    Route::get('/addPage', [App\Http\Controllers\security_access\ModuleManageController::class, 'addPage'])->name('addPage');
    Route::get('/createPage', [App\Http\Controllers\security_access\ModuleManageController::class, 'createPage'])->name('createPage');
    Route::post('/addPageLink', [App\Http\Controllers\security_access\ModuleManageController::class, 'addPageLink'])->name('addPageLink');


    Route::post('/changePageLinkStatus', [App\Http\Controllers\security_access\ModuleManageController::class, 'changePageLinkStatus'])->name('changePageLinkStatus');
    Route::post('/changePageLinkRead', [App\Http\Controllers\security_access\ModuleManageController::class, 'changePageLinkRead'])->name('changePageLinkRead');
    Route::post('/changePageLinkDelete', [App\Http\Controllers\security_access\ModuleManageController::class, 'changePageLinkDelete'])->name('changePageLinkDelete');

    Route::post('/addPageLink', [App\Http\Controllers\security_access\ModuleManageController::class, 'addPageLink'])->name('addPageLink');
    Route::post('/changePageLinkCreate', [App\Http\Controllers\security_access\ModuleManageController::class, 'changePageLinkCreate'])->name('changePageLinkCreate');


    Route::post('/updatePageLink', [App\Http\Controllers\security_access\ModuleManageController::class, 'updatePageLink'])->name('updatePageLink');

    // Modules Manage  add page Module
    Route::get('/createPageModule', [App\Http\Controllers\security_access\ModuleManageController::class, 'createPageModule'])->name('createPageModule');

    //Security Access Assing Link To Group
    Route::post('/assingLinkGroupLevel', [App\Http\Controllers\security_access\ModuleManageController::class, 'assingLinkGroupLevel'])->name('assingLinkGroupLevel');
    Route::post('/assingLinkUserLevel', [App\Http\Controllers\security_access\ModuleManageController::class, 'assingLinkUserLevel'])->name('assingLinkUserLevel');
    Route::post('/assingLinkUsergroup', [App\Http\Controllers\security_access\ModuleManageController::class, 'assingLinkUsergroup'])->name('assingLinkUsergroup');

    //Security Access Assing Link To Group
    Route::post('/assingLinkGroupLevel', [App\Http\Controllers\security_access\ModuleManageController::class, 'assingLinkGroupLevel'])->name('assingLinkGroupLevel');
    Route::post('/assingLinkUserLevel', [App\Http\Controllers\security_access\ModuleManageController::class, 'assingLinkUserLevel'])->name('assingLinkUserLevel');
    Route::post('/assingLinkUsergroup', [App\Http\Controllers\security_access\ModuleManageController::class, 'assingLinkUsergroup'])->name('assingLinkUsergroup');

    Route::post('/modulePageLinkCreate', [App\Http\Controllers\security_access\ModuleLinkPermissionController::class, 'modulePageLinkCreate'])->name('modulePageLinkCreate');
    Route::post('/modulePageLinkDelete', [App\Http\Controllers\security_access\ModuleLinkPermissionController::class, 'modulePageLinkDelete'])->name('modulePageLinkDelete');
    Route::post('/modulePageLinkRead', [App\Http\Controllers\security_access\ModuleLinkPermissionController::class, 'modulePageLinkRead'])->name('modulePageLinkRead');
    Route::post('/modulePageLinkUpdate', [App\Http\Controllers\security_access\ModuleLinkPermissionController::class, 'modulePageLinkUpdate'])->name('modulePageLinkUpdate');
    Route::post('/insertPageLinkStatus', [App\Http\Controllers\security_access\ModuleManageController::class, 'insertPageLinkStatus'])->name('insertPageLinkStatus');

    //end security and access setup

    //Lookup  group and data
    Route::get('/lookupIndex', [App\Http\Controllers\lookup\LookupController::class, 'index'])->name('lookupIndex');
    Route::get('/createLookupGrpup', [App\Http\Controllers\lookup\LookupController::class, 'create'])->name('createLookupGrpup');
    Route::post('/storeLookupGroup', [App\Http\Controllers\lookup\LookupController::class, 'store'])->name('storeLookupGroup');
    Route::get('/createLookupGroupItem/{GROUP_ID}/{USE_CHAR_NUMB}', [App\Http\Controllers\lookup\LookupController::class, 'createLookupGroupItem'])->name('createLookupGroupItem');
    Route::post('/storeLookupGroupItem', [App\Http\Controllers\lookup\LookupController::class, 'storeLookupGroupItem'])->name('storeLookupGroupItem');
    Route::get('/editLookupGroupItem/{id}/{USE_CHAR_NUMB}', [App\Http\Controllers\lookup\LookupController::class, 'editLookupGroupItem'])->name('editLookupGroupItem');
    Route::post('/updateLookupGroupItem/{id}', [App\Http\Controllers\lookup\LookupController::class, 'updateLookupGroupItem'])->name('updateLookupGroupItem');

    // NICVD - Routes
    Route::get('/createPatientsDataSample', [App\Http\Controllers\patients_data\PatientsDataController::class, 'createPatientsDataSample'])->name('createPatientsDataSample');
    Route::get('/createPatientsData', [App\Http\Controllers\patients_data\PatientsDataController::class, 'createPatientsData'])->name('createPatientsData');
    Route::post('/storePatientsData', [App\Http\Controllers\patients_data\PatientsDataController::class, 'storePatientsData'])->name('storePatientsData');
    Route::get('/patientData', [App\Http\Controllers\patients_data\PatientsDataController::class, 'patientData'])->name('patientData');
    Route::get('/searchPatientData/{searchField}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'searchPatientData'])->name('searchPatientData');

    //Route::get('/createFollowup', [App\Http\Controllers\patients_data\PatientsDataController::class, 'createFollowup'])->name('createFollowup');
    //Route::get('/createFollowup/{patientID}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'createFollowup'])->name('createFollowup');
    Route::post('/createFollowup', [App\Http\Controllers\patients_data\PatientsDataController::class, 'createFollowup'])->name('createFollowup');
    Route::post('/storeFollowupData', [App\Http\Controllers\patients_data\PatientsDataController::class, 'storeFollowupData'])->name('storeFollowupData');

    Route::get('/viewPatientsData/{patientID}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'viewPatientsData'])->name('viewPatientsData');
    Route::get('/viewFollowupData/{followupID}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'viewFollowupData'])->name('viewFollowupData');

    // Medicine Setup
    Route::get('/medicineIndex', [App\Http\Controllers\medicine_setup\MedicineSetupController::class, 'medicineIndex'])->name('medicineIndex');
    Route::get('/createMedicine', [App\Http\Controllers\medicine_setup\MedicineSetupController::class, 'createMedicine'])->name('createMedicine');
    Route::post('/storeMedicine', [App\Http\Controllers\medicine_setup\MedicineSetupController::class, 'storeMedicine'])->name('storeMedicine');
    Route::get('/editMedicine/{id}', [App\Http\Controllers\medicine_setup\MedicineSetupController::class, 'editMedicine'])->name('editMedicine');
    Route::post('/updateMedicine', [App\Http\Controllers\medicine_setup\MedicineSetupController::class, 'updateMedicine'])->name('updateMedicine');

    // Profile HF Medicine PDF
    Route::get('/genProfileHFPDF/{patientID}/{followupID}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'genProfileHFPDF'])->name('genProfileHFPDF');

    //serial
    Route::get('/serialEntryPopup', [App\Http\Controllers\patients_data\PatientsDataController::class, 'serialEntryPopup'])->name('serialEntryPopup');
    Route::post('/storePatientSerial', [App\Http\Controllers\patients_data\PatientsDataController::class, 'storePatientSerial'])->name('storePatientSerial');
    Route::get('/viewStatus/{id}/{status}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'viewStatus'])->name('viewStatus');
    Route::post('/changeStatus', [App\Http\Controllers\patients_data\PatientsDataController::class, 'changeStatus'])->name('changeStatus');


    Route::get('/viewStatusDO/{id}/{status}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'viewStatusDO'])->name('viewStatusDO');
    Route::post('/changeStatusDO', [App\Http\Controllers\patients_data\PatientsDataController::class, 'changeStatusDO'])->name('changeStatusDO');

    Route::get('/serialEntry', [App\Http\Controllers\patients_data\PatientsDataController::class, 'serialEntry'])->name('serialEntry');
    Route::get('/searchSerialEntry/{searchField}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'searchSerialEntry'])->name('searchSerialEntry');
    Route::get('/updateSerialInfo/{id}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'updateSerialInfo'])->name('updateSerialInfo');
    Route::post('/storeUpdateSerial/', [App\Http\Controllers\patients_data\PatientsDataController::class, 'storeUpdateSerial'])->name('storeUpdateSerial');

    Route::get('/serial-entry', [App\Http\Controllers\patients_data\PatientsDataController::class, 'serialEntryForm'])->name('serialEntryForm');
    Route::post('/storePatientSerialAction', [App\Http\Controllers\patients_data\PatientsDataController::class, 'storePatientSerialAction'])->name('storePatientSerialAction');

    // History
    Route::get('/patientHistory', [App\Http\Controllers\patients_data\PatientsDataController::class, 'patientHistory'])->name('patientHistory');
    Route::get('/registeredPatientData', [App\Http\Controllers\patients_data\PatientsDataController::class, 'registeredPatientData'])->name('registeredPatientData');
    Route::post('/searchregisteredPatientData', [App\Http\Controllers\patients_data\PatientsDataController::class, 'searchregisteredPatientData'])->name('searchregisteredPatientData');
    Route::get('/searchPatientHistory/{searchFieldFrom}/{searchFieldTo}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'searchPatientHistory'])->name('searchPatientHistory');
    Route::get('/cancelSerial/{id}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'cancelSerial'])->name('cancelSerial');

    // Schedule appointment
    Route::get('/scheduleAppointmentData', [App\Http\Controllers\patients_data\PatientsDataController::class, 'scheduleAppointmentData'])->name('scheduleAppointmentData');
    Route::get('/editAppointment/{id}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'editAppointment'])->name('editAppointment');
    Route::post('/scheduleAppointment', [App\Http\Controllers\patients_data\PatientsDataController::class, 'scheduleAppointment'])->name('scheduleAppointment');
    Route::get('/getPatientSuggestions/{query}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'getPatientSuggestions'])->name('getPatientSuggestions');

    // Set break Time
    Route::get('/setBreakTime/{text}/{value}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'setBreakTime'])->name('setBreakTime');
    Route::get('/setReportTime/{text}/{value}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'setReportTime'])->name('setBreakTime');

    // Get Current Data
    //Route::get('/getCurrentData', [App\Http\Controllers\patients_data\PatientsDataController::class, 'getCurrentData'])->name('getCurrentData');
    Route::get('/getCurrentList', [App\Http\Controllers\patients_data\PatientsDataController::class, 'getCurrentList'])->name('getCurrentList');

    //Category Setup
    Route::get('/categorySetup', [App\Http\Controllers\setup\CategorySetupController::class, 'index'])->name('categorySetup');
    Route::get('/createCategorySetup', [App\Http\Controllers\setup\CategorySetupController::class, 'create'])->name('createCategorySetup');
    Route::post('/storeCategorySetup', [App\Http\Controllers\setup\CategorySetupController::class, 'store'])->name('storeCategorySetup');
    Route::get('/editCategorySetup/{id}', [App\Http\Controllers\setup\CategorySetupController::class, 'edit'])->name('editCategorySetup');
    Route::get('/editRegisteredPatient/{id}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'editRegisteredPatient'])->name('editRegisteredPatient');
    Route::post('/approveAppointment', [App\Http\Controllers\patients_data\PatientsDataController::class, 'approveAppointment'])->name('approveAppointment');
    Route::post('/updateCategorySetup', [App\Http\Controllers\setup\CategorySetupController::class, 'update'])->name('updateCategorySetup');

    //Patient Summarby
    Route::get('/patientSummary', [App\Http\Controllers\patients_data\PatientsDataController::class, 'patientSummary'])->name('patientSummary');
    Route::get('/searchPatientSummary/{searchFieldFrom}/{searchFieldTo}', [App\Http\Controllers\patients_data\PatientsDataController::class, 'searchPatientSummary'])->name('searchPatientSummary');
    Route::post('/approvePatientAppointment', [App\Http\Controllers\patients_data\PatientsDataController::class, 'approvePatientAppointment'])->name('approvePatientAppointment');
});
