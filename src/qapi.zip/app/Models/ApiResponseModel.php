<?php

namespace App\Models;
use JsonSerializable;

class ApiResponseModel implements JsonSerializable
{
    public $status;
    public $message;
    public $data;
 
    public function __construct($status,$message,$data=null) {
        $this->status = $status;
        $this->message = $message;
        $this->data = $data;
    }
 
    public function jsonSerialize() {
        $json = array(
            'status' => $this->status,
            'message' => $this->message
        );
        if($this->data!=null) $json['data'] = $this->data; 
        return $json;
    }

}
?>
