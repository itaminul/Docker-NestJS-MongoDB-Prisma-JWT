@section('content')
@include('layouts.modalFormSubmit')
@php $actionUrl=url('/updateCategorySetup'); @endphp
<script>
    $('form').parsley();

</script>
<?php ini_set('memory_limit', -1) ?>
<div class="flash-message"></div>
<div class="x_content">
    <form id="CategorySetupForm" data-parsley-validate="" role="form" method="post" action="{{$actionUrl}}"
        class="form-label-left" autocomplete="off">
        @csrf
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Category Name*</label>
            <div class="col-md-6 col-sm-6">
                <input class="form-control input-field-required-sign" name="NAME" id="NAME" value="{{$result->NAME}}" required />
            </div>
        </div>
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Active Status <span
                    class="required  input-field-required-sign">*</span></label>
            <div class="col-md-6 col-sm-6">
                <select class="form-control" name="ACTIVE_STATUS" required>
                    <option value="1" {{ ($result->ACTIVE_STATUS==1)? 'selected':'' }}>Active</optin>
                    <option value="0" {{ ($result->ACTIVE_STATUS<1)? 'selected':'' }}>Inactive</optin>
                </select>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="form-group">
            <div class="col-md-6 offset-md-3">
                <input type="hidden" name="ID" value="{{$result->ID}}">
                <button type="submit" class="btn btn-primary">Submit</button>
                <button type='reset' class="btn btn-success">Reset</button>
            </div>
        </div>

    </form>
</div>
