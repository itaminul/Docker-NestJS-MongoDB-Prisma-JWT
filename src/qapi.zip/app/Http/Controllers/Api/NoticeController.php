<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiResponseModel;

    class NoticeController extends Controller{

        public function noticeList() {
            $notice_list = [
                // array(
                //     "url" => url('/uploads/notice_images/1.jpg')
                // ),
                // array(
                //     "url" => url('/uploads/notice_images/2.jpg')
                // ),
                // array(
                //     "url" => url('/uploads/notice_images/3.jpg')
                // ),
                array(
                    "url" => url('/uploads/notice_images/4.jpg')
                ),
            ];
            $data = array(
                "notice_list" => $notice_list
            );
            $result = new ApiResponseModel(true,"Notice List Found",$data);
            return response()->json($result, 200);
        }

    }

?>

