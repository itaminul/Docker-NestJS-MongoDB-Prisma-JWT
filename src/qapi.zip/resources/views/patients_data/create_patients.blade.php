@extends('layouts.master')
@php $actionUrl=url('/storePatientsData'); @endphp
@section('content')
@section('title')
@endsection
<style>
	.card0 {
        background-color: #F5F5F5;
        border-radius: 8px;
        z-index: 0
    }

    .card00 {
        z-index: 0
    }

    .card1 {
        margin-left: 140px;
        z-index: 0;
        border-right: 1px solid #F5F5F5
    }

    .card2 {
        display: none
    }

    .card2.show {
        display: block
    }

    .social {
        border-radius: 50%;
        background-color: #FFCDD2;
        color: #E53935;
        height: 47px;
        width: 47px;
        padding-top: 16px;
        cursor: pointer
    }

    input,
    select {
        padding: 2px;
        border-radius: 0px;
        box-sizing: border-box;
        color: #9E9E9E;
        border: 1px solid #BDBDBD;
        font-size: 16px;
        letter-spacing: 1px;
        height: 35px !important
    }

    select {
        width: 100%;
        margin-bottom: 85px
    }

    input:focus,
    select:focus {
        -moz-box-shadow: none !important;
        -webkit-box-shadow: none !important;
        box-shadow: none !important;
        border: 1px solid #E53935 !important;
        outline-width: 0 !important
    }

    .custom-checkbox .custom-control-input:checked~.custom-control-label::before {
        background-color: #E53935
    }

    .form-group {
        position: relative;
        margin-bottom: 1.5rem;
        /*width: 77%*/
    }

    .form-control-placeholder {
        position: absolute;
        top: 0px;
        padding: 12px 2px 0 2px;
        transition: all 300ms;
        opacity: 0.5
    }

    .form-control:focus+.form-control-placeholder,
    .form-control:valid+.form-control-placeholder {
        font-size: 95%;
        top: 10px;
        transform: translate3d(0, -100%, 0);
        opacity: 1;
        background-color: #fff
    }

    .next-button {
        width: 18%;
        height: 50px;
        background-color: #BDBDBD;
        color: #fff;
        border-radius: 6px;
        padding: 10px;
        cursor: pointer
    }

    .next-button:hover {
        background-color: #E53935;
        color: #fff
    }

    .get-bonus {
        margin-left: 154px
    }

    .pic {
        width: 230px;
        height: 110px
    }

    #progressbar {
        position: absolute;
        left: 35px;
        overflow: hidden;
        color: #E53935
    }

    #progressbar li {
        list-style-type: none;
        font-size: 8px;
        font-weight: 400;
        margin-bottom: 36px
    }

    #progressbar li:nth-child(3) {
        margin-bottom: 88px
    }

    #progressbar .step0:before {
        content: "";
        color: #fff
    }

    #progressbar li:before {
        width: 30px;
        height: 30px;
        line-height: 30px;
        display: block;
        font-size: 20px;
        background: #fff;
        border: 2px solid #E53935;
        border-radius: 50%;
        margin: auto
    }

    #progressbar li:last-child:before {
        width: 40px;
        height: 40px
    }

    #progressbar li:after {
        content: '';
        width: 3px;
        height: 66px;
        background: #BDBDBD;
        position: absolute;
        left: 58px;
        top: 15px;
        z-index: -1
    }

    #progressbar li:last-child:after {
        top: 147px;
        height: 132px
    }

    #progressbar li:nth-child(3):after {
        top: 81px
    }

    #progressbar li:nth-child(2):after {
        top: 0px
    }

    #progressbar li:first-child:after {
        position: absolute;
        top: -81px
    }

    #progressbar li.active:after {
        background: #E53935
    }

    #progressbar li.active:before {
        background: #E53935;
        font-family: FontAwesome;
        content: "\f00c"
    }

    .tick {
        width: 100px;
        height: 100px
    }

    .prev {
        display: block;
        position: absolute;
        left: 40px;
        top: 20px;
        cursor: pointer
    }

    .prev:hover {
        color: #D50000 !important
    }

    @media screen and (max-width: 912px) {
        .card00 {
            padding-top: 30px
        }

        .card1 {
            border: none;
            margin-left: 50px
        }

        .card2 {
            border-bottom: 1px solid #F5F5F5;
            margin-bottom: 25px
        }

        .social {
            height: 30px;
            width: 30px;
            font-size: 15px;
            padding-top: 8px;
            margin-top: 7px
        }

        .get-bonus {
            margin-top: 40px !important;
            margin-left: 75px
        }

        #progressbar {
            left: -25px
        }
    }



</style>
<link rel="stylesheet" href="{{URL::asset('assets/01102022/popper.min.js')}}">

<div class="container-fluid px-1 px-md-4 py-5 mx-auto">
    <div class="row d-flex justify-content-center">
      <div class="col-12 col-md-12 col-lg-12 col-xl-12">
        <div class="card card0 border-0">
          <div class="row">
            <div class="col-12">
              <div class="card card00 m-2 border-0">
                {{-- <div class="row text-center justify-content-center px-3">

                  <button class="btn btn-danger next-button prev btnNextPrev" style="margin-left:-36px;"><span class="fa fa-arrow-left"></span></button>
                    <br><br><br>


                </div> --}}
                <style>
                    .btnNextPrev{
                        width: 80px;
                        border: none;
                        border-radius: 4px;
                        color: #fff;
                        height: 38px;
                        line-height: 18px;
                        float: right;
                        color:#fff !important;
                        text-align: center;
                    }
                    .next-button{
                        background-color: #5b8b31;
                    }
                    .prev{
                        background-color: #c95c5c;
                        line-height: 38px;
                        margin-left: -54px;
                        margin-top: -15px;
                    }
                    .next-button:hover, .next-button:active{
                        background-color: #4c7429 !important;
                        color:#fff !important;
                    }
                    .prev:hover{
                        background-color: #c72b2b;
                        color:#fff !important;
                    }
                  </style>
                <div class="d-flex flex-md-row px-3 mt-4 flex-column">
                  <div class="col-md-2">
                    <p class="prev text-danger btnNextPrev"><span class="fa fa-arrow-left"></span></p><br><br><br>

                    <div class="card1">
                      <ul id="progressbar" class="text-center">
                        <li class="active step0"></li>
                        <li class="step0"></li>
                        <li class="step0"></li>
                        <li class="step0"></li>
                        <li class="step0"></li>
                        <li class="step0"></li>
                      </ul>
                      <h6 class="mb-5">Demographic Information</h6>
                      <h6 class="mb-5">Caregiver's Information</h6>
                      <h6 class="mb-5">Etiology Findings</h6>
                      <h6 class="mb-5">Analysis & Medication</h6>
                      <h6 class="mb-5">Clinical Findings</h6>
                    </div>
                  </div>
                  <div class="col-md-10">
                    <div class="card2 first-screen show">
                        <h2 style="text-align: center"><b>Demographic Information</b></h2>

                      {{-- <div class="row px-3 mt-4">
                        <div class="form-group mt-1 mb-1"> <input type="text" id="email" class="form-control" required> <label class="ml-3 form-control-placeholder" for="email">Email</label> </div>
                        <div class="next-button text-center mt-1 ml-2"> <span class="fa fa-arrow-right"></span> </div>
                      </div> --}}

                        <div class="row px-3 mt-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" class="form-control" id="name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="patient_id">Patient ID</label>
                                    <input type="text" class="form-control" id="patient_id">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="enrollment_date">Enrollment Date</label>
                                    <input type="text" class="form-control" id="enrollment_date">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="dept_of_cardiology">Department of Cardiology</label>
                                    <input type="text" class="form-control" id="dept_of_cardiology">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="patient_name">Patient's Name</label>
                                    <input type="text" class="form-control" id="patient_name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="birth_date">Date of Birth</label>
                                    <input type="text" class="form-control" id="birth_date">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="address">Address</label>
                                    <textarea class="form-control" id="address" name="address" rows="3" cols="50"></textarea>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">Mobile No</label>
                                    <input type="text" class="form-control" id="phone">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="monthlyIncome">Monthly Income</label>
                                <div class="form-group" style="padding-top: 15px">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="monthly_income" id="income_one" value="1">
                                        <label class="form-check-label" for="income_one">Less than 25,000</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="monthly_income" id="income_two" value="2">
                                        <label class="form-check-label" for="income_two">25,000 - 50,000</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="monthly_income" id="income_three" value="2">
                                        <label class="form-check-label" for="income_three">More than 50,000</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="gender">Gender</label>
                                <div class="form-group" style="padding-top: 15px">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="gender" id="male_gender" value="1">
                                        <label class="form-check-label" for="male_gender">Male</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="gender" id="female_gender" value="2">
                                        <label class="form-check-label" for="female_gender">Female</label>
                                    </div>
                                </div>
                            </div>

                            <button class="btn btn-danger next-button btnNextPrev mt-1 ml-2"><span class="fa fa-arrow-right"></span></button>
                        </div>

                    </div>
                    <div class="card2 ml-2">
                        <h2 style="text-align: center"><b>Caregiver's Information</b></h2>

                        <div class="row px-3 mt-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="caregiver_name">Caregiver Name</label>
                                    <input type="text" class="form-control" id="caregiver_name" name="caregiver_name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="caregiver_relationship">Relationship</label>
                                    <input type="text" class="form-control" id="caregiver_relationship" name="caregiver_relationship">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="caregiver_mobile">Mobile No</label>
                                    <input type="text" class="form-control" id="caregiver_mobile" name="caregiver_mobile">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="caregiver_mobile_home">Home No</label>
                                    <input type="text" class="form-control" id="caregiver_mobile_home" nanme="caregiver_mobile_home">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="hf_nursing_specialist">HF nursing specialist</label>
                                    <input type="text" class="form-control" id="hf_nursing_specialist" name="hf_nursing_specialist">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="primary_physician">Primary physician</label>
                                    <input type="text" class="form-control" id="primary_physician" name="primary_physician">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="referral_physician">Referral physician</label>
                                    <input type="text" class="form-control" id="referral_physician" name="referral_physician">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="additional_members">Additional members</label>
                                    <input type="text" class="form-control" id="additional_members" name="additional_members">
                                </div>
                            </div>

                            <button class="btn btn-danger next-button btnNextPrev mt-1 ml-2"><span class="fa fa-arrow-right"></span></button>
                        </div>
                    </div>
                    <div class="card2 ml-2">
                        <h2 style="text-align: center"><b>Etiology Findings</b></h2>
                        <style>
                            .checkbox-holder .form-group{
                                margin-bottom: initial;
                            }
                        </style>

                        <div class="row px-3 mt-4 checkbox-holder">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <table>
                                        <tr>
                                            <td style="padding-bottom: 12px"><b>Etiology of heart failure</b></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="ischemia" type="checkbox" class="custom-control-input">
                                        <label for="ischemia" class="custom-control-label">Ischemia</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="hypertension" type="checkbox" class="custom-control-input">
                                        <label for="hypertension" class="custom-control-label">Hypertension</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="valvular_heart_disease" type="checkbox" class="custom-control-input">
                                        <label for="valvular_heart_disease" class="custom-control-label">Valvular Heart Disease</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="viral_myocarditis" type="checkbox" class="custom-control-input">
                                        <label for="viral_myocarditis" class="custom-control-label">Viral Myocarditis</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="peri_partum" type="checkbox" class="custom-control-input">
                                        <label for="peri_partum" class="custom-control-label">Peri-partum</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="drug_induced" type="checkbox" class="custom-control-input">
                                        <label for="drug_induced" class="custom-control-label">Drug induced (specify drug) <input type="text"></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="alcohol_intake" type="checkbox" class="custom-control-input">
                                        <label for="alcohol_intake" class="custom-control-label">Alcohol Intake</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="infiltrative_heart_disease" type="checkbox" class="custom-control-input">
                                        <label for="infiltrative_heart_disease" class="custom-control-label">Infiltrative Heart Disease</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="other_etiology" type="checkbox" class="custom-control-input">
                                        <label for="other_etiology" class="custom-control-label">Other Etiology (please specify below)</label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">

                                <div class="form-group">
                                    <table>
                                        <tr>
                                            <td><b>Comorbidities &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></td>
                                            <td><input type="radio" name="comorbidities" id="comorbidities_yes" value="1"></td>
                                            <td>&nbsp;Yes&nbsp;&nbsp;&nbsp;</td>
                                            <td><input type="radio" name="comorbidities" id="comorbidities_no" value="0"></td>
                                            <td>&nbsp;No</td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="hyperlipidemia" type="checkbox" class="custom-control-input">
                                        <label for="hyperlipidemia" class="custom-control-label">Hyperlipidemia</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="diabetes_mellitus" type="checkbox" class="custom-control-input">
                                        <label for="diabetes_mellitus" class="custom-control-label">Diabetes Mellitus</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="hypertension" type="checkbox" class="custom-control-input">
                                        <label for="hypertension" class="custom-control-label">Hypertension</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="anemia" type="checkbox" class="custom-control-input">
                                        <label for="anemia" class="custom-control-label">Anemia (Female: Hb<12g/dL; Male: Hb<14g/dL)</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="cerebral_vascular_disease" type="checkbox" class="custom-control-input">
                                        <label for="cerebral_vascular_disease" class="custom-control-label">Cerebral Vascular Disease</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="renal_dysfunction" type="checkbox" class="custom-control-input">
                                        <label for="renal_dysfunction" class="custom-control-label">Renal Dysfunction</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="liver_dysfunction" type="checkbox" class="custom-control-input">
                                        <label for="liver_dysfunction" class="custom-control-label">Liver Dysfunction</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="af" type="checkbox" class="custom-control-input">
                                        <label for="af" class="custom-control-label">AF</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="gout" type="checkbox" class="custom-control-input">
                                        <label for="gout" class="custom-control-label">Gout</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="other_dysfunction" type="checkbox" class="custom-control-input">
                                        <label for="other_dysfunction" class="custom-control-label">Others (please specify below)</label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <textarea class="form-control" id="other_etiology_details" name="address" rows="3" cols="50"></textarea>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <textarea class="form-control" id="other_comorbidities" name="address" rows="3" cols="50"></textarea>
                                </div>
                            </div>
                            <br><br>
                            <br><br>
                            <button class="btn btn-danger next-button btnNextPrev mt-1 ml-2"><span class="fa fa-arrow-right"></span></button>
                        </div>

                    </div>
                    <div class="card2 ml-2">
                        <h2 style="text-align: center"><b>Analysis & Medication</b></h2>
                        <style>
                            .checkbox-holder .form-group{
                                margin-bottom: initial;
                            }
                        </style>

                        <div class="row px-3 mt-4 checkbox-holder">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <table>
                                        <tr>
                                            <td style="padding-bottom: 12px"><b>Analysis</b></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="poor_compliance" type="checkbox" class="custom-control-input">
                                        <label for="poor_compliance" class="custom-control-label">Poor compliance</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="ongoing_ischemia" type="checkbox" class="custom-control-input">
                                        <label for="ongoing_ischemia" class="custom-control-label">Ongoing Ischemia</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="fast_af" type="checkbox" class="custom-control-input">
                                        <label for="fast_af" class="custom-control-label">Fast AF</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="arrhythmia" type="checkbox" class="custom-control-input">
                                        <label for="arrhythmia" class="custom-control-label">Arrhythmia</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="end_stage_heart_failure" type="checkbox" class="custom-control-input">
                                        <label for="end_stage_heart_failure" class="custom-control-label">End stage heart failure</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="trauma" type="checkbox" class="custom-control-input">
                                        <label for="trauma" class="custom-control-label">Trauma</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="indeterminate" type="checkbox" class="custom-control-input">
                                        <label for="indeterminate" class="custom-control-label">Indeterminate</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="pregnancy" type="checkbox" class="custom-control-input">
                                        <label for="pregnancy" class="custom-control-label">Pregnancy</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="infection" type="checkbox" class="custom-control-input">
                                        <label for="infection" class="custom-control-label">Infection</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="surgery" type="checkbox" class="custom-control-input">
                                        <label for="surgery" class="custom-control-label">Surgery</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="anemia" type="checkbox" class="custom-control-input">
                                        <label for="anemia" class="custom-control-label">Anemia</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="drug_induced" type="checkbox" class="custom-control-input">
                                        <label for="drug_induced" class="custom-control-label">Others (specify) <input type="text"></label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <table>
                                        <tr>
                                            <td style="padding-bottom: 12px"><b>Medication</b></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="nsaid" type="checkbox" class="custom-control-input">
                                        <label for="nsaid" class="custom-control-label">NSAID</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="steroids" type="checkbox" class="custom-control-input">
                                        <label for="steroids" class="custom-control-label">Steroids</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="ocp" type="checkbox" class="custom-control-input">
                                        <label for="ocp" class="custom-control-label">OCP</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="anti_cancer_drug_cardiac" type="checkbox" class="custom-control-input">
                                        <label for="anti_cancer_drug_cardiac" class="custom-control-label">Anti-Cancer Drug Cardiac</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input id="depressant_drug" type="checkbox" class="custom-control-input">
                                        <label for="depressant_drug" class="custom-control-label">Depressant Drug</label>
                                    </div>
                                </div>
                            </div>
                            <br><br>
                            <br><br>
                            <button class="btn btn-danger next-button btnNextPrev mt-1 ml-2"><span class="fa fa-arrow-right"></span></button>
                        </div>

                    </div>

                    <div class="card2 ml-2">
                        <h2 style="text-align: center"><b>Clinical Findings</b></h2>

                        <div class="row px-3 mt-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="hospitalization_date">Hospitalization date</label>
                                    <input type="text" class="form-control" id="hospitalization_date">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="length_of_stay">Length of stay</label>
                                    <input type="text" class="form-control" id="length_of_stay">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="symptoms">Symptoms</label>
                                    <input type="text" class="form-control" id="symptoms">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="height">Height</label>
                                    <input type="text" class="form-control" id="height">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="weight">Weight</label>
                                    <input type="text" class="form-control" id="weight">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="resp_rate">Resp Rate</label>
                                    <input type="text" class="form-control" id="resp_rate">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="blood_pressure">Blood Pressure</label>
                                    <input type="text" class="form-control" id="blood_pressure">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="pulse">Pulse</label>
                                    <input type="text" class="form-control" id="pulse">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="o2_sat">O2 sat</label>
                                    <input type="text" class="form-control" id="o2_sat">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <table>
                                        <tr>
                                            <td>NYHA class &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                            <td>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="nyha_class" id="nyha_class_one" value="1">
                                                    <label class="form-check-label" for="nyha_class_one">I</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="nyha_class" id="nyha_class_two" value="2">
                                                    <label class="form-check-label" for="nyha_class_two">II</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="nyha_class" id="nyha_class_three" value="2">
                                                    <label class="form-check-label" for="nyha_class_three">III</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="nyha_class" id="nyha_class_three" value="2">
                                                    <label class="form-check-label" for="nyha_class_three">IV</label>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <table>
                                        <tr>
                                            <td>Ascites &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                            <td>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="ascites" id="ascites_yes" value="1">
                                                    <label class="form-check-label" for="ascites_yes">Yes</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="ascites" id="ascites_no" value="2">
                                                    <label class="form-check-label" for="ascites_no">No</label>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <table>
                                        <tr>
                                            <td>Anemia &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                            <td>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="h_animia" id="h_animia_zero" value="1">
                                                    <label class="form-check-label" for="h_animia_zero">0</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="h_animia" id="h_animia_one" value="2">
                                                    <label class="form-check-label" for="h_animia_one">+1</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="h_animia" id="h_animia_two" value="3">
                                                    <label class="form-check-label" for="h_animia_two">+2</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="h_animia" id="h_animia_three" value="4">
                                                    <label class="form-check-label" for="h_animia_three">+3</label>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="bmi">BMI</label>
                                    <input type="text" class="form-control" id="bmi">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <table>
                                        <tr>
                                            <td>Leg edema &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                            <td>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="leg_edema" id="leg_edema_zero" value="1">
                                                    <label class="form-check-label" for="leg_edema_zero">0</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="leg_edema" id="leg_edema_one" value="2">
                                                    <label class="form-check-label" for="leg_edema_one">+1</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="leg_edema" id="leg_edema_two" value="3">
                                                    <label class="form-check-label" for="leg_edema_two">+2</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="leg_edema" id="leg_edema_three" value="4">
                                                    <label class="form-check-label" for="leg_edema_three">+3</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="leg_edema" id="leg_edema_four" value="4">
                                                    <label class="form-check-label" for="leg_edema_four">+4</label>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <table>
                                        <tr>
                                            <td>Hepatomegaly &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                            <td>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="hepatomigaly" id="hepatomigaly_yes" value="1">
                                                    <label class="form-check-label" for="hepatomigaly_yes">Yes</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="hepatomigaly" id="hepatomigaly_no" value="2">
                                                    <label class="form-check-label" for="hepatomigaly_no">No</label>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="measurement">Measurement</label>
                                    <input type="text" class="form-control" id="measurement">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <table>
                                        <tr>
                                            <td>JVP &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                            <td>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="jvp" id="jvp_normal" value="1">
                                                    <label class="form-check-label" for="jvp_normal">Normal</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="jvp" id="jvp_raised" value="2">
                                                    <label class="form-check-label" for="jvp_raised">Raised</label>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <h6>Precordium</h6>
                            </div>
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <h6>Heart</h6>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="measurement">S1</label>
                                        <input type="text" class="form-control" id="measurement">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="measurement">S2</label>
                                        <input type="text" class="form-control" id="measurement">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="measurement">S3</label>
                                        <input type="text" class="form-control" id="measurement">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="measurement">S4</label>
                                        <input type="text" class="form-control" id="measurement">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="measurement">Cardiac Murmur & Added Sound</label>
                                        <textarea class="form-control" rows="3"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <h6>Lungs</h6>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <table>
                                            <tr>
                                                <td>Vesicular breath sound &nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                <td><input type="radio" name="vesicular_breath_sound" id="vesicular_breath_sound_present" value="1"></td>
                                                <td>&nbsp;Present&nbsp;&nbsp;&nbsp;</td>
                                                <td><input type="radio" name="vesicular_breath_sound" id="vesicular_breath_sound_absent" value="0"></td>
                                                <td>&nbsp;Absent</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <table>
                                            <tr>
                                                <td>Bronchial breath sound&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                <td><input type="radio" name="bronchial_breath_sound" id="bronchial_breath_sound_present" value="1"></td>
                                                <td>&nbsp;Present&nbsp;&nbsp;&nbsp;</td>
                                                <td><input type="radio" name="bronchial_breath_sound" id="bronchial_breath_sound_absent" value="0"></td>
                                                <td>&nbsp;Absent</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <table>
                                            <tr>
                                                <td>Prolonged expiration &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                <td><input type="radio" name="prolonged_expiration" id="prolonged_expiration_yes" value="1"></td>
                                                <td>&nbsp;Yes&nbsp;&nbsp;&nbsp;</td>
                                                <td><input type="radio" name="prolonged_expiration" id="prolonged_expiration_no" value="0"></td>
                                                <td>&nbsp;No</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <table>
                                            <tr>
                                                <td>Creps &nbsp;&nbsp;&nbsp;
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                </td>
                                                <td><input type="radio" name="creps" id="creps_present" value="1"></td>
                                                <td>&nbsp;Present&nbsp;&nbsp;&nbsp;</td>
                                                <td><input type="radio" name="creps" id="creps_absent" value="0"></td>
                                                <td>&nbsp;Absent</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <h6>Laboratory tests</h6>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="wbc">WBC</label>
                                    <input type="text" class="form-control" id="wbc">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="hb_percent">Hb%</label>
                                    <input type="text" class="form-control" id="hb_percent">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="hct">HCT</label>
                                    <input type="text" class="form-control" id="hct">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="na">Na</label>
                                    <input type="text" class="form-control" id="na">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="k">K</label>
                                    <input type="text" class="form-control" id="k">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="s_creatinine">S. Creatinine</label>
                                    <input type="text" class="form-control" id="s_creatinine">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="bnp">BNP/ NT-proBNP</label>
                                    <input type="text" class="form-control" id="bnp">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="ferritin">Ferritin</label>
                                    <input type="text" class="form-control" id="ferritin">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="tibc">TIBC</label>
                                    <input type="text" class="form-control" id="tibc">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="ecg">ECG</label>
                                    <input type="text" class="form-control" id="ecg">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <h6>Echocardiography</h6>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="Echocardiography_date">on date</label>
                                    <input type="text" class="form-control" id="Echocardiography_date">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="cxr_pa_view">CXR P/A View</label>
                                    <input type="text" class="form-control" id="cxr_pa_view">
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="lvidd">LVIDd</label>
                                    <input type="text" class="form-control" id="lvidd">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="lvids">LVIDs</label>
                                    <input type="text" class="form-control" id="lvids">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="lvef">LVEF</label>
                                    <input type="text" class="form-control" id="lvef">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="mr">MR</label>
                                    <input type="text" class="form-control" id="mr">
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="ar">AR</label>
                                    <input type="text" class="form-control" id="ar">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="tr">TR</label>
                                    <input type="text" class="form-control" id="tr">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="ms">MS</label>
                                    <input type="text" class="form-control" id="ms">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="as">AS</label>
                                    <input type="text" class="form-control" id="as">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="6mwt">6MWT</label>
                                    <input type="text" class="form-control" id="6mwt">
                                </div>
                            </div>
                            <div class="col-md-6">
                            </div>
                            <br>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="hf_diagnosis_date">HF diagnosis date</label>
                                    <input type="text" class="form-control" id="hf_diagnosis_date">
                                </div>
                            </div>
                            <div class="col-md-6">
                            </div>
                            <div class="col-md-6">
                                <h6>HF management</h6>
                            </div>
                            <div class="col-md-6">
                                <h6>Name and dose</h6>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <table>
                                        <tr>
                                            <td>ACEIs &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                            <td>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="aceis" id="aceis_yes" value="1">
                                                    <label class="form-check-label" for="aceis_yes">Yes</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="aceis" id="aceis_no" value="2">
                                                    <label class="form-check-label" for="aceis_no">No</label>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="aceis_dose">
                                </div>
                            </div>




                            <button class="btn btn-danger next-button btnNextPrev mt-1 ml-2"><span class="fa fa-arrow-right"></span></button>
                        </div>

                    </div>


                    <div class="card2 ml-2">
                      <div class="row px-3 mt-2 mb-4 text-center">
                        <h2 class="col-12 text-danger"><strong>Success !</strong></h2>
                        <div class="col-12 text-center"><img class="tick"></div>
                        <h6 class="col-12 mt-2"><i>...Enjoy COOKIES...</i></h6>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12">
                <div class="row px-3">
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        var current_fs, next_fs, previous_fs;

        // No BACK button on first screen
        if ($(".show").hasClass("first-screen")) {
            $(".prev").css({
                'display': 'none'
            });
        }

        // Next button
        $(".next-button").click(function() {

            current_fs = $(this).parent().parent();
            next_fs = $(this).parent().parent().next();

            $(".prev").css({
                'display': 'block'
            });

            $(current_fs).removeClass("show");
            $(next_fs).addClass("show");

            $("#progressbar li").eq($(".card2").index(next_fs)).addClass("active");

            current_fs.animate({}, {
                step: function() {

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });

                    next_fs.css({
                        'display': 'block'
                    });
                }
            });
        });

        // Previous button
        $(".prev").click(function() {

            current_fs = $(".show");
            previous_fs = $(".show").prev();

            $(current_fs).removeClass("show");
            $(previous_fs).addClass("show");

            $(".prev").css({
                'display': 'block'
            });

            if ($(".show").hasClass("first-screen")) {
                $(".prev").css({
                    'display': 'none'
                });
            }

            $("#progressbar li").eq($(".card2").index(current_fs)).removeClass("active");

            current_fs.animate({}, {
                step: function() {

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });

                    previous_fs.css({
                        'display': 'block'
                    });
                }
            });
        });

    });

    // custom scripting
    $('.left_col').css('display','none');
    $('.right_col').css('margin-left', 'initial');
    $('.top_nav').css('margin-left', 'initial');
    // $('.footer').css('margin-left', '-230px');
    $('body').css('background', '#fff');
    $('#menu_toggle').css('display', 'none');
    $('#progressbar').addClass('progressbarStyle');
</script>
<style>
    .card0{
        border-radius: initial;
    }
    body .container.body .right_col{
        /* background: #32d1b3; */
    }
    .nav_menu{
        box-shadow: initial;
    }
    .card0{
        background-color: #fff;
    }
    .progressbarStyle{
        left: 0 !important;
        margin-left: -60px !important;
    }
    @media screen and (max-width: 767px) {
        .card1{
            margin-bottom:165px;
        }
    }

    label{
        margin-bottom:2px;
    }


    /* .progressbarDiv1d44{
        background-color: #999999;
        position:absolute;
        overflow: hidden;
        color: #E53935;
        height: 408px;
        margin-top: -100px;
        margin-left: -62px;
        list-style: none;
    }
    .progressbarDiv2444{
        background-color: #F4F6FA;
        position:absolute;
        overflow: hidden;
        color: #E53935;
        height: 408px;
        margin-top: -301px;
        margin-left: 163px;
        list-style: none;
    } */
    .card1{
        margin-left: 25px;
    }
</style>


<style>
    /* The container */
    .containerCheck {
      display: block;
      position: relative;
      padding-left: 35px;
      margin-bottom: 12px;
      cursor: pointer;
      font-size: 22px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    /* Hide the browser's default checkbox */
    .containerCheck input {
      position: absolute;
      opacity: 0;
      cursor: pointer;
      height: 0;
      width: 0;
    }

    /* Create a custom checkbox */
    .checkmark {
      position: absolute;
      top: 0;
      left: 0;
      height: 25px;
      width: 25px;
      background-color: #eee;
    }

    /* On mouse-over, add a grey background color */
    .containerCheck:hover input ~ .checkmark {
      background-color: #ccc;
    }

    /* When the checkbox is checked, add a blue background */
    .containerCheck input:checked ~ .checkmark {
      background-color: #2196F3;
    }

    /* Create the checkmark/indicator (hidden when not checked) */
    .checkmark:after {
      content: "";
      position: absolute;
      display: none;
    }

    /* Show the checkmark when checked */
    .containerCheck input:checked ~ .checkmark:after {
      display: block;
    }

    /* Style the checkmark/indicator */
    .containerCheck .checkmark:after {
      left: 9px;
      top: 5px;
      width: 5px;
      height: 10px;
      border: solid white;
      border-width: 0 3px 3px 0;
      -webkit-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      transform: rotate(45deg);
    }
    </style>

@endsection

