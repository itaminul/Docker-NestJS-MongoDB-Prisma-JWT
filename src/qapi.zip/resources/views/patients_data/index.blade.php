@extends('layouts.master') @section('content') @section('title') @endsection
<style>
    ul li.active,
    a.active {
        color: #3fbbc0;
    }

</style>
<div class="" role="main">
    <div class="">
        <div class="page-title">
            <div class="col-md-8">
                <div class="row">
                    <?php
                        $cDate = date('Y-m-d');
                        $info = DB::select("SELECT * FROM pat_patients_info WHERE ENTRY_DATE='$cDate'
                            AND PATIENT_STATUS=1 ORDER BY SL_NO");
                        $X = '';
                        $result = '';
                        if($info){
                            foreach ($info as $row) {
                                $X.=" ".$row->NAME."(".$row->SL_NO."),";
                            }
                            $result = substr($X,0,-1);
                        }
                    ?>
                    <h3>
                        {{-- {{$header['pageTitle']}} --}}
                        <span style="font-size: 20px; color: #5858f3;">
                            Current Serial: {{$result}}</span>
                    </h3>
                </div>
            </div>
            <div class="col-md-4">
                <table style="float:right">
                    <tr>
                        <td style="color:darkolivegreen;text-align:right;font-weight:bold;">Prayer time? &nbsp;</td>
                        <td>
                            <?php
                            $settings = new App\Models\Settings();
                            $flag = $settings->getValOfSettings('TEA_BREAK');
                            ?>
                            <input type="checkbox" class="circle-nicelabel" name="TEA_BREAK" id="TEA_BREAK" value="1" {{($flag==1)? 'checked':''}}/>
                        </td>
                        <td style="color:#B06FCF;text-align:right;font-weight:bold;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Report view? &nbsp;</td>
                        <td>
                            <?php
                            $settings = new App\Models\Settings();
                            $flag = $settings->getValOfSettings('REPORT_BREAK');
                            ?>
                            <input type="checkbox" class="circle-nicelabel" name="REPORT_BREAK" id="REPORT_BREAK" value="1" {{($flag==1)? 'checked':''}}/>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="x_panel">
                    {{-- <div class="x_title">
                        <h2>{{$header['tableTitle']}} </h2>
                    </div> --}}
                    <div class="x_title" style="display: none">
                        {{-- <h2>{{$header['tableTitle']}} </h2> --}}

                        {{-- filtering start --}}

                        {{-- <div class="row" style="padding-top:15px">
                            <div class="col-sm-12">
                                <div class="col-md-5">
                                    <div class="field item form-group">
                                        <label class="col-form-label col-md-4 col-sm-4  label-align">Patient ID / Phone</label>
                                        <div class="col-md-8 col-sm-8">
                                            <input type="text" class="form-control searchField required" name="" id="searchField" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="field item form-group">
                                        <div style="display: block; color:#FFF">
                                            <a id="btnSearch" class="btn btn-info">Search</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> --}}

                        {{-- filtering end --}}


                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content" id="searchPatientData">
                        {{-- <div class="row">
                            <div class="col-sm-12">
                                <div class="card-box table-responsive">
                                    <table id="datatable"
                                        class="table table-striped table-bordered custom-table-border dataTable no-footer"
                                        role="grid" aria-describedby="datatable_info">
                                        <thead>
                                            <tr>
                                                <th class="center">#</th>
                                                <th class="center">Patient ID</th>
                                                <th class="center">Name</th>
                                                <th class="center">Patient name</th>
                                                <th class="center">Gender</th>
                                                <th class="center">Phone</th>
                                                <th class="center">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php $sl=1 @endphp @foreach($patients as $row)
                                            <tr>
                                                <td>{{$sl}}</td>
                                                <td style="color:#09097c;">{{$row->PATIENT_ID}}</td>
                                                <td>{{$row->NAME}}</td>
                                                <td>{{$row->PATIENT_NAME}}</td>
                                                <td>{{($row->GENDER==1)? 'Male':'Female'}}</td>
                                                <td>{{$row->MOBILE_NO}}</td>
                                                <td>
                                                    <button type="button" class="btn btn-info btn-sm">
                                                        ACTIVE
                                                      </button>
                                                </td>
                                            </tr>
                                            @php $sl++;@endphp @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div> --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
// search on user list
    $('#btnSearch').click(function(){
        var searchField = $('#searchField').val();

        if(searchField==''){
            getPatientData(searchField='');
        }else{
            getPatientData(searchField);
        }
    });

    getPatientData(searchField='');

    // get patient data list, with search or without search
    function getPatientData(searchField=''){

        if(searchField=='') searchField=0;

        $('.ajaxLoaderFormLoad').show();
        $.ajax({
            type: 'GET',
            url: '{{url("/searchPatientData")}}/'+searchField,
            success: function (data) {
                $('.ajaxLoaderFormLoad').hide();
                $('#searchPatientData').html(data);
                $('#datatable').dataTable();
            }
        });
    }

    function setBreakZero(text=null){
        $.ajax({
            type: 'GET',
            url: '{{url("/setBreakTime")}}/'+text+'/'+0,
            success: function (data) {
            }
        });
    }

    $('#TEA_BREAK').click(function(){
        $('#REPORT_BREAK').prop('checked', false);
        setBreakZero('REPORT_BREAK');

        var patStatus = false;
        $('.PATIENT_STATUS').map(function () {
            if(this.value==1){
                patStatus = true;
            }
        }).get();

        /*if ($('#REPORT_BREAK').is(':checked')) {
            $('#REPORT_BREAK').prop('checked', false);
            // alertify.alert("Please, turn off report view option first.");
            // return false;
        }*/

        if ($(this).is(':checked')) {
            if(patStatus){
                alertify.alert("Please, complete all DI before turn on prayer time.");
                return false;
            }
            var breakTime = 1;
        }else{
            var breakTime = 0;
        }
        $.ajax({
            type: 'GET',
            url: '{{url("/setBreakTime")}}/'+'TEA_BREAK/'+breakTime,
            success: function (data) {
                if(data==1){
                    alertify.alert('Prayer time is on.');
                }else if(data==0){
                    alertify.alert('Prayer time is off.');
                }else{}
            }
        });
    });

    $('#REPORT_BREAK').click(function(){
        $('#TEA_BREAK').prop('checked', false);
        setBreakZero('TEA_BREAK');

        var patStatus = false;
        $('.PATIENT_STATUS').map(function () {
            if(this.value==1){
                patStatus = true;
            }
        }).get();

        /*if ($('#TEA_BREAK').is(':checked')) {
            $('#TEA_BREAK').prop('checked', false);
            // alertify.alert("Please, turn off prayer time first.");
            // return false;
        }*/

        if ($(this).is(':checked')) {
            if(patStatus){
                alertify.alert("Please, complete all DI before turn on report view time.");
                return false;
            }
            var reportTime = 1;
        }else{
            var reportTime = 0;
        }
        $.ajax({
            type: 'GET',
            url: '{{url("/setReportTime")}}/'+'REPORT_BREAK/'+reportTime,
            success: function (data) {
                if(data==1){
                    alertify.alert('Report view time is on.');
                }else if(data==0){
                    alertify.alert('Report view time is off.');
                }else{}
            }
        });
    });
</script>
<script>
    $('input').nicelabel();
</script>
@endsection
