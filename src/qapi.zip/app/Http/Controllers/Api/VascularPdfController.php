<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiResponseModel;
use DB;

class VascularPdfController extends Controller{


    public function getvascularPdfList()
    {
        $pdf_list = DB::table('vascular_pdf_info')->select('PDF_NAME', 'PDF_URL')->get();
        if(!$pdf_list){
            $result = new ApiResponseModel(true,"PDF List Not Found");
            return response()->json($result, 500);
        }
        foreach($pdf_list as $pdf){
            $pdf->PDF_URL = url($pdf->PDF_URL);
        }
        $data = array(
            "pdf_list" => $pdf_list
        );
        $result = new ApiResponseModel(true,"PDF List Found",$data);
        return response()->json($result, 200);
    }

}

?>