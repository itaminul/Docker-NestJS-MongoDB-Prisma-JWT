<div class="row patientDataTable">
    <div class="col-sm-12">
        <div class="card-box table-responsive">
            <div class="card text-center pt-3 p-0 count-card shadow p-3 mb-5 bg-white rounded" style="width: 18rem;">
                <h1 class="display-4 text-dark"><b>{{ count($patients) }}</b></h1>
                <div class="card-body p-0">
                    <h2 class="card-text text-dark"><b>Total Patients.</b></h2>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function getStatusPage(a) {
        var url = a.context.attributes.pageLink.nodeValue;
        var pageTitle = a.context.attributes.pageTitle.nodeValue;
        $.ajax({
            type: 'GET',
            url: url,
            success: function(data) {
                $('.modal-body').html(data);
                $('.modal').modal('show');
                $('#modalSize').addClass("modal-lg");
                $('.modal-title').html(pageTitle);
                // $('.modal-content').css({"width": "400px", "margin": "auto"});
                // $('.modal-title').css({"font-size": "19px", "color": "#000"});
            }
        });
    }

    $(document).ready(function() {
        $('#datatable12').DataTable({
            lengthMenu: [
                [80, 150, 200, -1],
                [80, 150, 200, 'All'],
            ],
            "order": []
        });
    });

    function getProfileUpdatePage(a) {
        var url = a.context.attributes.pageLink.nodeValue;
        if (url != '') {
            $('.ajaxLoaderFormLoad').show();
            $.ajax({
                type: 'GET',
                url: url,
                success: function(data) {
                    $('.ajaxLoaderFormLoad').hide();
                    $('.modal').modal('show');
                    // $('#modalSize').addClass("modal-lg");
                    $('.modal-title').html(a.context.attributes.pagetitle.nodeValue);
                    $('.modal-body').html(data);
                }
            });
        }
    }
</script>
<style>
    .patientDataTable .btn {
        padding: 2px 4px !important;
        font-size: 13px !important;
    }

    /*.btnFollowup, .btnCreateFollowup, .btnProfile{
    padding: 2px 4px !important;
    font-size: 13px;
}*/
    .btnCreateFollowup {
        background-color: #eeb60f;
        border-color: #eeb60f;
        color: #212529 !important;
    }

    .btnCP,
    .btnDI,
    .btnDO {
        width: 60px;
    }

    .btnCP,
    .btnCP:hover,
    .btnCP:focus,
    .btnCP:active {
        background-color: #B06FCF !important;
        border-color: #B06FCF !important;
    }

    .btnDI,
    .btnDI:hover,
    .btnDI:focus,
    .btnDI:active {
        background-color: #DAB600 !important;
        border-color: #DAB600 !important;
    }

    .btnDO,
    .btnDO:hover,
    .btnDO:focus,
    .btnDO:active {
        background-color: #82AB47 !important;
        border-color: #82AB47 !important;
    }

    .count-card {
        position: relative;
        margin-left: 35%
    }

    .patientDataTable {
        margin-top: 15vh;
        margin-bottom: 15vh;
    }
</style>
