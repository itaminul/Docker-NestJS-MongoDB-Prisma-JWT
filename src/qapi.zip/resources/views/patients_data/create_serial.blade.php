@section('content')
@include('layouts.modalFormSubmit')
@php $actionUrl=url('/storePatientSerial'); @endphp
<script>
    $('form').parsley();
</script>
<?php ini_set('memory_limit', -1) ?>
<div class="flash-message"></div>
<div class="x_content">
    <form id="ClassRoomSetupForm" data-parsley-validate="" role="form" method="post" action="{{$actionUrl}}"
        class="form-label-left" enctype="multipart/form-data" autocomplete="off">
        @csrf

        <?php
        $MX_SL = 0;
        if($slInfo){
            $MX_SL = $slInfo->MAX_SL + 1;
        }else{
                $MX_SL = $MX_SL+1;
        }
        ?>
        <style>
            .SL_NO[readonly] {
                background-color: #f5f7f9;
            }
        </style>
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Serial No</label>
            <div class="col-md-6 col-sm-6">
                <input class="form-control input-field-required-sign SL_NO" name="SL_NO" id="SL_NO" value="{{$MX_SL}}" required readonly/>
            </div>
        </div>
        {{-- <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Department*</label>
            <div class="col-md-6 col-sm-6">
                <select class="form-control" name="DEPT_ID" id="DEPT_ID" required>
                    <option value="">--select--</option>
                    @if($depts)
                    @foreach($depts as $row)
                    <option value="{{$row->LOOKUP_DATA_ID}}">{{$row->LOOKUP_DATA_NAME}}</option>
                    @endforeach
                    @endif
                </select>
            </div>
        </div>
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Doctor*</label>
            <div class="col-md-6 col-sm-6">
                <select class="form-control" name="DOCTOR_ID" id="DOCTOR_ID" required>
                    <option value="">--select--</option>
                    @if($doctors)
                    @foreach($doctors as $row)
                    <option value="{{$row->LOOKUP_DATA_ID}}">{{$row->LOOKUP_DATA_NAME}}</option>
                    @endforeach
                    @endif
                </select>
            </div>
        </div>
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Room No*</label>
            <div class="col-md-6 col-sm-6">
                <select class="form-control" name="ROOM_NO" id="ROOM_NO" required>
                    <option value="">--select--</option>
                    @if($rooms)
                    @foreach($rooms as $row)
                    <option value="{{$row->LOOKUP_DATA_ID}}">{{$row->LOOKUP_DATA_NAME}}</option>
                    @endforeach
                    @endif
                </select>
            </div>
        </div> --}}
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Category*</label>
            <div class="col-md-6 col-sm-6">
                <select class="form-control" name="CATEGORY_ID" id="CATEGORY_ID" required>
                    <option value="">--select--</option>
                    @if($categories)
                    @foreach($categories as $row)
                    <option value="{{$row->ID}}">{{$row->NAME}}</option>
                    @endforeach
                    @endif
                </select>
            </div>
        </div>
        <div class="field item form-group">
            <label class="col-form-label col-md-3 col-sm-3  label-align">Name</label>
            <div class="col-md-6 col-sm-6">
                <input class="form-control input-field-required-sign" name="NAME" id="NAME"/>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="form-group">
            <div class="col-md-6 offset-md-3">
                <input type="hidden" name="targetURL" id="targetURL">
                <button type="submit" class="btn btn-primary">Submit</button>
                {{-- <button type='reset' class="btn btn-success">Reset</button> --}}
            </div>
        </div>

    </form>
</div>
<script>
    // Redirect to specific location
    var k = $(location).attr("href");
    const myArray = k.split("/");
    var result = myArray[myArray.length - 1];
    $('#targetURL').val(result);
</script>


